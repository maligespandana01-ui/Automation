/**
 * @charset UTF-8
 * TestContext - MCP-inspired structured context for sharing state across
 * API, UI, and DB validation steps within a single test flow.
 *
 * Tracks data provenance (source: 'api' | 'ui' | 'db') and provides
 * cross-layer validation to ensure consistency between all three layers.
 *
 * Usage:
 *   const ctx = new TestContext();
 *   ctx.set('flightNumber', '1046', 'api');
 *   ctx.set('flightNumber', '1046', 'ui');
 *   ctx.set('flightNumber', '1046', 'db');
 *   const result = ctx.crossValidate('flightNumber');
 *   // { field: 'flightNumber', api: '1046', ui: '1046', db: '1046', match: true }
 */
export class TestContext {
    constructor() {
        /** @type {Map<string, {value: *, source: string, timestamp: number}>} */
        this._store = new Map();
        /** @type {Array<{action: string, key: string, source: string, timestamp: number}>} */
        this._history = [];
    }

    /**
     * Sets a value in the context with source metadata.
     * Uses composite key (source.key) to allow same field from multiple sources.
     * @param {string} key - Context key (e.g., 'flightNumber', 'origin')
     * @param {*} value - The value to store
     * @param {string} source - Origin of the data ('api' | 'ui' | 'db' | 'manual')
     */
    set(key, value, source = 'manual') {
        const compositeKey = `${source}.${key}`;
        this._store.set(compositeKey, { value, source, timestamp: Date.now() });
        this._history.push({ action: 'set', key, source, timestamp: Date.now() });
    }

    /**
     * Gets a value by key and optional source.
     * If source is provided, returns the value from that specific source.
     * If no source, returns the most recently set value for that key.
     * @param {string} key - Context key
     * @param {string} [source] - Optional source filter
     * @returns {*} The stored value or undefined
     */
    get(key, source) {
        if (source) {
            return this._store.get(`${source}.${key}`)?.value;
        }
        // Return the most recent value for this key across all sources
        const sources = ['api', 'ui', 'db', 'manual'];
        for (const s of sources) {
            const entry = this._store.get(`${s}.${key}`);
            if (entry !== undefined) return entry.value;
        }
        return undefined;
    }

    /**
     * Gets value with full metadata (source, timestamp).
     * @param {string} key - Context key
     * @param {string} source - Source to look up
     * @returns {{ value: *, source: string, timestamp: number } | undefined}
     */
    getWithMeta(key, source) {
        return this._store.get(`${source}.${key}`);
    }

    /**
     * Bulk set from an API response object.
     * @param {Object} data - Key-value pairs from API response
     */
    setFromApi(data) {
        for (const [key, value] of Object.entries(data)) {
            this.set(key, value, 'api');
        }
    }

    /**
     * Bulk set from UI-extracted data.
     * @param {Object} data - Key-value pairs extracted from UI
     */
    setFromUi(data) {
        for (const [key, value] of Object.entries(data)) {
            this.set(key, value, 'ui');
        }
    }

    /**
     * Bulk set from DB query result.
     * @param {Object} data - Key-value pairs from database row
     */
    setFromDb(data) {
        for (const [key, value] of Object.entries(data)) {
            this.set(key, value, 'db');
        }
    }

    /**
     * Cross-validates a field across all three sources (API, UI, DB).
     * @param {string} field - Field name to validate
     * @returns {{ field: string, api: *, ui: *, db: *, match: boolean }}
     */
    crossValidate(field) {
        const apiVal = this.get(field, 'api');
        const uiVal = this.get(field, 'ui');
        const dbVal = this.get(field, 'db');

        const defined = [apiVal, uiVal, dbVal].filter(v => v !== undefined);
        const allMatch = defined.length > 1 && defined.every(v => String(v) === String(defined[0]));

        return {
            field,
            api: apiVal ?? '(not set)',
            ui: uiVal ?? '(not set)',
            db: dbVal ?? '(not set)',
            match: allMatch,
        };
    }

    /**
     * Cross-validates multiple fields at once.
     * @param {string[]} fields - Array of field names
     * @returns {Array<{ field: string, api: *, ui: *, db: *, match: boolean }>}
     */
    crossValidateAll(fields) {
        return fields.map(f => this.crossValidate(f));
    }

    /**
     * Returns a snapshot of the entire context for Allure reporting.
     * @returns {Object}
     */
    snapshot() {
        const obj = {};
        for (const [compositeKey, entry] of this._store) {
            obj[compositeKey] = { value: entry.value, source: entry.source };
        }
        return obj;
    }

    /**
     * Returns the audit history of all set operations.
     * @returns {Array}
     */
    getHistory() {
        return [...this._history];
    }

    /**
     * Clears all stored data.
     */
    clear() {
        this._store.clear();
        this._history.length = 0;
    }
}
