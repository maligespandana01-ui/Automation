/**
 * @charset UTF-8
 * FlightDataService - Thin wrapper around existing apiHelper to fetch flight
 * data from NTM, XSDG, OpsHub services. Does NOT duplicate HTTP logic —
 * reuses httpRequest() and buildUrl() from utils/helpers/apiHelper.js.
 *
 * This service acts as the single entry point for UI tests to get flight
 * data from backend APIs, bridging the backend→UI data flow.
 */
import { httpRequest, buildUrl } from '../utils/helpers/apiHelper.js';
import { getEnvVariable } from '../utils/config/EnvLoader.js';
import { ENV_CONFIG_KEYS, HTTP_METHODS } from '../utils/constants/Constants.js';
import * as allure from 'allure-js-commons';

export class FlightDataService {
    /**
     * @param {import('@playwright/test').APIRequestContext} request - Playwright API request context
     */
    constructor(request) {
        this.request = request;
        this.opshubBaseUrl = getEnvVariable(ENV_CONFIG_KEYS.URL_OPSHUB);
        this.hazrapsBaseUrl = getEnvVariable(ENV_CONFIG_KEYS.URL_HAZRAPS);
    }

    /**
     * Fetches flight info from OpsHub Flight Info API.
     * Reuses the same endpoint used by FlightHub_CrewBase.api.spec.js.
     * @param {string} flightNumber - Flight number (e.g., '1046')
     * @param {string} flightDate - Flight date (e.g., '2026-04-21')
     * @param {string} origin - Origin airport code (e.g., 'DFW')
     * @param {string} destination - Destination airport code (e.g., 'MIA')
     * @returns {Promise<Object>} Parsed flight info response
     */
    async getFlightInfo(flightNumber, flightDate, origin, destination) {
        return allure.step(`Fetch flight info: ${flightNumber} on ${flightDate}`, async () => {
            const endpoint = getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_OPSHUB_FLIGHT_INFO);
            const url = buildUrl(this.opshubBaseUrl, endpoint);

            const response = await httpRequest(this.request, {
                method: HTTP_METHODS.POST,
                url,
                headers: { 'Content-Type': 'application/json' },
                body: { flightNumber, flightDate, origin, destination },
            });

            const status = response.status();
            const body = await response.json();

            await allure.attachment('Flight Info Request',
                JSON.stringify({ flightNumber, flightDate, origin, destination }, null, 2),
                'application/json');
            await allure.attachment('Flight Info Response',
                JSON.stringify(body, null, 2), 'application/json');
            await allure.attachment('Response Status', `${status}`, 'text/plain');

            return { status, data: body };
        });
    }

    /**
     * Fetches flight status from OpsHub Flight Status API.
     * @param {string} flightNumber - Flight number
     * @param {string} flightDate - Flight date
     * @param {string} origin - Origin airport code
     * @param {string} destination - Destination airport code
     * @returns {Promise<Object>} Parsed flight status response
     */
    async getFlightStatus(flightNumber, flightDate, origin, destination) {
        return allure.step(`Fetch flight status: ${flightNumber} on ${flightDate}`, async () => {
            const endpoint = getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_OPSHUB_FLIGHT_STATUS);
            const url = buildUrl(this.opshubBaseUrl, endpoint);

            const response = await httpRequest(this.request, {
                method: HTTP_METHODS.POST,
                url,
                headers: { 'Content-Type': 'application/json' },
                body: { flightNumber, flightDate, origin, destination },
            });

            const status = response.status();
            const body = await response.json();

            await allure.attachment('Flight Status Response',
                JSON.stringify(body, null, 2), 'application/json');

            return { status, data: body };
        });
    }

    /**
     * Posts XSDG/HAZRAPS data via the publish endpoint.
     * Reuses the same endpoint used by HazrapsProcessing.api.spec.js.
     * @param {string} xsdgXml - XSDG XML message content
     * @returns {Promise<Object>} Parsed response
     */
    async publishXsdg(xsdgXml) {
        return allure.step('Publish XSDG message via HAZRAPS', async () => {
            const endpoint = getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_HAZRAPS_REWRITE);
            const url = buildUrl(this.hazrapsBaseUrl, endpoint);

            const response = await httpRequest(this.request, {
                method: HTTP_METHODS.POST,
                url,
                headers: { 'Content-Type': 'application/xml' },
                body: xsdgXml,
            });

            const status = response.status();
            const body = await response.text();

            await allure.attachment('XSDG Publish Response', body, 'text/plain');

            return { status, data: body };
        });
    }

    /**
     * Fetches bin assignment data via the bin assign API endpoint.
     * @param {Object} params - { flightNumber, flightDate, origin, destination }
     * @returns {Promise<Object>} Bin assignment data
     */
    async getBinAssignData(params) {
        return allure.step(`Fetch bin assign data: flight ${params.flightNumber}`, async () => {
            const endpoint = getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_BIN_ASSIGN);
            const url = buildUrl(this.opshubBaseUrl, endpoint);

            const response = await httpRequest(this.request, {
                method: HTTP_METHODS.POST,
                url,
                headers: { 'Content-Type': 'application/json' },
                body: params,
            });

            const status = response.status();
            const body = await response.json();

            await allure.attachment('Bin Assign API Response',
                JSON.stringify(body, null, 2), 'application/json');

            return { status, data: body };
        });
    }
}
