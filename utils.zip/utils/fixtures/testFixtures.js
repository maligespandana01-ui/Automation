/**
 * @charset UTF-8
 * Custom Playwright Fixtures - Provides shared TestContext, FlightDataService,
 * authenticated page, and page objects to tests via dependency injection.
 *
 * Usage in tests:
 *   import { test, expect } from '../../utils/fixtures/testFixtures.js';
 *
 *   test('my e2e test', async ({ testContext, flightService, binLocationPage }) => {
 *       // testContext, flightService, binLocationPage are auto-injected
 *   });
 */
import { test as base } from '@playwright/test';
import { TestContext } from '../../services/TestContext.js';
import { FlightDataService } from '../../services/FlightDataService.js';
import { BrowserHelpers } from '../helpers/BrowserHelpers.js';
import { AutoNotocLoginPage } from '../../pages/ui/autonotoc/AutoNotocLoginPage.js';
import { BinLocationAssignPage } from '../../pages/ui/autonotoc/BinLocationAssignPage.js';
import { EmergencyResponseReportPage } from '../../pages/ui/autonotoc/EmergencyResponseReportPage.js';
import { getEnvVariable } from '../config/EnvLoader.js';
import { ENV_CONFIG_KEYS } from '../constants/Constants.js';
import { Logger } from '../helpers/Logger.js';

/**
 * Extended Playwright test with custom fixtures.
 */
export const test = base.extend({

    /**
     * Shared test context for API → UI → DB data flow.
     * Fresh instance per test to avoid cross-test contamination.
     */
    testContext: async ({}, use) => {
        const ctx = new TestContext();
        Logger.debug('Fixture', 'TestContext initialized');
        await use(ctx);
        Logger.debug('Fixture', 'TestContext snapshot at teardown', ctx.snapshot());
    },

    /**
     * Flight data service that reuses existing apiHelper.js.
     * Injected with Playwright's request context for HTTP calls.
     */
    flightService: async ({ request }, use) => {
        const service = new FlightDataService(request);
        Logger.debug('Fixture', 'FlightDataService initialized');
        await use(service);
    },

    /**
     * Authenticated browser page with AutoNOTOC login already completed.
     * Handles browser launch, login, and teardown (browser close).
     */
    authenticatedPage: async ({}, use) => {
        const page = await BrowserHelpers.launchBrowser();
        const loginPage = new AutoNotocLoginPage(page);
        await loginPage.login(
            getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_USERNAME),
            getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_PASSWORD)
        );
        Logger.info('Fixture', 'AutoNOTOC login completed');
        await use(page);
        // Teardown: close browser
        const browser = page.context().browser();
        if (browser) await browser.close();
        Logger.info('Fixture', 'Browser closed');
    },

    /**
     * Ready-to-use BinLocationAssignPage with navigation done.
     * Depends on authenticatedPage fixture.
     */
    binLocationPage: async ({ authenticatedPage }, use) => {
        const loginPage = new AutoNotocLoginPage(authenticatedPage);
        await loginPage.navigateToBinLocationAssignment();
        const binPage = new BinLocationAssignPage(authenticatedPage);
        Logger.info('Fixture', 'Navigated to Bin Location Assignment page');
        await use(binPage);
    },

    /**
     * Ready-to-use EmergencyResponseReportPage with navigation done.
     * Depends on authenticatedPage fixture.
     */
    emergencyResponsePage: async ({ authenticatedPage }, use) => {
        const errPage = new EmergencyResponseReportPage(authenticatedPage);
        await errPage.navigateToEmergencyResponseReport();
        Logger.info('Fixture', 'Navigated to Emergency Response Report page');
        await use(errPage);
    },
});

export { expect } from '@playwright/test';
