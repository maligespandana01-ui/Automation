import vaultFactory from 'node-vault';

// Load config from environment variables
const vaultAddr = process.env.VAULT_ADDR || 'http://127.0.0.1:8200';
const vaultNamespace = process.env.VAULT_NAMESPACE || '';
const roleId = process.env.ROLE_ID;
const secretId = process.env.SECRET_ID;

// Create Vault client
const vault = vaultFactory({
  endpoint: vaultAddr,
  namespace: vaultNamespace || undefined,
});

// Authenticate with AppRole and read secret
export async function getSecret(secretPath) {
  try {
    // Login with AppRole
    const auth = await vault.approleLogin({ role_id: roleId, secret_id: secretId });
    vault.token = auth.auth.client_token;

    // Read secret (KV v2: data is nested under "data")
    const result = await vault.read(secretPath);
    if (!result || !result.data || !result.data.data) {
      throw new Error(`No data found at path: ${secretPath}`);
    }
    return result.data.data;
  } catch (err) {
    console.error('Vault error:', err);
    throw err;
  }
}

// Load secrets from Vault and set to process.env
export async function loadSecretsToEnv(secretPath) {
  const secrets = await getSecret(secretPath);
  for (const [key, value] of Object.entries(secrets)) {
    process.env[key] = value;
  }
}
