import dotenv from 'dotenv';
import fs from 'fs';

const env = process.env.ENV || 'nonprod';

dotenv.config({
  path: `.env.${env}`,
});

const envFilePath = `.env.${env}`;
if (!fs.existsSync(envFilePath)) {
  throw new Error(`Environment file '${envFilePath}' not found. Please ensure the file exists for the '${env}' environment.`);
}

export function getEnvVariable(key) {
  const value = process.env[key];
  if (value === undefined) {
    throw new Error(`Environment variable '${key}' is not defined in '${envFilePath}'. Please check your environment configuration.`);
  }
  if (value === '') {
    return;
  }
  return value;
}