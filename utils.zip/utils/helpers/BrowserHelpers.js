import { chromium } from '@playwright/test';
import * as allure from 'allure-js-commons';

export class BrowserHelpers {
    //method to launch the browser and return the page object
    static async launchBrowser() {
        return await allure.step('Launch the browser and create a new page', async () => {
            const headlessFlag = process.env.HEADLESS === 'true';
            const browser = await chromium.launch({ headless: headlessFlag, slowMo: 200, args: ['--start-maximized'] });
            // Create a new context with no cookies or cache (completely fresh)
            const contextOptions = { ignoreHTTPSErrors: true, permissions: ['geolocation', 'notifications', 'local-network-access'] };
            if (!headlessFlag) {
                // viewport:null lets the page use the REAL maximized window size set
                // by the --start-maximized launch arg. A fixed viewport would shrink
                // the window back to that size, so the browser would not look maximized.
                contextOptions.viewport = null;
            }
            const context = await browser.newContext(contextOptions);
            // Ensure context starts fresh (no storage state)
            await context.clearCookies();
            await context.clearPermissions();
            const page = await context.newPage();
            return page;
        });
    }
}