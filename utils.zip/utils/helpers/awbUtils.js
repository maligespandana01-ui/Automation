import { randomNumber } from './random.js';


/* Generate 8-digit AWB (parallel-safe) */
export function generateAwb(workerIndex = 0) {
  const base = randomNumber(6);
  const worker = workerIndex.toString().padStart(2, '0');
  return `${base}${worker}`;
}


