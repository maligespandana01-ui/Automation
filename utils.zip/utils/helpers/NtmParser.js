/**
 * @charset UTF-8
 * NtmParser - Parses an NTM (Notification to Master) text message
 * and extracts structured flight and dangerous goods data for ERR validation.
 *
 * NTM format overview:
 *   Header line:  AA{FLIGHTNUM}/{DATE} {ORIGIN} {SEQ}/{TIMESTAMP}
 *   DNG block:    DNG{DEST}{ORIG}[PC]{CODE}
 *                 {AWB}   U{UNID}   {PCS}/{TI}   /{PG}//{SH}/{CLASS}/{RQ}/
 *                 {PROPER_SHIPPING_NAME}
 *                 OSI/-{BIN}-PPS
 *   End:          LAST
 *
 * Extracts:
 * - Flight number, date, origin, destination
 * - AWB number
 * - Each DG item: UNID, pieces, net quantity / TI, packing group, class,
 *   proper shipping name, bin location
 */
import { Logger } from './Logger.js';

/** Month abbreviation → zero-padded month number */
const MONTH_MAP = {
    JAN: '01', FEB: '02', MAR: '03', APR: '04', MAY: '05', JUN: '06',
    JUL: '07', AUG: '08', SEP: '09', OCT: '10', NOV: '11', DEC: '12',
};

/**
 * Parses NTM (Notification to Master) telex-style text messages.
 */
export class NtmParser {

    /**
     * Parses an NTM text string and returns structured flight and DG data.
     * @param {string} ntmText - Full NTM message text
     * @returns {NtmData}
     */
    static parse(ntmText) {
        const lines = ntmText
            .replace(/\r\n/g, '\n')
            .replace(/\r/g, '\n')
            .split('\n')
            .map(l => l.trim())
            .filter(l => l.length > 0);

        Logger.debug('NtmParser', `Parsing NTM with ${lines.length} non-empty lines`);

        // Find the flight header line — starts with "AA" followed by digits and "/"
        // (the first line may be just "NTM" or other preamble, so scan for the real header)
        const headerLine = lines.find(l => /^AA\d+\/\d{1,2}[A-Z]{3}/i.test(l)) || lines[0] || '';
        const flightInfo = this._parseHeader(headerLine);

        // Extract destination and unit number from first DNG block header
        // Format: DNG{DEST}{UNIT}  e.g. "DNGLGAORDP1725" → dest=LGA, unit=ORDP1725
        for (const line of lines) {
            const dngMatch = line.match(/^DNG([A-Z]{3})(.+)$/);
            if (dngMatch) {
                flightInfo.destination = dngMatch[1];      // e.g., "LGA"
                flightInfo.unitNumber = dngMatch[2].trim(); // e.g., "ORDP1725"
                break;
            }
        }

        // Parse all DG items from DNG blocks
        const dgItems = this._parseDgBlocks(lines);

        Logger.info('NtmParser', `NTM parsed: flight=${flightInfo.flightNumber}, date=${flightInfo.flightDate}, origin=${flightInfo.origin}, dest=${flightInfo.destination}, ${dgItems.length} DG items`);

        return { flightInfo, dgItems };
    }

    /**
     * Parses the NTM header line.
     * Format: AA{FLIGHTNUM}/{DATE} {ORIGIN} {SEQ}/{TIMESTAMP}
     * Example: AA0327/12JUN ORD 1/20260611225813
     * @param {string} headerLine
     * @returns {NtmFlightInfo}
     * @private
     */
    static _parseHeader(headerLine) {
        // e.g. "AA0327/12JUN ORD 1/20260611225813"
        const match = headerLine.match(/^AA(\d+)\/(\d{1,2})([A-Z]{3})\s+([A-Z]{3})/i);

        if (!match) {
            Logger.warn('NtmParser', `Could not parse NTM header: "${headerLine}"`);
            return { flightNumber: '', flightDate: '', origin: '', destination: '', unitNumber: '' };
        }

        const flightNumber = match[1];           // e.g. "0327"
        const day = match[2].padStart(2, '0');  // e.g. "12"
        const monthAbbr = match[3].toUpperCase(); // e.g. "JUN"
        const origin = match[4];                // e.g. "ORD"
        const month = MONTH_MAP[monthAbbr] || '01';

        // Derive year from current year (NTM messages reference current/near-future flights)
        const year = new Date().getFullYear();
        const flightDate = `${month}/${day}/${year}`;

        return { flightNumber, flightDate, origin, destination: '', unitNumber: '' };
    }

    /**
     * Parses all DG item blocks from NTM lines.
     * Each DG block starts with a DNG header line followed by AWB/DG data.
     * @param {string[]} lines
     * @returns {NtmDgItem[]}
     * @private
     */
    static _parseDgBlocks(lines) {
        const items = [];
        let i = 0;

        while (i < lines.length) {
            const line = lines[i];

            // DNG block header. Two known formats:
            //   New (per-ULD):   DNGLHRAKE71846AA  => dest(LHR) + ULD(AKE71846AA)
            //   Legacy:          DNGLGAORDP1725    => dest(LGA) + ULD(ORDP1725)
            // Both are captured by: DNG + 3-letter destination + remaining ULD token.
            const dngMatch = line.match(/^DNG([A-Z]{3})(.+)$/);
            if (dngMatch) {
                const blockDest = dngMatch[1];
                const blockUld = dngMatch[2].trim();
                i++;

                // AWB + DG line. Examples:
                //   001-230022434.1 U1324   1/26K   //III/RFS/3L/N/   (AWB+class concatenated, weight in K)
                //   001-244560407   U2915   4/0.2   /II//RRY/7L/N/    (legacy, TI value)
                const dgLine = lines[i] || '';
                const dgMatch = dgMatch2(dgLine);

                if (dgMatch) {
                    i++;
                    const { awb, unid, pieces, netQty, netQtyUnit, packingGroup, specialHandling, classDivision, rq } = dgMatch;

                    // Next line = proper shipping name
                    const psnLine = lines[i] || '';
                    const isOsi = psnLine.startsWith('OSI/') || psnLine.startsWith('LAST');
                    const properShippingName = isOsi ? '' : psnLine;
                    if (!isOsi) i++;

                    // Next line = OSI/bin line (optional)
                    const osiLine = lines[i] || '';
                    let binLocation = '';
                    if (osiLine.startsWith('OSI/')) {
                        // OSI/-BARROW-2-PPS or OSI/BARROW-2-PPS or OSI/--1-CONFIRMEDFS
                        const osiMatch = osiLine.match(/OSI\/-?([\w-]+)/);
                        binLocation = osiMatch ? osiMatch[1] : osiLine.replace('OSI/', '');
                        i++;
                    }

                    items.push({
                        awb,
                        unid,
                        pieces,
                        netQty,
                        netQtyUnit,
                        packingGroup,
                        classDivision,
                        specialHandling,
                        rq,
                        properShippingName: properShippingName.toUpperCase(),
                        binLocation,
                        uld: blockUld,
                        unitNumber: blockUld,
                        destination: blockDest,
                    });
                } else {
                    // No matching AWB line after DNG header — skip
                    i++;
                }
            } else {
                i++;
            }
        }

        return items;
    }

    /**
     * Groups parsed DG items by their ULD (unit number), preserving first-seen order.
     * Each UI report box corresponds to one ULD group.
     * @param {NtmDgItem[]} dgItems
     * @returns {Array<{uld: string, items: NtmDgItem[]}>}
     */
    static groupByUld(dgItems) {
        const groups = [];
        const index = new Map();
        for (const item of dgItems) {
            const key = item.uld || item.unitNumber || '';
            if (!index.has(key)) {
                index.set(key, groups.length);
                groups.push({ uld: key, items: [] });
            }
            groups[index.get(key)].items.push(item);
        }
        return groups;
    }
}

/**
 * Parses a DG data line from an NTM message block.
 *
 * Supports two AWB encodings:
 *  - New: AWB (001-NNNNNNNN, 8 digits) immediately followed by the class/division,
 *    e.g. "001-230022434.1" => AWB "001-23002243" + class "4.1".
 *  - Legacy: e.g. "001-244560407" => AWB "001-24456040" + class "7".
 *
 * Format: {AWB}{CLASS} U?{UNID} {PCS}/{NETQTY}{UNIT?} /{seg}/{seg}/.../
 * Examples:
 *   001-230022434.1 U1324   1/26K   //III/RFS/3L/N/
 *   001-244560407   U2915   4/0.2   /II//RRY/7L/N/
 *
 * @param {string} line
 * @returns {Object|null} Parsed DG fields or null if no match
 */
function dgMatch2(line) {
    if (!line) return null;

    // AWB(001 + 8 digits) + optional class digits, UNID (opt. U prefix),
    // pieces/netQty (+ optional unit letter e.g. K), then trailing /-segments.
    const match = line.match(
        /^(\d{3}-\d{8})([\d.]*)\s+U?(\d{3,4})\s+(\d+)\/(\d+(?:\.\d+)?)([A-Za-z]*)\s*(.*)$/
    );

    if (!match) return null;

    const awb = match[1];
    const classFromAwb = (match[2] || '').replace(/\.$/, '').trim(); // e.g. "4.1" or "7"
    const unid = `UN${match[3]}`;        // e.g. "UN1324"
    const pieces = match[4];             // e.g. "1"
    const netQty = match[5];             // numeric only, e.g. "26" or "0.2"
    const netQtyUnit = (match[6] || '').toUpperCase(); // "K" (weight) or "" (TI)
    const segments = match[7] || '';     // e.g. "//III/RFS/3L/N/"

    // Packing group: roman numerals I / II / III within the segments.
    const pgMatch = segments.match(/\b(I{1,3})\b/);
    const packingGroup = pgMatch ? pgMatch[1] : '';

    // Reportable quantity: trailing /Y/ or /N/.
    const rqMatch = segments.match(/\/([YN])\/\s*$/i);
    const rq = rqMatch && rqMatch[1].toUpperCase() === 'Y' ? 'Y' : 'N';

    // Class/division: prefer the value concatenated to the AWB (authoritative,
    // matches XSDG/UI, e.g. "4.1", "7"). Fall back to a class-like token in segments.
    let classDivision = classFromAwb;
    if (!classDivision) {
        const clsMatch = segments.match(/\/(\d(?:\.\d)?)[A-Za-z]?\//);
        classDivision = clsMatch ? clsMatch[1] : '';
    }

    // Special handling code: first alphabetic-only segment that is not a PG/RQ token.
    let specialHandling = '';
    const segParts = segments.split('/').map(s => s.trim()).filter(Boolean);
    for (const seg of segParts) {
        if (/^[A-Z]{2,}$/i.test(seg) && !/^I{1,3}$/.test(seg)) {
            specialHandling = seg.toUpperCase();
            break;
        }
    }

    return {
        awb,
        unid,
        pieces,
        netQty,
        netQtyUnit,
        packingGroup,
        specialHandling,
        classDivision,
        rq,
    };
}

/**
 * @typedef {Object} NtmFlightInfo
 * @property {string} flightNumber - Flight number without airline code, e.g. "0327"
 * @property {string} flightDate - Date in MM/DD/YYYY format, e.g. "06/12/2026"
 * @property {string} origin - Origin IATA code, e.g. "ORD"
 * @property {string} destination - Destination IATA code, e.g. "LGA"
 * @property {string} unitNumber - Unit (ULD/cart) number from DNG header, e.g. "ORDP1725"
 */

/**
 * @typedef {Object} NtmDgItem
 * @property {string} awb - Air Waybill number, e.g. "001-23002243"
 * @property {string} unid - UN/ID code, e.g. "UN1324"
 * @property {string} pieces - Number of packages, e.g. "1"
 * @property {string} netQty - Net quantity or transport index (numeric only), e.g. "26" or "0.2"
 * @property {string} netQtyUnit - Net quantity unit, "K" for weight (kg) or "" for transport index
 * @property {string} packingGroup - Packing group, e.g. "III"
 * @property {string} classDivision - Hazard class/division, e.g. "4.1" or "7"
 * @property {string} specialHandling - Special handling code, e.g. "RFS"
 * @property {string} rq - Reportable quantity, "Y" or "N"
 * @property {string} properShippingName - IATA proper shipping name (uppercased)
 * @property {string} binLocation - Bin location from OSI line, e.g. "BARROW-2-PPS"
 * @property {string} uld - ULD/unit number this item belongs to, e.g. "AKE72464AA"
 * @property {string} unitNumber - Alias of uld for convenience
 * @property {string} destination - Destination airport code
 */

/**
 * @typedef {Object} NtmData
 * @property {NtmFlightInfo} flightInfo - Parsed flight header information
 * @property {NtmDgItem[]} dgItems - Array of DG items from NTM blocks
 */
