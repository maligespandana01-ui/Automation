/**
 * @charset UTF-8
 * BinningDbValidator.js - Database validation methods for binning operations
 *
 * Provides methods to query and validate UNITASSIGN, BINASSIGN,
 * SHIPPERFLIGHTINFORMATION, and SHIPPERCHECKLIST tables after binning operations.
 */
import * as allure from 'allure-js-commons';
import { executeQuery } from './database.js';
import { TIMEOUTS } from '../constants/Constants.js';
import { Logger } from './Logger.js';

/**
 * Formats an AWB map or array for SQL IN clause.
 * @param {Object|string[]} awbs - AWB map { '${awb1}': 'actual' } or array ['awb1', 'awb2']
 * @returns {string} SQL IN clause value (e.g., "('12345678','87654321')")
 */
export function formatAwbsForSql(awbs) {
    let awbList;
    if (Array.isArray(awbs)) {
        awbList = awbs;
    } else {
        awbList = Object.values(awbs);
    }
    return `(${awbList.map(a => `'${a}'`).join(',')})`;
}

/**
 * Queries UNITASSIGN table for the given AWBs and returns results.
 * @param {string} awbsSql - SQL IN clause (e.g., "('awb1','awb2')")
 * @param {Object} dbQueries - DB queries object from test data
 * @returns {Promise<Array>}
 */
export async function getUnitAssignData(awbsSql, dbQueries) {
    const query = dbQueries.unitassign_by_awbs.replace('${awbs}', awbsSql);
    try {
        const data = await executeQuery(query, 3, TIMEOUTS.V_SHORT);
        Logger.info('BinningDbValidator', `UNITASSIGN returned ${data.length} rows`);
        return data;
    } catch (error) {
        Logger.error('BinningDbValidator', `UNITASSIGN query failed: ${error.message}`);
        return [];
    }
}

/**
 * Queries BINASSIGN table for the given AWBs and returns results.
 * @param {string} awbsSql - SQL IN clause
 * @param {Object} dbQueries - DB queries object from test data
 * @returns {Promise<Array>}
 */
export async function getBinAssignData(awbsSql, dbQueries) {
    const query = dbQueries.binassign_by_awbs.replace('${awbs}', awbsSql);
    try {
        const data = await executeQuery(query, 3, TIMEOUTS.V_SHORT);
        Logger.info('BinningDbValidator', `BINASSIGN returned ${data.length} rows`);
        return data;
    } catch (error) {
        Logger.error('BinningDbValidator', `BINASSIGN query failed: ${error.message}`);
        return [];
    }
}

/**
 * Queries SHIPPERFLIGHTINFORMATION table for the given AWBs.
 * @param {string} awbsSql - SQL IN clause
 * @param {Object} dbQueries - DB queries object from test data
 * @returns {Promise<Array>}
 */
export async function getShipperFlightInfo(awbsSql, dbQueries) {
    const query = dbQueries.sfi_by_awbs.replace('${awbs}', awbsSql);
    try {
        const data = await executeQuery(query, 3, TIMEOUTS.V_SHORT);
        Logger.info('BinningDbValidator', `SHIPPERFLIGHTINFORMATION returned ${data.length} rows`);
        return data;
    } catch (error) {
        Logger.error('BinningDbValidator', `SFI query failed: ${error.message}`);
        return [];
    }
}

/**
 * Queries audit tables (NTM and XSDG) for the given AWBs.
 * @param {string} awbsSql - SQL IN clause
 * @param {Object} dbQueries - DB queries object from test data
 * @returns {Promise<{ ntmAudit: Array, xsdgAudit: Array }>}
 */
export async function getAuditData(awbsSql, dbQueries) {
    const ntmQuery = dbQueries.audit_ntm_by_awbs.replace('${awbs}', awbsSql);
    const xsdgQuery = dbQueries.audit_xsdg_by_awbs.replace('${awbs}', awbsSql);
    let ntmAudit = [], xsdgAudit = [];
    try {
        ntmAudit = await executeQuery(ntmQuery, 3, TIMEOUTS.V_SHORT);
    } catch (e) { Logger.warn('BinningDbValidator', `NTM audit query failed: ${e.message}`); }
    try {
        xsdgAudit = await executeQuery(xsdgQuery, 3, TIMEOUTS.V_SHORT);
    } catch (e) { Logger.warn('BinningDbValidator', `XSDG audit query failed: ${e.message}`); }
    return { ntmAudit, xsdgAudit };
}

/**
 * Safely gets a column value from a DB row (handles lowercase/uppercase).
 * @param {Object} row - DB result row
 * @param {string} col - Column name (e.g., 'binlocation')
 * @returns {string}
 */
function getCol(row, col) {
    return String(row[col.toLowerCase()] ?? row[col.toUpperCase()] ?? '');
}

/**
 * Validates UNITASSIGN data against expected values and returns assertion results.
 * @param {Array} dbData - UNITASSIGN query results
 * @param {Object} expected - Expected values
 * @param {string} expected.awb - AWB number
 * @param {string} [expected.unitAssigned] - Expected unit assigned value
 * @param {string} [expected.totalPcs] - Expected total pieces
 * @param {string} [expected.classDiv] - Expected class/division
 * @returns {Array<{field: string, expected: string, actual: string, match: boolean}>}
 */
export function validateUnitAssign(dbData, expected) {
    const results = [];
    const matchingRows = dbData.filter(r => getCol(r, 'awbnum') === expected.awb);

    if (matchingRows.length === 0) {
        results.push({ field: 'UNITASSIGN_RECORD', expected: 'exists', actual: 'NOT FOUND', match: false });
        return results;
    }

    const row = matchingRows[0];
    if (expected.unitAssigned) {
        const actual = getCol(row, 'unitassigned');
        results.push({ field: 'unitassigned', expected: expected.unitAssigned, actual, match: actual === expected.unitAssigned });
    }
    if (expected.totalPcs) {
        const actual = getCol(row, 'totalpcs');
        results.push({ field: 'totalpcs', expected: expected.totalPcs, actual, match: actual === expected.totalPcs });
    }
    if (expected.classDiv) {
        const actual = getCol(row, 'displayedclassdiv');
        results.push({ field: 'displayedclassdiv', expected: expected.classDiv, actual, match: actual === expected.classDiv });
    }
    return results;
}

/**
 * Validates BINASSIGN data against expected values after a binning operation.
 * @param {Array} dbData - BINASSIGN query results
 * @param {Object} expected - Expected values
 * @param {string} expected.awb - AWB number
 * @param {string} [expected.binLocation] - Expected bin location
 * @param {string} [expected.splitFlag] - Expected split flag ('Y' or 'N')
 * @param {string} [expected.binStatus] - Expected bin status
 * @param {string} [expected.piecesinbin] - Expected pieces in bin
 * @returns {Array<{field: string, expected: string, actual: string, match: boolean}>}
 */
export function validateBinAssign(dbData, expected) {
    const results = [];
    const matchingRows = dbData.filter(r => getCol(r, 'awbnum') === expected.awb);

    if (matchingRows.length === 0) {
        results.push({ field: 'BINASSIGN_RECORD', expected: 'exists', actual: 'NOT FOUND', match: false });
        return results;
    }

    // If checking specific bin location, find that row
    let row;
    if (expected.binLocation) {
        row = matchingRows.find(r => getCol(r, 'binlocation') === expected.binLocation) || matchingRows[0];
        const actual = getCol(row, 'binlocation');
        results.push({ field: 'binlocation', expected: expected.binLocation, actual, match: actual === expected.binLocation });
    } else {
        row = matchingRows[0];
    }

    if (expected.splitFlag) {
        const actual = getCol(row, 'isunitsplitflag');
        results.push({ field: 'isunitsplitflag', expected: expected.splitFlag, actual, match: actual === expected.splitFlag });
    }
    if (expected.binStatus) {
        const actual = getCol(row, 'binstatus');
        results.push({ field: 'binstatus', expected: expected.binStatus, actual, match: actual === expected.binStatus });
    }
    if (expected.piecesinbin) {
        const actual = getCol(row, 'piecesinbin');
        results.push({ field: 'piecesinbin', expected: expected.piecesinbin, actual, match: actual === expected.piecesinbin });
    }
    return results;
}

/**
 * Validates that a binning deletion was successful in DB.
 * @param {Array} dbData - BINASSIGN query results after deletion
 * @param {string} awb - AWB number
 * @param {string} deletedBinLocation - Bin location that was deleted
 * @returns {Array<{field: string, expected: string, actual: string, match: boolean}>}
 */
export function validateBinDeletion(dbData, awb, deletedBinLocation) {
    const results = [];
    const matchingRows = dbData.filter(r =>
        getCol(r, 'awbnum') === awb && getCol(r, 'binlocation') === deletedBinLocation
    );

    if (matchingRows.length === 0) {
        // No record found — deletion confirmed
        results.push({ field: 'BINASSIGN_DELETED', expected: 'deleted', actual: 'deleted', match: true });
    } else {
        // Record still exists — check if status changed to deleted
        const status = getCol(matchingRows[0], 'binstatus');
        const isDeleted = status.toLowerCase().includes('delet') || matchingRows.length === 0;
        results.push({ field: 'binstatus', expected: 'deleted', actual: status, match: isDeleted });
    }
    return results;
}

/**
 * Validates SHIPPERFLIGHTINFORMATION data.
 * @param {Array} dbData - SFI query results
 * @param {Object} expected - Expected flight values
 * @param {string} expected.awb - AWB number
 * @param {string} [expected.flightNumber] - Expected flight number
 * @param {string} [expected.origin] - Expected leg origin
 * @param {string} [expected.destination] - Expected leg destination
 * @returns {Array<{field: string, expected: string, actual: string, match: boolean}>}
 */
export function validateShipperFlightInfo(dbData, expected) {
    const results = [];
    const matchingRows = dbData.filter(r => getCol(r, 'awbnum') === expected.awb);

    if (matchingRows.length === 0) {
        results.push({ field: 'SFI_RECORD', expected: 'exists', actual: 'NOT FOUND', match: false });
        return results;
    }

    const row = matchingRows[0];
    if (expected.flightNumber) {
        const actual = getCol(row, 'flightnumber').replace(/^0+/, '');
        results.push({ field: 'flightnumber', expected: expected.flightNumber, actual, match: actual === expected.flightNumber });
    }
    if (expected.origin) {
        const actual = getCol(row, 'legorigin');
        results.push({ field: 'legorigin', expected: expected.origin, actual, match: actual === expected.origin });
    }
    if (expected.destination) {
        const actual = getCol(row, 'legdestination');
        results.push({ field: 'legdestination', expected: expected.destination, actual, match: actual === expected.destination });
    }
    return results;
}

/**
 * Cross-validates UI assignment table data against DB UNITASSIGN data.
 * @param {Array<Object>} uiTableData - UI table data from getAssignmentTableData()
 * @param {Array<Object>} dbUnitData - UNITASSIGN query results
 * @returns {Array<{field: string, uiValue: string, dbValue: string, match: boolean}>}
 */
export function crossValidateUiVsDb(uiTableData, dbUnitData) {
    const results = [];

    for (const uiRow of uiTableData) {
        // Find matching DB row by unit ID
        const dbRow = dbUnitData.find(r => {
            const dbUnit = getCol(r, 'unitassigned');
            return dbUnit === uiRow.unitId || dbUnit.includes(uiRow.unitId);
        });

        if (!dbRow) {
            results.push({ field: `unit_${uiRow.unitId}`, uiValue: 'present', dbValue: 'NOT FOUND', match: false });
            continue;
        }

        // Compare key fields
        const comparisons = [
            { field: 'totalPcs', ui: uiRow.totalPcs, db: getCol(dbRow, 'totalpcs') },
            { field: 'totalWt', ui: uiRow.totalWt, db: getCol(dbRow, 'totalweight') },
            { field: 'classDiv', ui: uiRow.classDiv, db: getCol(dbRow, 'displayedclassdiv') },
            { field: 'unit', ui: uiRow.unit, db: getCol(dbRow, 'displayedunit') },
        ];

        for (const c of comparisons) {
            results.push({
                field: `${uiRow.unitId}.${c.field}`,
                uiValue: c.ui,
                dbValue: c.db,
                match: c.ui.trim() === c.db.trim(),
            });
        }
    }
    return results;
}

/**
 * Runs all DB validations and attaches results to Allure report.
 * @param {string} awbsSql - SQL IN clause for AWBs
 * @param {Object} dbQueries - DB queries from test data
 * @param {Object} expected - Expected values for assertions
 * @param {import('@playwright/test').expect} expect - Playwright expect
 * @returns {Promise<Object>} All DB data { unitAssign, binAssign, sfi, audit }
 */
export async function runFullDbValidation(awbsSql, dbQueries, expected, expect) {
    const unitAssign = await getUnitAssignData(awbsSql, dbQueries);
    const binAssign = await getBinAssignData(awbsSql, dbQueries);
    const sfi = await getShipperFlightInfo(awbsSql, dbQueries);
    const audit = await getAuditData(awbsSql, dbQueries);

    await allure.attachment('DB - UNITASSIGN', JSON.stringify(unitAssign, null, 2), 'application/json');
    await allure.attachment('DB - BINASSIGN', JSON.stringify(binAssign, null, 2), 'application/json');
    await allure.attachment('DB - SHIPPERFLIGHTINFORMATION', JSON.stringify(sfi, null, 2), 'application/json');
    await allure.attachment('DB - AUDIT NTM', JSON.stringify(audit.ntmAudit, null, 2), 'application/json');
    await allure.attachment('DB - AUDIT XSDG', JSON.stringify(audit.xsdgAudit, null, 2), 'application/json');

    // Run validations
    if (expected.awb) {
        const uaResults = validateUnitAssign(unitAssign, expected);
        const sfiResults = validateShipperFlightInfo(sfi, expected);
        await allure.attachment('Validation - UNITASSIGN', JSON.stringify(uaResults, null, 2), 'application/json');
        await allure.attachment('Validation - SFI', JSON.stringify(sfiResults, null, 2), 'application/json');

        for (const r of uaResults) {
            expect.soft(r.match, `UNITASSIGN ${r.field}: expected=${r.expected}, actual=${r.actual}`).toBe(true);
        }
        for (const r of sfiResults) {
            expect.soft(r.match, `SFI ${r.field}: expected=${r.expected}, actual=${r.actual}`).toBe(true);
        }
    }

    if (expected.binLocation || expected.splitFlag) {
        const baResults = validateBinAssign(binAssign, expected);
        await allure.attachment('Validation - BINASSIGN', JSON.stringify(baResults, null, 2), 'application/json');
        for (const r of baResults) {
            expect.soft(r.match, `BINASSIGN ${r.field}: expected=${r.expected}, actual=${r.actual}`).toBe(true);
        }
    }

    return { unitAssign, binAssign, sfi, audit };
}
