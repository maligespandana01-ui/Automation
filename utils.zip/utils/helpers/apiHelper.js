/**
 * @charset UTF-8
 * API Helper - Generic HTTP request and test execution utilities
 */
import { expect } from '@playwright/test';
import { HTTP_METHODS, ENV_CONFIG_KEYS } from '../constants/Constants.js';
import { ReportHelper } from './ReportHelper.js';
import { getEnvVariable } from '../config/EnvLoader.js';
import * as allure from 'allure-js-commons';

// Builds a complete URL from base URL and endpoint
export const buildUrl = (baseUrl, endpoint) =>
    `${baseUrl.replace(/\/$/, '')}/${endpoint.replace(/^\//, '')}`;

/**
 * Generic HTTP request executor
 */
export const httpRequest = async (request, { method = HTTP_METHODS.POST, url, headers = {}, body = null, timeout = 60000 }) => {
    if (!url) throw new Error('URL is required');
    if (!Object.values(HTTP_METHODS).includes(method)) throw new Error(`Invalid HTTP method: ${method}`);
    return request[method](url, { headers, data: body, timeout });
};

/**
 * Reusable API test executor with comprehensive Allure reporting
 */
export const runAPITest = async ({ apiName, testData, requestFn, endpoint, isQueryParams = false }) => {
    const { Test_ID, Scenario, ['Expected Status']: statusStr, ['Expected Response']: expectedResponse } = testData;
    const expectedStatus = parseInt(statusStr);

    await allure.displayName(`${Test_ID} - ${Scenario}`);
    await allure.severity('critical');
    await allure.description(`${apiName}: ${Scenario}`);

    const response = await allure.step(`Send request to ${apiName}`, requestFn);
    const actualStatus = response.status();
    const actualBody = await response.text();

    const requestData = isQueryParams
        ? { data: testData.Query_Params || '', isQueryParams: true }
        : { data: testData.RequestBody ? JSON.parse(testData.RequestBody) : {}, isQueryParams: false };

    await allure.step('TestCase Execution', async () => {
        await ReportHelper.validateResponse(expectedStatus, actualStatus, expectedResponse, actualBody,
            { Test_ID, baseUrl: getEnvVariable(ENV_CONFIG_KEYS.URL_OPSHUB), endpoint, requestData });
        if (expectedStatus >= 200 && expectedStatus < 300) expect(response.ok()).toBe(true);
    });
};


