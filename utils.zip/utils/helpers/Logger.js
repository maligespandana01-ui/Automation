/**
 * @charset UTF-8
 * Logger - Structured logging utility with component tagging for
 * debug-friendly failure analysis across API, UI, and DB layers.
 *
 * Controlled by DEBUG env variable. Info/error always log.
 * Debug logs only appear when DEBUG=true.
 */
export class Logger {
    /**
     * Formats a structured log message.
     * @param {string} level - Log level (INFO, ERROR, DEBUG, WARN)
     * @param {string} component - Component name (e.g., 'FlightDataService', 'BinAssignPage', 'DbValidator')
     * @param {string} message - Log message
     * @param {Object} [data] - Optional structured data to include
     * @returns {string} Formatted log string
     * @private
     */
    static _format(level, component, message, data) {
        const ts = new Date().toISOString();
        const base = `[${ts}] [${level}] [${component}] ${message}`;
        return data ? `${base} | ${JSON.stringify(data)}` : base;
    }

    /**
     * Logs an informational message.
     * @param {string} component - Source component name
     * @param {string} message - Log message
     * @param {Object} [data] - Optional structured data
     */
    static info(component, message, data) {
        console.log(this._format('INFO', component, message, data));
    }

    /**
     * Logs a warning message.
     * @param {string} component - Source component name
     * @param {string} message - Log message
     * @param {Object} [data] - Optional structured data
     */
    static warn(component, message, data) {
        console.warn(this._format('WARN', component, message, data));
    }

    /**
     * Logs an error message.
     * @param {string} component - Source component name
     * @param {string} message - Log message
     * @param {Object} [data] - Optional structured data (e.g., error stack)
     */
    static error(component, message, data) {
        console.error(this._format('ERROR', component, message, data));
    }

    /**
     * Logs a debug message. Only outputs when DEBUG=true in environment.
     * @param {string} component - Source component name
     * @param {string} message - Log message
     * @param {Object} [data] - Optional structured data
     */
    static debug(component, message, data) {
        if (process.env.DEBUG === 'true') {
            console.log(this._format('DEBUG', component, message, data));
        }
    }

    /**
     * Logs test step execution for traceability.
     * @param {string} testName - Test case name
     * @param {string} stepName - Step description
     * @param {Object} [data] - Optional context data
     */
    static step(testName, stepName, data) {
        console.log(this._format('STEP', testName, stepName, data));
    }
}
