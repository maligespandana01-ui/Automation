/* ================= INTERPOLATE OPERATION - SUBSTITUTE PLACEHOLDER STRING WITH ACTUAL VALUES ================= */
export function substitutePlaceholders(template, ...placeholderParams) {
  if (typeof template !== 'string') {
    throw new TypeError(`substitutePlaceholders: template must be a string, got ${typeof template}`);
  }
  return template.replace(/\$(\d+)/g, (match, n) => {
    const idx = parseInt(n, 10) - 1;
    return idx >= 0 && idx < placeholderParams.length ? placeholderParams[idx] : match;
  });
}