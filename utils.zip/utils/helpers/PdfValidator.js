/**
 * @charset UTF-8
 * PdfValidator - Extracts and validates content from downloaded PDF files.
 *
 * Uses pdf-parse to extract text from PDF files and provides structured
 * validation methods for Emergency Response Report PDF content.
 */
import fs from 'fs';
import { PDFParse } from 'pdf-parse';
import * as allure from 'allure-js-commons';
import { VALIDATION_STATUS } from '../constants/Constants.js';
import { Logger } from './Logger.js';

export class PdfValidator {

    /**
     * Extracts text content from a PDF file.
     * @param {string} filePath - Absolute path to the PDF file
     * @returns {Promise<string>} Extracted text content
     */
    static async extractText(filePath) {
        return allure.step(`Extract text from PDF: ${filePath}`, async () => {
            if (!fs.existsSync(filePath)) {
                throw new Error(`PDF file not found: ${filePath}`);
            }
            const buffer = fs.readFileSync(filePath);
            const parser = new PDFParse({ data: new Uint8Array(buffer) });
            const result = await parser.getText();
            const text = result.text;
            Logger.info('PdfValidator', `PDF parsed: ${result.total} pages, ${text.length} chars`);
            await allure.attachment('PDF Raw Text', text, 'text/plain');
            await parser.destroy();
            return text;
        });
    }

    /**
     * Validates the Emergency Response Report PDF content against expected report data.
     * @param {string} filePath - Path to the downloaded PDF file
     * @param {Object} expectedData - Expected report data from UI or DB
     * @param {Object} expectedData.flightInfo - { flightNumber, date, from, to }
     * @param {Array}  expectedData.hazmatRows - Array of hazmat detail objects
     * @param {Object} expectedData.verificationInfo - { verifiedByName, verifiedByEmpNum }
     * @param {string} expectedData.binLocation - Expected bin location
     * @param {string} expectedData.unitNumber - Expected unit number
     * @returns {Promise<{ results: Array, allPassed: boolean, pdfText: string }>}
     */
    static async validateEmergencyResponsePdf(filePath, expectedData) {
        return allure.step('Validate Emergency Response Report PDF content', async () => {
            const pdfText = await this.extractText(filePath);
            const results = [];

            // Validate report title
            results.push(this._containsCheck('reportTitle', pdfText, 'EMERGENCY RESPONSE REPORT'));
            results.push(this._containsCheck('reportSubtitle', pdfText, 'DANGEROUS GOODS'));

            // Validate flight info
            if (expectedData.flightInfo) {
                const fi = expectedData.flightInfo;
                if (fi.flightNumber) results.push(this._containsCheck('pdf.flightNumber', pdfText, fi.flightNumber));
                if (fi.date) results.push(this._containsCheck('pdf.date', pdfText, fi.date));
                if (fi.from) results.push(this._containsCheck('pdf.from', pdfText, fi.from));
                if (fi.to) results.push(this._containsCheck('pdf.to', pdfText, fi.to));
            }

            // Validate unit number
            if (expectedData.unitNumber) {
                results.push(this._containsCheck('pdf.unitNumber', pdfText, expectedData.unitNumber));
            }

            // Validate bin location
            if (expectedData.binLocation) {
                results.push(this._containsCheck('pdf.binLocation', pdfText, expectedData.binLocation));
            }

            // Validate hazmat rows
            if (expectedData.hazmatRows?.length) {
                for (let i = 0; i < expectedData.hazmatRows.length; i++) {
                    const row = expectedData.hazmatRows[i];
                    if (row.properShippingName) {
                        results.push(this._containsCheck(
                            `pdf.hazmatRow[${i}].properShippingName`,
                            pdfText, row.properShippingName
                        ));
                    }
                    if (row.unIdNumber) {
                        results.push(this._containsCheck(
                            `pdf.hazmatRow[${i}].unIdNumber`,
                            pdfText, row.unIdNumber
                        ));
                    }
                    if (row.classDivision) {
                        results.push(this._containsCheck(
                            `pdf.hazmatRow[${i}].classDivision`,
                            pdfText, row.classDivision
                        ));
                    }
                }
            }

            // Validate verification info
            if (expectedData.verificationInfo) {
                const vi = expectedData.verificationInfo;
                if (vi.verifiedByName) {
                    results.push(this._containsCheck('pdf.verifiedByName', pdfText, vi.verifiedByName));
                }
                if (vi.verifiedByEmpNum) {
                    results.push(this._containsCheck('pdf.verifiedByEmpNum', pdfText, vi.verifiedByEmpNum));
                }
            }

            // Validate emergency contact info
            results.push(this._containsCheck('pdf.emergencyContactDomestic', pdfText, '1-866-519-4752'));
            results.push(this._containsCheck('pdf.emergencyContactIntl', pdfText, '1-760-476-3962'));

            // Validate end of report marker
            results.push(this._containsCheck('pdf.endOfReport', pdfText, 'End of Emergency Response Report'));

            const allPassed = results.every(r => r.status === VALIDATION_STATUS.PASS);

            await allure.attachment('PDF Validation Results',
                JSON.stringify(results, null, 2), 'application/json');
            await allure.attachment('PDF Validation Summary HTML',
                this._generateHtmlReport(results), 'text/html');

            Logger.info('PdfValidator', `PDF validation: ${allPassed ? 'ALL PASSED' : 'FAILURES DETECTED'}`,
                { total: results.length, passed: results.filter(r => r.status === VALIDATION_STATUS.PASS).length });

            return { results, allPassed, pdfText };
        });
    }

    /**
     * Validates that PDF text contains an expected value (case-insensitive).
     * @param {string} field - Field name for reporting
     * @param {string} pdfText - Full PDF text content
     * @param {string} expected - Expected text to find in PDF
     * @returns {Object} Validation result
     * @private
     */
    static _containsCheck(field, pdfText, expected) {
        // Normalize whitespace (newlines, multiple spaces) for PDF text that may have line breaks
        const normalizedPdf = pdfText.replace(/\s+/g, ' ').toLowerCase();
        const normalizedExpected = expected.replace(/\s+/g, ' ').toLowerCase();
        const found = normalizedPdf.includes(normalizedExpected);
        return {
            field,
            expected,
            actual: found ? `Found in PDF` : `NOT found in PDF`,
            status: found ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL,
        };
    }

    /**
     * Generates an HTML report for PDF validation results.
     * @param {Array} results - Validation results
     * @returns {string} HTML content
     * @private
     */
    static _generateHtmlReport(results) {
        const passed = results.filter(r => r.status === VALIDATION_STATUS.PASS).length;
        const failed = results.filter(r => r.status === VALIDATION_STATUS.FAIL).length;

        const rows = results.map(r => {
            const cls = r.status === VALIDATION_STATUS.PASS ? 'pass' : 'fail';
            return `<tr class="${cls}"><td>${r.field}</td><td><code>${r.expected}</code></td><td>${r.actual}</td><td>${r.status}</td></tr>`;
        }).join('');

        return `<!DOCTYPE html><html><head><meta charset="UTF-8">
<style>body{font-family:Arial;margin:20px}table{width:100%;border-collapse:collapse}
th,td{border:1px solid #ddd;padding:8px}th{background:#1976d2;color:#fff}
.pass{background:#e8f5e9;color:#2e7d32}.fail{background:#ffebee;color:#c62828}</style>
</head><body>
<h2>Emergency Response Report - PDF Validation</h2>
<p><b>Total:</b> ${results.length} | <span style="color:green"><b>Passed:</b> ${passed}</span> | <span style="color:red"><b>Failed:</b> ${failed}</span></p>
<table><tr><th>Field</th><th>Expected</th><th>Actual</th><th>Status</th></tr>${rows}</table>
</body></html>`;
    }

    /**
     * Cleans up a downloaded PDF file after validation.
     * @param {string} filePath - Path to the PDF file to delete
     */
    static cleanup(filePath) {
        try {
            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
                Logger.info('PdfValidator', `Cleaned up PDF: ${filePath}`);
            }
        } catch (error) {
            Logger.warn('PdfValidator', `Failed to clean up PDF: ${error.message}`);
        }
    }
}
