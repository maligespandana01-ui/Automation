/**
 * @charset UTF-8
 * DbValidator - Reusable cross-layer validation utility that compares
 * expected data (from API/UI) against database records.
 *
 * Wraps the existing executeQuery() from database.js with structured
 * comparison logic and Allure reporting.
 */
import { executeQuery } from './database.js';
import { VALIDATION_STATUS, DEFAULT_VALUES, ENV_CONFIG_KEYS } from '../constants/Constants.js';
import * as allure from 'allure-js-commons';

export class DbValidator {
    /**
     * Executes a query and validates expected values against the first returned row.
     * @param {string} query - SQL query string
     * @param {Object} expected - Map of { fieldName: expectedValue }
     * @param {Object} [options]
     * @param {number} [options.retries=3] - Number of retry attempts
     * @param {number} [options.interval=2000] - Delay between retries in ms
     * @returns {Promise<{ results: Array, allPassed: boolean, rows: Array }>}
     */
    static async validate(query, expected, options = {}) {
        const { retries = 3, interval = 2000 } = options;

        return allure.step('DB Validation', async () => {
            await allure.attachment('SQL Query', query, 'text/plain');
            await allure.attachment('Expected Values',
                JSON.stringify(expected, null, 2), 'application/json');

            const rows = await executeQuery(query, retries, interval);

            if (!rows?.length) {
                await allure.attachment('DB Validation Result',
                    'No rows returned from query', 'text/plain');
                return { results: [], allPassed: false, rows: [] };
            }

            const dbRecord = rows[0];
            await allure.attachment('DB Record',
                JSON.stringify(dbRecord, null, 2), 'application/json');

            const results = Object.entries(expected).map(([field, expectedVal]) => {
                // Try exact field name, then lowercase, then uppercase
                const actualVal = dbRecord[field]
                    ?? dbRecord[field.toLowerCase()]
                    ?? dbRecord[field.toUpperCase()];

                const expectedStr = String(expectedVal ?? '');
                const actualStr = String(actualVal ?? DEFAULT_VALUES.NOT_FOUND);

                return {
                    field,
                    expected: expectedStr,
                    actual: actualStr,
                    status: expectedStr === actualStr
                        ? VALIDATION_STATUS.PASS
                        : VALIDATION_STATUS.FAIL,
                };
            });

            const allPassed = results.every(r => r.status === VALIDATION_STATUS.PASS);

            await allure.attachment('Validation Results',
                JSON.stringify(results, null, 2), 'application/json');
            await allure.attachment('Validation Summary',
                this._generateHtmlReport(results), 'text/html');

            return { results, allPassed, rows };
        });
    }

    /**
     * Validates multiple rows against expected arrays.
     * Useful for validating bin assignments or unit assigns that return multiple rows.
     * @param {string} query - SQL query string
     * @param {Array<Object>} expectedRows - Array of expected row objects
     * @param {string} matchKey - Field to match expected rows to DB rows (e.g., 'awbnum')
     * @param {Object} [options] - Same as validate()
     * @returns {Promise<{ results: Array, allPassed: boolean, rows: Array }>}
     */
    static async validateMultipleRows(query, expectedRows, matchKey, options = {}) {
        const { retries = 3, interval = 2000 } = options;

        return allure.step('DB Multi-Row Validation', async () => {
            const rows = await executeQuery(query, retries, interval);

            if (!rows?.length) {
                return { results: [], allPassed: false, rows: [] };
            }

            const allResults = [];
            for (const expected of expectedRows) {
                const matchValue = expected[matchKey];
                const dbRow = rows.find(r =>
                    String(r[matchKey] ?? r[matchKey.toLowerCase()] ?? r[matchKey.toUpperCase()])
                    === String(matchValue)
                );

                if (!dbRow) {
                    allResults.push({
                        field: matchKey,
                        expected: matchValue,
                        actual: DEFAULT_VALUES.NOT_FOUND,
                        status: VALIDATION_STATUS.FAIL,
                    });
                    continue;
                }

                const rowResults = Object.entries(expected).map(([field, expectedVal]) => {
                    const actualVal = dbRow[field]
                        ?? dbRow[field.toLowerCase()]
                        ?? dbRow[field.toUpperCase()];
                    return {
                        field: `${matchValue}.${field}`,
                        expected: String(expectedVal ?? ''),
                        actual: String(actualVal ?? DEFAULT_VALUES.NOT_FOUND),
                        status: String(expectedVal) === String(actualVal)
                            ? VALIDATION_STATUS.PASS
                            : VALIDATION_STATUS.FAIL,
                    };
                });
                allResults.push(...rowResults);
            }

            const allPassed = allResults.every(r => r.status === VALIDATION_STATUS.PASS);

            await allure.attachment('Multi-Row Validation Results',
                JSON.stringify(allResults, null, 2), 'application/json');

            return { results: allResults, allPassed, rows };
        });
    }

    /**
     * Generates an HTML validation report for Allure attachment.
     * @param {Array<{field: string, expected: string, actual: string, status: string}>} results
     * @returns {string} HTML string
     * @private
     */
    static _generateHtmlReport(results) {
        const passed = results.filter(r => r.status === VALIDATION_STATUS.PASS).length;
        const failed = results.filter(r => r.status === VALIDATION_STATUS.FAIL).length;

        const rows = results.map(r => {
            const cls = r.status === VALIDATION_STATUS.PASS ? 'pass' : 'fail';
            return `<tr class="${cls}"><td><b>${r.field}</b></td><td><code>${r.expected}</code></td><td><code>${r.actual}</code></td><td style="text-align:center"><b>${r.status}</b></td></tr>`;
        }).join('');

        return `<!DOCTYPE html><html><head><meta charset="UTF-8"><style>body{font-family:Arial;margin:20px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ddd;padding:8px}th{background:#1976d2;color:#fff}.pass{background:#e8f5e9;color:#2e7d32}.fail{background:#ffebee;color:#c62828}</style></head><body><h3>DB Validation Report</h3><p><b>Total:</b> ${results.length} | <span style="color:#2e7d32"><b>Passed:</b> ${passed}</span> | <span style="color:#c62828"><b>Failed:</b> ${failed}</span></p><table><tr><th>Field</th><th>Expected</th><th>Actual</th><th>Status</th></tr>${rows}</table></body></html>`;
    }
}
