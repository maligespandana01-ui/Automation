/**
 * @charset UTF-8
 * XsdgParser - Parses an XSDG (Shipper's Declaration for Dangerous Goods) XML file
 * and extracts structured data for Emergency Response Report validation.
 *
 * Extracts:
 * - AWB number, shipper, consignee, origin, destination
 * - Each hazmat DG line item: UNID, proper shipping name, class, packing group,
 *   transport index, number of pieces
 * - Emergency contact information
 *
 * Depends on: fast-xml-parser (npm install fast-xml-parser --save)
 */
import { XMLParser } from 'fast-xml-parser';
import fs from 'fs';
import { Logger } from './Logger.js';

/**
 * Parses XSDG XML files following the IATA Shipper's Declaration schema.
 */
export class XsdgParser {

    /**
     * Parses an XSDG XML file and returns structured data.
     * @param {string} xmlFilePath - Absolute or relative path to the XSDG XML file
     * @returns {XsdgData} Structured XSDG data object
     */
    static parse(xmlFilePath) {
        if (!fs.existsSync(xmlFilePath)) {
            throw new Error(`XSDG file not found: ${xmlFilePath}`);
        }

        const xml = fs.readFileSync(xmlFilePath, 'utf8');
        return this.parseXml(xml);
    }

    /**
     * Parses an XSDG XML string and returns structured data. Useful when the XML
     * content is obtained from a non-file source or needs pre-sanitisation
     * (e.g. stripping export wrapper characters) before parsing.
     * @param {string} xml - Raw XSDG XML content
     * @returns {XsdgData} Structured XSDG data object
     */
    static parseXml(xml) {
        const parser = new XMLParser({
            ignoreAttributes: false,
            attributeNamePrefix: '@_',
            removeNSPrefix: true,          // strips ns2: prefixes
            parseTagValue: false,          // keep values as strings (preserves leading zeros e.g. "00797971")
            isArray: (name) => [
                'IncludedHouseConsignment',
                'IncludedCommercialTradeLineItem',
                'SpecifiedLogisticsPackage',
                'IncludedPackagedTradeLineItem',
                'SenderParty',
                'RecipientParty',
            ].includes(name),
        });

        const parsed = parser.parse(xml);
        Logger.debug('XsdgParser', 'Parsed XSDG XML', { keys: Object.keys(parsed) });

        return this._extract(parsed);
    }

    /**
     * Extracts structured data from the parsed XML object.
     * @param {Object} parsed - Object returned by fast-xml-parser
     * @returns {XsdgData}
     * @private
     */
    static _extract(parsed) {
        const root = parsed?.ShippersDeclarationForDangerousGoods;
        if (!root) {
            throw new Error('XSDG XML is missing root ShippersDeclarationForDangerousGoods element');
        }

        const consignments = root?.MasterConsignment?.IncludedHouseConsignment || [];
        if (!consignments.length) {
            throw new Error('XSDG XML has no IncludedHouseConsignment elements');
        }

        // Merge all house consignments (usually one per XSDG file)
        const allDgItems = [];
        let awbNumber = '';
        let shipperName = '';
        let consigneeName = '';
        let origin = '';
        let destination = '';
        let emergencyContact = '';
        let emergencyPhone = '';
        let aircraftLimitation = '';
        let specialHandlingInfo = '';

        // Verified-by (declarant authentication) lives in the BusinessHeaderDocument
        let verifiedByName = '';
        let verifiedByEmpNum = '';
        const declarantAuth = root?.BusinessHeaderDocument?.SignatoryDeclarantAuthentication;
        const authContact = declarantAuth?.ProviderAuthenticationParty?.DefinedTradeContact;
        if (authContact) {
            verifiedByName = authContact?.PersonName || '';
            verifiedByEmpNum = authContact?.JobTitle != null ? String(authContact.JobTitle) : '';
        }

        for (const consignment of consignments) {
            // AWB
            const awbDoc = consignment?.AssociatedReferenceDocument;
            const awbArr = Array.isArray(awbDoc) ? awbDoc : awbDoc ? [awbDoc] : [];
            const awbEntry = awbArr.find(d => d?.Name === 'Air Waybill') || awbArr[0];
            if (awbEntry?.ID && !awbNumber) awbNumber = String(awbEntry.ID);

            // Shipper / Consignee
            if (!shipperName) shipperName = consignment?.ConsignorParty?.Name || '';
            if (!consigneeName) consigneeName = consignment?.ConsigneeParty?.Name || '';

            // Origin / Destination
            if (!origin) origin = consignment?.OriginLocation?.ID || '';
            if (!destination) destination = consignment?.FinalDestinationLocation?.ID || '';

            // Special handling info - only populated if XSDG carries a textual handling value.
            // ExclusiveUsageIndicator (a boolean flag) is NOT a special-handling instruction.
            if (!specialHandlingInfo) {
                const handling = consignment?.HandlingInstructions;
                if (handling) {
                    const candidate = handling?.Description
                        ?? handling?.DescriptionCode
                        ?? handling?.HandlingSpecialServiceCode
                        ?? handling?.SpecialServiceInstructions
                        ?? '';
                    specialHandlingInfo = candidate ? String(candidate).trim() : '';
                }
            }

            // Hazmat line items and packages are both inside RelatedCommercialTradeTransaction
            const transaction = consignment?.RelatedCommercialTradeTransaction;
            let lineItems = transaction?.IncludedCommercialTradeLineItem || [];
            if (!Array.isArray(lineItems)) lineItems = [lineItems];

            // Package quantities indexed by sequence number (also inside transaction)
            let packages = transaction?.SpecifiedLogisticsPackage || [];
            if (!Array.isArray(packages)) packages = [packages];

            const piecesBySeq = {};
            const dimensionsBySeq = {};
            for (const pkg of packages) {
                const qty = pkg?.ItemQuantity;
                const seqItems = pkg?.IncludedPackagedTradeLineItem || [];
                const seqArr = Array.isArray(seqItems) ? seqItems : [seqItems];
                for (const si of seqArr) {
                    const seq = String(si?.SequenceNumeric);
                    if (seq) {
                        piecesBySeq[seq] = qty != null ? String(qty) : '';
                        const dim = pkg?.LinearSpatialDimension;
                        if (dim) {
                            dimensionsBySeq[seq] = {
                                width: dim?.WidthMeasure?.['#text'] ?? dim?.WidthMeasure ?? '',
                                length: dim?.LengthMeasure?.['#text'] ?? dim?.LengthMeasure ?? '',
                                height: dim?.HeightMeasure?.['#text'] ?? dim?.HeightMeasure ?? '',
                            };
                        }
                    }
                }
            }

            // Emergency contact
            const transportDG = consignment?.ApplicableTransportDangerousGoods;
            if (transportDG && !emergencyContact) {
                aircraftLimitation = transportDG?.AircraftLimitationInformation || '';
                const contact = transportDG?.EmergencyDangerousGoodsContact;
                if (contact) {
                    emergencyContact = contact?.PersonName || '';
                    emergencyPhone = contact?.DirectTelephoneCommunication?.CompleteNumber || '';
                }
            }

            // Build DG item list
            for (const item of lineItems) {
                const seq = String(item?.SequenceNumeric || '');
                const dg = item
                    ?.SpecifiedProductTradeDelivery
                    ?.SpecifiedProductRegulatedGoods
                    ?.ApplicableProductDangerousGoods;

                if (!dg) continue;

                const rm = dg?.RadioactiveMaterial;
                const packingGroupRaw = rm?.TypeCode || '';
                // "II-YELLOW" → "II", "III-WHITE" → "III"
                const packingGroup = packingGroupRaw ? packingGroupRaw.split('-')[0] : '';
                const transportIndex = rm?.TransportIndexNumeric != null
                    ? String(rm.TransportIndexNumeric)
                    : '';

                // Radioactive isotope details (per line item)
                const isotope = rm?.ApplicableRadioactiveIsotope;
                const radionuclideSymbol = isotope?.ID != null ? String(isotope.ID) : '';
                const activityMeasure = isotope?.ActivityLevelMeasure;
                const activityLevel = activityMeasure != null
                    ? String(activityMeasure?.['#text'] ?? activityMeasure)
                    : '';
                const activityUnit = activityMeasure?.['@_unitCode'] != null
                    ? String(activityMeasure['@_unitCode'])
                    : '';
                // Chemical/physical form has no dedicated XSDG element in this schema;
                // populated only if present, otherwise empty.
                const chemicalPhysicalForm = isotope?.PhysicalChemicalForm
                    ?? isotope?.ChemicalPhysicalForm
                    ?? '';

                allDgItems.push({
                    sequence: seq,
                    unid: dg?.UNDGIdentificationCode || '',           // e.g., "UN2915"
                    properShippingName: dg?.ProperShippingName || '',  // e.g., "Radioactive material, Type A package"
                    classDivision: String(dg?.HazardClassificationID || ''), // e.g., "7"
                    packingGroup,                                       // e.g., "II"
                    reportableQty: dg?.ReportableQuantity || 'N',       // "Y" or "N"
                    transportIndex,                                     // e.g., "0.2" (TI for radioactive)
                    numPcs: piecesBySeq[seq] ?? '',                     // e.g., "4"
                    dimensions: dimensionsBySeq[seq] || null,
                    radionuclideSymbol,                                 // e.g., "I-123"
                    chemicalPhysicalForm: chemicalPhysicalForm ? String(chemicalPhysicalForm).trim() : '',
                    activityLevel,                                      // e.g., "742.25"
                    activityUnit,                                       // e.g., "4N" or "GBQ"
                    radioactiveMaterial: rm ? {
                        typeCode: packingGroupRaw,
                        transportIndex,
                        radionuclideSymbol,
                        activityLevel,
                        activityUnit,
                    } : null,
                });
            }
        }

        /** @type {XsdgData} */
        const result = {
            awbNumber,
            shipperName,
            consigneeName,
            origin,
            destination,
            dgItems: allDgItems,
            emergencyContact,
            emergencyPhone,
            aircraftLimitation,
            specialHandlingInfo,
            verifiedByName,
            verifiedByEmpNum,
            totalPackages: String(allDgItems.reduce((sum, it) => sum + (parseInt(it.numPcs, 10) || 0), 0)),
        };

        Logger.info('XsdgParser', `Parsed XSDG: AWB=${awbNumber}, origin=${origin}, dest=${destination}, ${allDgItems.length} DG items`);
        return result;
    }
}

/**
 * @typedef {Object} XsdgDgItem
 * @property {string} sequence - Line item sequence number (1-based)
 * @property {string} unid - UN/ID number e.g. "UN2915"
 * @property {string} properShippingName - IATA proper shipping name
 * @property {string} classDivision - Hazard class/division e.g. "7"
 * @property {string} packingGroup - Packing group e.g. "II" (or "" for radioactive)
 * @property {string} reportableQty - "Y" or "N"
 * @property {string} transportIndex - Transport index for radioactive, or net quantity
 * @property {string} numPcs - Number of packages/pieces
 * @property {Object|null} dimensions - Package dimensions {width, length, height}
 * @property {string} radionuclideSymbol - Radionuclide symbol e.g. "I-123"
 * @property {string} chemicalPhysicalForm - Chemical/physical form (empty if not provided)
 * @property {string} activityLevel - Activity level e.g. "742.25"
 * @property {string} activityUnit - Unit of measure e.g. "4N" or "GBQ"
 * @property {Object|null} radioactiveMaterial - RadioactiveMaterial info if applicable
 */

/**
 * @typedef {Object} XsdgData
 * @property {string} awbNumber - Air Waybill number e.g. "001-24456040"
 * @property {string} shipperName - Consignor/shipper name
 * @property {string} consigneeName - Consignee name
 * @property {string} origin - Origin IATA code e.g. "ORD"
 * @property {string} destination - Destination IATA code e.g. "LGA"
 * @property {XsdgDgItem[]} dgItems - Array of DG line items
 * @property {string} emergencyContact - Emergency contact name/org
 * @property {string} emergencyPhone - Emergency contact phone
 * @property {string} aircraftLimitation - Aircraft type limitation string
 * @property {string} specialHandlingInfo - Special handling instructions (empty if none)
 * @property {string} verifiedByName - Declarant/verifier name e.g. "LUCAS MARTINEZ"
 * @property {string} verifiedByEmpNum - Declarant/verifier employee number e.g. "00797971"
 * @property {string} totalPackages - Total number of packages across all DG items
 */
