
/**
 * Minimal date formatter with offset and timezone
 * Supported tokens: YYYY, YY, MM, DD/dd, HH, mm, ss, MMM, MMMM
 * Time zone: any valid IANA zone (e.g., "Asia/Kolkata", "America/Chicago") or "UTC"
 * Locale: uses "en-US" for month names; adjust if you need another language.
 */

export function getDateWithOffset(pattern, offset, timeZone = undefined) {
    const days = parseInt(offset, 10) || 0;

    // Base date = now + offset days (in local clock)
    const base = new Date();
    base.setDate(base.getDate() + days);

    // Validate timezone (fallback to local if invalid)
    let tz = timeZone;
    if (tz && typeof tz === "string") {
        try { new Intl.DateTimeFormat("en-US", { timeZone: tz }).format(base); }
        catch { tz = undefined; }
    } else {
        tz = undefined;
    }

    // Formatters to extract numeric parts and month names in the chosen timezone
    const numericFmt = new Intl.DateTimeFormat("en-US", {
        timeZone: tz,
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: false,
    });

    const parts = Object.fromEntries(numericFmt.formatToParts(base).map(p => [p.type, p.value]));
    const YYYY = parts.year;
    const YY = parts.year.slice(-2);
    const MM = parts.month;
    const DD = parts.day;
    const HH = parts.hour;
    const mm = parts.minute;
    const ss = parts.second;

    // Month names in timezone
    const MMM = new Intl.DateTimeFormat("en-US", { timeZone: tz, month: "short" }).format(base).toUpperCase(); // "MAR"
    const MMMM = new Intl.DateTimeFormat("en-US", { timeZone: tz, month: "long" }).format(base);               // "March"

    const tokens = {
        "YYYY": YYYY,
        "YY": YY,
        "MMMM": MMMM,
        "MMM": MMM,
        "MM": MM,
        "DD": DD,
        "dd": DD,
        "HH": HH,
        "mm": mm,
        "ss": ss,
    };

    // Build regex from tokens, sorted by length DESC to avoid partial matches (e.g., MMM before MM)
    const keys = Object.keys(tokens).sort((a, b) => b.length - a.length);
    const re = new RegExp(keys.join("|"), "g");

    return pattern.replace(re, t => tokens[t]);
}



/**
 * Replaces all ${date|<pattern>|<offset>[|<timezone>]} placeholders.
 * Works for:
 *   - string (returns string)
 *   - array (deep, returns new array)
 *   - object/dict (deep, returns new object)
 *
 * @param {any} input
 * @param {string|undefined} defaultTimeZone - applied when placeholder omits a timezone
 * @returns {any} deep-transformed copy with placeholders replaced
 */
export function replaceDatePlaceholders(input, defaultTimeZone = undefined) {
    // Regex allows optional spaces: ${date| pattern | offset | timezone }
    const PLACEHOLDER_RE = /\$\{date\|\s*([^|}]+?)\s*\|\s*([^|}]+?)\s*(?:\|\s*([^}]+?)\s*)?\}/g;

    const seen = new WeakSet();

    const replaceInString = (s) => {
        if (typeof s !== "string") return s;
        return s.replace(PLACEHOLDER_RE, (full, pattern, offset, tz) => {
            const tzFinal = (tz && tz.trim()) || defaultTimeZone;
            try {
                return getDateWithOffset(String(pattern).trim(), String(offset).trim(), tzFinal);
            } catch {
                // On any failure, return the original placeholder
                return full;
            }
        });
    };

    const walk = (value) => {
        // Primitives (and functions) left as-is
        if (value === null || typeof value !== "object") {
            return replaceInString(value);
        }

        // Arrays
        if (Array.isArray(value)) {
            return value.map(walk);
        }

        // Objects (dicts) with cycle protection
        if (seen.has(value)) return value;
        seen.add(value);

        const out = {};
        for (const k of Object.keys(value)) {
            out[k] = walk(value[k]); // only replace in values, not in keys
        }
        return out;
    };

    return walk(input);
}

export function isMatchingDateFormat(str, pattern) {
    const MONTHS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
    const map = {
        YYYY: '(?<YYYY>\\d{4})',
        MM: '(?<MM>\\d{2})',
        dd: '(?<dd>\\d{2})',
        HH: '(?<HH>\\d{2})',
        mm: '(?<min>\\d{2})',
        ss: '(?<ss>\\d{2})',
        MMM: '(?<MMM>[A-Za-z]{3})'
    };

    // Build regex from pattern
    const tok = /(YYYY|MM|dd|HH|mm|ss|MMM)/g;
    const regex = new RegExp('^' + pattern.replace(tok, t => map[t]) + '$');

    const m = str.match(regex);
    if (!m) return false;

    // Extract parsed parts
    const g = m.groups;
    const yyyy = g.YYYY ? +g.YYYY : undefined;
    const mm = g.MM ? +g.MM : g.MMM ? MONTHS[g.MMM.toLowerCase()] : undefined;
    const dd = g.dd ? +g.dd : undefined;

    // Calendar validation if YYYY/MM/dd exist
    if (yyyy && mm && dd) {
        const days = [31, (yyyy % 4 === 0 && (yyyy % 100 !== 0 || yyyy % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][mm - 1];
        if (dd < 1 || dd > days) return false;
    }

    // Time fields validation
    if (g.HH && (+g.HH < 0 || +g.HH > 23)) return false;
    if (g.min && (+g.min < 0 || +g.min > 59)) return false;
    if (g.ss && (+g.ss < 0 || +g.ss > 59)) return false;

    return true;
}

export function parse_MMddYYYY(s, timeZone = undefined) {
    // "03/01/2026"
    const MM = +s.slice(0, 2);
    const DD = +s.slice(3, 5);
    const YYYY = +s.slice(6, 10);
    
    const date = new Date(YYYY, MM - 1, DD);
    
    if (timeZone) {
        const formatter = new Intl.DateTimeFormat("en-US", { timeZone });
        const parts = Object.fromEntries(formatter.formatToParts(date).map(p => [p.type, p.value]));
        return new Date(+parts.year, +parts.month - 1, +parts.day);
    }
    
    return date;
}

export function parse_ddMMM(s) {
    // "31DEC"
    const DD = parseInt(s.slice(0, s.length - 3), 10);
    const MMM = s.slice(-3).toUpperCase();

    const MONTHS = {
        JAN: 0, FEB: 1, MAR: 2, APR: 3, MAY: 4, JUN: 5,
        JUL: 6, AUG: 7, SEP: 8, OCT: 9, NOV: 10, DEC: 11
    };

    return new Date(new Date().getFullYear(), MONTHS[MMM], DD);
}

