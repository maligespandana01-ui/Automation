/**
 * @charset UTF-8
 * Report Helper - Allure reporting utilities for API response validation
 */
import * as allure from 'allure-js-commons';
import { compareJsonObjects, getComparisonSummary } from './JsonUtils.js';
import { VALIDATION_STATUS, DEFAULT_VALUES, ENV_CONFIG_KEYS } from '../constants/Constants.js';

export class ReportHelper {
    static #STATUS = {
        [VALIDATION_STATUS.PASS]: { cls: 'pass', txt: VALIDATION_STATUS.PASS },
        [VALIDATION_STATUS.FAIL]: { cls: 'fail', txt: VALIDATION_STATUS.FAIL },
        [VALIDATION_STATUS.SKIP]: { cls: 'ignored', txt: VALIDATION_STATUS.SKIP }
    };

    static #getStatus = (s) => this.#STATUS[s] || { cls: '', txt: s };
    static #fmt = (v) => typeof v === 'object' ? JSON.stringify(v, null, 2) : v;
    static #parse = (v) => { try { return typeof v === 'string' ? JSON.parse(v.trim()) : v; } catch { return v?.trim?.() ?? v; } };

    static #genRows = (results) => results.map(r => {
        const { cls, txt } = this.#getStatus(r.status);
        return `<tr class="${cls}"><td><b>${r.field}</b></td><td><code>${this.#fmt(r.expected)}</code></td><td><code>${this.#fmt(r.actual)}</code></td><td style="text-align:center"><b>${txt}</b></td></tr>`;
    }).join('');


     //Generates an HTML validation table for comparison results

    static generateHtmlTable(title, results, expectedStatus, actualStatus) {
        const statusMatch = expectedStatus === actualStatus;
        const statusInfo = this.#getStatus(statusMatch ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL);
        const summary = {
            total: results.length,
            passed: results.filter(r => r.status === VALIDATION_STATUS.PASS).length + (statusMatch ? 1 : 0),
            failed: results.filter(r => r.status === VALIDATION_STATUS.FAIL).length + (statusMatch ? 0 : 1),
            ignored: results.filter(r => r.status === VALIDATION_STATUS.SKIP).length
        };

        return `<!DOCTYPE html><html><head><meta charset="UTF-8"><style>body{font-family:Arial;margin:20px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ddd;padding:10px}th{background:#1976d2;color:#fff}.pass{background:#e8f5e9;color:#4CAF50}.fail{background:#ffebee;color:#f44336}.ignored{background:#fff3e0;color:#ff9800}</style></head><body><h2>${title}</h2><div style="background:#f5f5f5;padding:15px;margin-bottom:15px;border-radius:5px"><b>Total:</b> ${summary.total + 1} | <span style="color:#4CAF50"><b>Passed:</b> ${summary.passed}</span> | <span style="color:#f44336"><b>Failed:</b> ${summary.failed}</span> | <span style="color:#ff9800"><b>Ignored:</b> ${summary.ignored}</span></div><table><tr><th>Field</th><th>Expected</th><th>Actual</th><th>Status</th></tr><tr class="${statusInfo.cls}"><td><b>HTTP Status</b></td><td><b>${expectedStatus}</b></td><td><b>${actualStatus}</b></td><td style="text-align:center"><b>${statusInfo.txt}</b></td></tr>${this.#genRows(results)}</table></body></html>`;
    }

    static #validateErrors = (expected, actual) => {
        const getErrors = (obj) => Array.isArray(obj) ? obj : obj?.validationErrors ? [].concat(obj.validationErrors) : obj?.field ? [obj] : [];
        const expErrs = getErrors(expected), actErrs = getErrors(actual);

        return expErrs.flatMap((exp, i) => {
            const exact = actErrs.find(a => a.field === exp.field && a.message === exp.message);
            const field = actErrs.find(a => a.field === exp.field);
            return [
                { field: `[${i}].field`, expected: exp.field, actual: field?.field || DEFAULT_VALUES.MISSING, status: field?.field === exp.field ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL },
                { field: `[${i}].message`, expected: exp.message, actual: exact?.message || field?.message || DEFAULT_VALUES.MISSING, status: exact ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL }
            ];
        });
    };

    static async validateResponse(expectedStatus, actualStatus, expectedResponse, actualResponse, testData = {}, fieldsToIgnore = []) {
        const { Test_ID = '', baseUrl = '', endpoint = '', requestData = {} } = testData;

        // Allure reporting steps
        await allure.step('Before Hooks', async () => await allure.attachment('Test Initialization', 'Test setup completed', ENV_CONFIG_KEYS.CONTENT_TYPE));
        if (Test_ID) await allure.step('Test Identification', async () => await allure.attachment('Test ID', Test_ID, ENV_CONFIG_KEYS.CONTENT_TYPE));

        if (requestData.data && requestData.data !== '') {
            const type = requestData.isQueryParams ? 'Query Parameters' : 'Request Body';
            await allure.step(type, async () => await allure.attachment(type, typeof requestData.data === 'string' ? requestData.data : JSON.stringify(requestData.data, null, 2), typeof requestData.data === 'string' ? ENV_CONFIG_KEYS.CONTENT_TYPE : ENV_CONFIG_KEYS.CONTENT_TYPE_JSON));
        }

        await allure.step('Send Request', async () => await allure.attachment('Request URL', `${baseUrl}${endpoint}`, ENV_CONFIG_KEYS.CONTENT_TYPE));
        await allure.step('Actual Response', async () => {
            await allure.attachment('Response Status', `${actualStatus}`, ENV_CONFIG_KEYS.CONTENT_TYPE);
            await allure.attachment('Response Body', typeof actualResponse === 'string' ? actualResponse : JSON.stringify(actualResponse, null, 2), ENV_CONFIG_KEYS.CONTENT_TYPE);
        });

        // Parse and validate
        const expObj = this.#parse(expectedResponse), actObj = this.#parse(actualResponse);
        const isArr = Array.isArray(expObj) || Array.isArray(actObj) || actObj?.validationErrors;

        let results = [], type = 'POSITIVE';
        if (isArr) {
            type = 'NEGATIVE_VALIDATION';
            results = this.#validateErrors(expObj, actObj);
        } else if (typeof expObj === 'string') {
            type = 'NEGATIVE_ERROR';
            const actMsg = actObj?.message || actObj?.error || actObj;
            results = [{ field: 'message', expected: expObj, actual: actMsg, status: expObj === actMsg ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL }];
        } else {
            results = compareJsonObjects(expObj, actObj, fieldsToIgnore);
        }

        const summary = getComparisonSummary(results);

        await allure.step('Validate Response', async () => await allure.attachment('Validation Report', this.generateHtmlTable('API Response Validation', results, expectedStatus, actualStatus), ENV_CONFIG_KEYS.CONTENT_TYPE_HTML));

        if (actualStatus !== expectedStatus) throw new Error(`❌ Status Mismatch: Expected ${expectedStatus}, got ${actualStatus}`);
        if (summary.failed > 0) throw new Error(`❌ Validation Failed: ${summary.failed} field(s) mismatch`);

        await allure.step('After Hooks', async () => await allure.attachment('Test Cleanup', 'Test cleanup completed', ENV_CONFIG_KEYS.CONTENT_TYPE));
        return { statusMatch: true, validationType: type, comparisonResults: results, summary };
    }
}
