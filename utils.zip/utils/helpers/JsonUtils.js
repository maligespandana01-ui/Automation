import { expect, test } from '@playwright/test';
import * as allure from 'allure-js-commons';

/**
 * @charset UTF-8
 * UTF-8 Character Encoding Declaration
 */
/**
 * @charset UTF-8
 * JSON Utilities - File reading and JSON comparison helpers
 */
import fs from 'fs';
import { VALIDATION_STATUS, DEFAULT_VALUES } from '../constants/Constants.js';

export const readJsonFile = (path) => {
    try { return JSON.parse(fs.readFileSync(path, 'utf-8')); }
    catch (e) { throw new Error(`Failed to read test data: ${e.message}`); }
};

export const compareJsonObjects = (expected, actual, ignore = []) => {
    const exp = typeof expected === 'string' ? JSON.parse(expected) : expected;
    const act = typeof actual === 'string' ? JSON.parse(actual) : actual;

    return Object.keys(exp || {}).map(key => {
        if (ignore.includes(key)) return { field: key, expected: exp[key], actual: act?.[key] ?? DEFAULT_VALUES.MISSING, status: VALIDATION_STATUS.SKIP };
        const expVal = exp[key], actVal = act?.[key] ?? DEFAULT_VALUES.MISSING;
        return { field: key, expected: expVal, actual: actVal, status: JSON.stringify(expVal) === JSON.stringify(actVal) ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL };
    });
};

export const getComparisonSummary = (results) => ({
    total: results.length,
    passed: results.filter(r => r.status === VALIDATION_STATUS.PASS).length,
    failed: results.filter(r => r.status === VALIDATION_STATUS.FAIL).length,
    ignored: results.filter(r => r.status === VALIDATION_STATUS.SKIP).length
});

export async function normalizeArrayDict(obj, ignoreKeys = [], convertNullToBlank = false) {
    const ignore = new Set(ignoreKeys.map(k => k.toLowerCase()));

    const toCanonicalString = (value) => {
        if (Array.isArray(value)) {
            return `[${value.map(toCanonicalString).join(',')}]`;
        }

        if (value && typeof value === 'object') {
            const keys = Object.keys(value).sort();
            return `{${keys.map((k) => `${JSON.stringify(k)}:${toCanonicalString(value[k])}`).join(',')}}`;
        }

        return JSON.stringify(value);
    };

    const clean = (v) => {
        if (Array.isArray(v)) {
            const normalized = v.map(clean);
            // sort map positions in array based on string key and string value
            return normalized.sort((a, b) => {
                const aStr = typeof a === 'object' ? toCanonicalString(a) : String(a);
                const bStr = typeof b === 'object' ? toCanonicalString(b) : String(b);
                return aStr.localeCompare(bStr);
            });
        }

        if (v && typeof v === "object") {
            const out = {};
            for (const [k, val] of Object.entries(v)) {
                const keyLower = k.toLowerCase();
                if (ignore.has(keyLower)) continue;
                out[keyLower] = clean(val);
            }
            return out;
        }

        //convert null values to blank
        if (convertNullToBlank && v === null) {
            return '';
        }

        // trim leading and trailing spaces
        if (typeof v === "string") {
            v = v.trim();
        }

        // minimal addition: convert "5.0" / "10.000" → "5" / "10"
        if (typeof v === "string" && /^[+-]?\d+\.0+$/.test(v)) {
            return String(Number(v));
        }

        return v;
    };

    return clean(obj);
}
