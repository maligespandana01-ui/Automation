import { Pool } from 'pg';
import oracledb from 'oracledb';
import fs from 'fs';
import { FILE_PATHS } from '../constants/Constants.js';
import * as allure from 'allure-js-commons';
import { getEnvVariable } from '../../utils/config/EnvLoader.js';
import { ENV_CONFIG_KEYS } from '../../utils/constants/Constants.js';


/* -------------------- load queries -------------------- */

const QUERIES = JSON.parse(
  fs.readFileSync(`${process.cwd()}/${FILE_PATHS.DB_QUERIES}`, 'utf-8')
);

/* -------------------- DB pool -------------------- */

const pool = new Pool({
  host: getEnvVariable(ENV_CONFIG_KEYS.DB_HOST),
  port: Number(getEnvVariable(ENV_CONFIG_KEYS.DB_PORT)),
  database: getEnvVariable(ENV_CONFIG_KEYS.DB_NAME),
  user: getEnvVariable(ENV_CONFIG_KEYS.DB_USERNAME),
  password: getEnvVariable(ENV_CONFIG_KEYS.DB_PASSWORD),
  ssl: { rejectUnauthorized: false },
  max: 30, // Increased pool size for better concurrency
  idleTimeoutMillis: 60000, // Keep connections alive longer
  connectionTimeoutMillis: 10000, // Faster timeout for failed connections
  keepalives: true,
  keepalives_idle: 10000, // Start keepalive probes after 10 seconds
  statement_timeout: 30000, // Cancel queries taking longer than 30 seconds
  query_timeout: 30000, // Alternative query timeout
  // application_name: 'cgodangergds-test-automation', // For monitoring
});

/* -------------------- generic executor with retry logic  -------------------- */
function isRetryable(err) {
  return (
    err.message?.includes('timeout') ||
    err.message?.includes('Connection terminated')
  );
}

export async function executeQuery(sqlQuery, retries = 0, interval = 1000) {
  let rows = {};
  //convert to lowercase for case-insensitive comparison in retry logic, but keep original for logging and execution
  sqlQuery = sqlQuery.toLowerCase();

  //extract table name from query for better logging, assuming table name is after 'from' keyword and before space or end of query
  const tableNameMatch = sqlQuery.match(/from\s+([^\s]+)/);
  const tableName = tableNameMatch ? tableNameMatch[1] : 'unknown_table';

  //loop with retry logic
  await allure.step(`Executing DB query for table: ${tableName}`, async () => {
    //attach the SQL query in allure for better visibility in reports
    await allure.attachment(`SQL Query - ${tableName}`, sqlQuery, 'text/plain');
    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        const res = await pool.query(sqlQuery);
        rows = res.rows;
        if (rows.length > 0) { // exit loop if query execution is successful
          console.log(`[DB] Query execution successful on attempt ${attempt + 1}: ${sqlQuery}`);
          break;
        }
      } catch (err) {
        if (attempt >= retries || !isRetryable(err)) {
          console.error(`[DB] Query execution failed after ${attempt + 1} attempts, SQL Query: ${sqlQuery}`);
          await allure.step(`Error executing query for table ${tableName}: ${err.message}`, async () => {
            await allure.attachment('Query', sqlQuery, 'text/plain');
            await allure.attachment('Error Message', err.message, 'text/plain');
          });
          throw err;
        }
      }
      //wait interval before next attempt
      if (attempt < retries && interval > 0)
        await new Promise(r => setTimeout(r, interval));
    }
  });
  return rows;
}

/* -------------------- close pool -------------------- */
export async function closeDb() {
  try {
    await pool.end();
    console.log('[DB] Connection pool closed');
  } catch (error) {
    console.error('[DB] Error closing pool:', error.message);
  }
}



///////// ORACLE DB CONNECTION METHODS

// Module-level Oracle pool singleton — created once, reused across all calls
let _oraclePool = null;
let _oraclePoolCreating = null;

async function getOraclePool() {
  if (_oraclePool) return _oraclePool;
  // Prevent concurrent pool creation races
  if (!_oraclePoolCreating) {
    _oraclePoolCreating = oracledb.createPool({
      user: getEnvVariable("ORACLE_DB_USERNAME"),
      password: getEnvVariable("ORACLE_DB_PASSWORD"),
      connectString: `${getEnvVariable("ORACLE_DB_HOST")}:${getEnvVariable("ORACLE_DB_PORT")}/${getEnvVariable("ORACLE_DB_SERVICE_NAME")}`,
      poolMin: 4,
      poolMax: 20,
      poolIncrement: 2,
      poolTimeout: 60,
      queueTimeout: 60000,
      stmtCacheSize: 50,
    }).then(pool => { _oraclePool = pool; return pool; });
  }
  return _oraclePoolCreating;
}

export async function executeOracleQuery(
  sqlQuery,
  bindParams = {},
  options = {},
  retries = 0,
  interval = 1000
) {
  let resultRows = {};
  const tableName = sqlQuery.match(/from\s+([^\s]+)/i)?.[1] || 'unknown_table';

  await allure.step(`Executing Oracle DB query for table: ${tableName}`, async () => {
    //attach the SQL query in allure for better visibility in reports
    await allure.attachment(`SQL Query - ${tableName}`, sqlQuery, 'text/plain');

    const pool = await getOraclePool();

    for (let attempt = 0; attempt <= retries; attempt++) {
      let connection;
      try {
        connection = await pool.getConnection();
        // Set NLS_DATE_FORMAT so TO_DATE() and implicit VARCHAR2→DATE conversions
        // always use MM/DD/YYYY, regardless of the Oracle server's default NLS settings.
        await connection.execute("ALTER SESSION SET NLS_DATE_FORMAT='MM/DD/YYYY'");

        const executeOptions = {
          outFormat: oracledb.OUT_FORMAT_OBJECT,
          autoCommit: false,
          ...options,
        };

        const result = await connection.execute(sqlQuery, bindParams, executeOptions);
        resultRows = result.rows || {};

        console.log(`[Oracle DB] Query execution successful on attempt ${attempt + 1}`);
        break;
      } catch (err) {
        if (attempt >= retries || !isRetryable(err)) {
          console.error(`[Oracle DB] Query execution failed after ${attempt + 1} attempts, SQL Query: ${sqlQuery}`);
          throw err;
        }
      } finally {
        if (connection) {
          await connection.close();
        }
      }

      if (attempt < retries && interval > 0) {
        await new Promise((resolve) => setTimeout(resolve, interval));
      }
    }
  });

  return resultRows;
}
