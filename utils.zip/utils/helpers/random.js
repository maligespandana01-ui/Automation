/* ==================== RANDOM NUMBER ==================== */

export function randomNumber(length) {
  const min = Math.pow(10, length - 1);
  const max = Math.pow(10, length) - 1;
  return Math.floor(Math.random() * (max - min + 1) + min).toString();
}

 //Generate a random 3-letter uppercase crew base code
export function generateRandomCrewBase() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  return Array.from({ length: 3 }, () => chars.charAt(Math.floor(Math.random() * chars.length))).join('');
}

/* ================= DATE FORMAT ================= */

export function formatTime(format = "MM/dd/yyyy HH:mm:ss") {
  const d = new Date();
  const pad = n => n.toString().padStart(2, '0');

  const map = {
    MM: pad(d.getMonth() + 1),
    dd: pad(d.getDate()),
    yyyy: d.getFullYear(),
    HH: pad(d.getHours()),
    mm: pad(d.getMinutes()),
    ss: pad(d.getSeconds())
  };

  return format.replace(/MM|dd|yyyy|HH|mm|ss/g, match => map[match]);
}