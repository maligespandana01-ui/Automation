/**
 * @charset UTF-8
 * EmergencyResponseNtmXsdgValidator - Validates Emergency Response Report UI data
 * against expected data derived from NTM and XSDG source files.
 *
 * Unlike the DB-based validator, this validator uses parsed NTM + XSDG data
 * as the expected (golden) values and compares them against the UI's actual output.
 *
 * Validation areas:
 * - Flight info (number, date, origin, destination) — sourced from NTM
 * - AWB / Shipper info — sourced from XSDG
 * - Hazmat detail rows (PSN, class, UNID, PG, pieces, net qty/TI) — sourced from XSDG + NTM
 * - PDF content checks — against NTM/XSDG values
 */
import * as allure from 'allure-js-commons';
import { VALIDATION_STATUS } from '../constants/Constants.js';
import { Logger } from './Logger.js';
import { NtmParser } from './NtmParser.js';

/** Escapes HTML special characters for safe embedding in HTML reports. */
function escHtml(str) {
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/**
 * Validates Emergency Response Report UI data against NTM + XSDG expected data.
 */
export class EmergencyResponseNtmXsdgValidator {

    /**
     * Static emergency contact (CHEMTREC) — identical for every Emergency Response
     * Report regardless of flight/booking. The report shows it under the
     * "Emergency Contact Num" section as the Domestic number.
     * @type {string}
     */
    static EXPECTED_EMERGENCY_CONTACT_DOMESTIC = '1 703 527 3887';

    // ==================== FLIGHT INFO VALIDATION ====================

    /**
     * Validates the UI report flight info against NTM-derived expected values.
     * @param {Object} reportData - Extracted UI report data from EmergencyResponseReportPage
     * @param {import('./NtmParser.js').NtmFlightInfo} ntmFlightInfo - Parsed NTM flight info
     * @returns {{ results: Array, allPassed: boolean }}
     */
    static validateFlightInfo(reportData, ntmFlightInfo) {
        const results = [];
        const ui = reportData.flightInfo || {};

        if (!ntmFlightInfo?.flightNumber) {
            Logger.warn('ERR-NtmXsdgValidator', 'No NTM flight info available for validation');
            return {
                results: [{ field: 'ntmFlightInfo', expected: 'present', actual: 'empty', status: VALIDATION_STATUS.FAIL }],
                allPassed: false,
            };
        }

        // Flight number: NTM has e.g. "0327", UI may show "327" — strip leading zeros for compare
        const uiFlightNum = String(ui.flightNumber || '').trim().replace(/^0+/, '');
        const ntmFlightNum = String(ntmFlightInfo.flightNumber || '').trim().replace(/^0+/, '');
        results.push({
            field: 'flightNumber',
            expected: ntmFlightInfo.flightNumber,
            actual: ui.flightNumber,
            status: uiFlightNum === ntmFlightNum ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL,
        });

        // Date: NTM gives MM/DD/YYYY; UI may show MM/DD/YYYY or YYYY-MM-DD
        const uiDate = this._normalizeDate(String(ui.date || '').trim());
        const ntmDate = this._normalizeDate(ntmFlightInfo.flightDate || '');
        results.push({
            field: 'flightDate',
            expected: ntmFlightInfo.flightDate,
            actual: ui.date,
            status: uiDate === ntmDate ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL,
        });

        // Origin
        results.push(this._compare('origin', ui.from, ntmFlightInfo.origin));

        // Destination
        results.push(this._compare('destination', ui.to, ntmFlightInfo.destination));

        // Unit numbers are validated per-ULD (see validatePerUld), because a report
        // may span multiple ULDs and render one box per unit. The single flight-level
        // "Unit Num" header is therefore not asserted here.

        const allPassed = results.every(r => r.status === VALIDATION_STATUS.PASS);
        Logger.info('ERR-NtmXsdgValidator', `Flight info validation: ${allPassed ? 'ALL PASSED' : 'FAILURES'}`, { results });
        return { results, allPassed };
    }

    // ==================== AWB / SHIPPER INFO VALIDATION ====================

    /**
     * Validates the AWB headers shown in the UI against the AWB number from XSDG.
     * @param {Object} reportData - Extracted UI report data
     * @param {import('./XsdgParser.js').XsdgData} xsdgData - Parsed XSDG data
     * @returns {{ results: Array, allPassed: boolean }}
     */
    static validateAwbInfo(reportData, xsdgData) {
        const results = [];

        if (!xsdgData?.awbNumber) {
            Logger.warn('ERR-NtmXsdgValidator', 'No XSDG AWB number for validation');
            return {
                results: [{ field: 'xsdgAwbNumber', expected: 'present', actual: 'empty', status: VALIDATION_STATUS.FAIL }],
                allPassed: false,
            };
        }

        const uiAwbHeaders = reportData.awbHeaders || [];
        if (!uiAwbHeaders.length) {
            results.push({
                field: 'awbHeaders',
                expected: xsdgData.awbNumber,
                actual: 'none found in UI',
                status: VALIDATION_STATUS.FAIL,
            });
        } else {
            // AWB may be formatted differently: "001-24456040" vs "001-244560407"
            // Normalize by removing dashes and trailing check digits
            const normXsdgAwb = this._normalizeAwb(xsdgData.awbNumber);
            const uiAwbMatch = uiAwbHeaders.find(h =>
                this._normalizeAwb(h.awbNumber || '').startsWith(normXsdgAwb) ||
                normXsdgAwb.startsWith(this._normalizeAwb(h.awbNumber || ''))
            );

            results.push({
                field: 'awbNumber',
                expected: xsdgData.awbNumber,
                actual: uiAwbHeaders[0]?.awbNumber || '',
                status: uiAwbMatch ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL,
            });

            const uiHeader = uiAwbHeaders[0] || {};

            // --- Origin embedded in AWB header ---
            // The header reads "001<ORIGIN><awb-digits>" e.g. "001ORD24456040".
            // The origin (from XSDG) must appear between the "001" prefix and the AWB digits.
            if (xsdgData.origin) {
                const headerStr = String(uiHeader.awbNumber || '').toUpperCase();
                const expectedOrigin = String(xsdgData.origin).trim().toUpperCase();
                const originMatch = new RegExp(`^001\\s*${expectedOrigin}`).test(headerStr)
                    || headerStr.includes(expectedOrigin);
                results.push({
                    field: 'awbOrigin',
                    expected: `${expectedOrigin} (after "001" in AWB header)`,
                    actual: uiHeader.awbNumber || '',
                    status: originMatch ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL,
                });
            }

            // --- Total number of packages ---
            // XSDG total = sum of pieces across all DG items (e.g. 3+1+1+1 = 6).
            // The UI may split this AWB across several ULD boxes, each with its own
            // "(Total Packages=N)" header, so compare against the SUM across all boxes.
            if (xsdgData.totalPackages) {
                const uiTotalSum = uiAwbHeaders.reduce(
                    (sum, h) => sum + (parseInt(h.totalPackages, 10) || 0), 0);
                results.push({
                    field: 'awbTotalPackages',
                    expected: String(xsdgData.totalPackages).trim(),
                    actual: String(uiTotalSum),
                    status: String(uiTotalSum) === String(xsdgData.totalPackages).trim()
                        ? VALIDATION_STATUS.PASS
                        : VALIDATION_STATUS.FAIL,
                });
            }
        }

        const allPassed = results.every(r => r.status === VALIDATION_STATUS.PASS);
        return { results, allPassed };
    }

    // ==================== HAZMAT DETAIL ROW VALIDATION ====================

    /**
     * Validates UI hazmat detail rows against expected data from XSDG + NTM.
     * Each UI row is matched to an XSDG DG item by UNID.
     * NTM provides pieces and net quantity; XSDG provides PSN, class, and packing group.
     *
     * @param {Array} uiHazmatRows - Hazmat rows from UI (from EmergencyResponseReportPage.getHazmatDetailRows())
     * @param {import('./XsdgParser.js').XsdgDgItem[]} xsdgItems - XSDG DG items
     * @param {import('./NtmParser.js').NtmDgItem[]} ntmItems - NTM DG items
     * @param {Array} [uiRadionuclideRows] - Radionuclide detail rows from UI (index-aligned to hazmat rows)
     * @returns {{ results: Array, allPassed: boolean }}
     */
    static validateHazmatRows(uiHazmatRows, xsdgItems, ntmItems, uiRadionuclideRows = []) {
        const results = [];

        if (!uiHazmatRows?.length) {
            results.push({
                field: 'uiHazmatRows',
                expected: 'at least 1 row',
                actual: '0 rows',
                status: VALIDATION_STATUS.FAIL,
            });
            return { results, allPassed: false };
        }

        if (!xsdgItems?.length) {
            results.push({
                field: 'xsdgDgItems',
                expected: 'present',
                actual: 'empty',
                status: VALIDATION_STATUS.FAIL,
            });
            return { results, allPassed: false };
        }

        // Validate row count
        results.push({
            field: 'hazmatRowCount',
            expected: String(xsdgItems.length),
            actual: String(uiHazmatRows.length),
            status: uiHazmatRows.length === xsdgItems.length ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL,
        });

        // Determine if UNIDs are unique across XSDG items
        // If all items share the same UNID (e.g. all UN2915), use index-based matching
        const xsdgUnids = xsdgItems.map(x => this._normalizeUnid(x.unid));
        const allUidsUnique = new Set(xsdgUnids).size === xsdgUnids.length;

        const ntmUnids = (ntmItems || []).map(n => this._normalizeUnid(n.unid));
        const allNtmUnique = new Set(ntmUnids).size === ntmUnids.length;

        // Validate each UI row against matched XSDG + NTM entry
        for (let i = 0; i < uiHazmatRows.length; i++) {
            const uiRow = uiHazmatRows[i];
            const rowLabel = `row[${i}]`;

            const uiUnid = this._normalizeUnid(uiRow.unIdNumber || '');

            // Use UNID-based match only when UNIDs are unique; otherwise use index
            const xsdgItem = allUidsUnique
                ? (xsdgItems.find(x => this._normalizeUnid(x.unid) === uiUnid) || xsdgItems[i])
                : xsdgItems[i];

            if (!xsdgItem) {
                results.push({
                    field: `${rowLabel}.xsdgMatch`,
                    expected: `XSDG item for UNID ${uiRow.unIdNumber}`,
                    actual: 'no match found',
                    status: VALIDATION_STATUS.FAIL,
                });
                continue;
            }

            // Match NTM item by index (or UNID when unique)
            const ntmItem = allNtmUnique
                ? ntmItems?.find(n => this._normalizeUnid(n.unid) === uiUnid)
                : ntmItems?.[i];

            // --- Proper Shipping Name ---
            results.push(this._compareContains(
                `${rowLabel}.properShippingName`,
                uiRow.properShippingName,
                xsdgItem.properShippingName,
            ));

            // --- Class / Division ---
            results.push(this._compare(
                `${rowLabel}.classDivision`,
                uiRow.classDivision,
                xsdgItem.classDivision,
            ));

            // --- UNID ---
            results.push({
                field: `${rowLabel}.unid`,
                expected: xsdgItem.unid,
                actual: uiRow.unIdNumber,
                status: uiUnid === this._normalizeUnid(xsdgItem.unid)
                    ? VALIDATION_STATUS.PASS
                    : VALIDATION_STATUS.FAIL,
            });

            // --- Packing Group ---
            // The report shows the full radioactive type code e.g. "II-YELLOW".
            // The XSDG raw TypeCode is the same full value, so display it as the
            // expected value (exact match) and fall back to prefix compare otherwise.
            if (xsdgItem.packingGroup) {
                const rawTypeCode = xsdgItem.radioactiveMaterial?.typeCode || xsdgItem.packingGroup;
                const normUiPg = (uiRow.packingGroup || '').split('-')[0].trim().toUpperCase();
                const normExpPg = (xsdgItem.packingGroup || '').split('-')[0].trim().toUpperCase();
                const exactMatch = (uiRow.packingGroup || '').trim().toUpperCase()
                    === String(rawTypeCode).trim().toUpperCase();
                results.push({
                    field: `${rowLabel}.packingGroup`,
                    expected: rawTypeCode,
                    actual: uiRow.packingGroup,
                    status: (exactMatch || normUiPg === normExpPg)
                        ? VALIDATION_STATUS.PASS
                        : VALIDATION_STATUS.FAIL,
                });
            }

            // --- Reportable Quantity (RQ) ---
            const expectedRq = xsdgItem.reportableQty === 'Y' ? 'Y' : 'N';
            const actualRq = (uiRow.rq || '').trim() === '' ? 'N' : (uiRow.rq || '').trim();
            results.push({
                field: `${rowLabel}.rq`,
                expected: expectedRq,
                actual: actualRq,
                status: expectedRq.toLowerCase() === actualRq.toLowerCase()
                    ? VALIDATION_STATUS.PASS
                    : VALIDATION_STATUS.FAIL,
            });

            // --- Number of Pieces (from NTM or XSDG) ---
            const expectedPcs = ntmItem?.pieces || xsdgItem.numPcs;
            if (expectedPcs) {
                results.push({
                    field: `${rowLabel}.numPcs`,
                    expected: String(expectedPcs),
                    actual: uiRow.numPcs,
                    status: String(uiRow.numPcs || '').trim() === String(expectedPcs).trim()
                        ? VALIDATION_STATUS.PASS
                        : VALIDATION_STATUS.FAIL,
                });
            }

            // --- Net Quantity / Transport Index (from NTM or XSDG) ---
            // NTM net quantity is numeric with a separate unit flag ("K" = kg). Build a
            // unit-bearing expected value so it normalizes against the UI's "26.000kg".
            // Radioactive items carry no unit (transport index), e.g. "0.2" → "0.200TI".
            const expectedNetQty = ntmItem
                ? `${ntmItem.netQty}${ntmItem.netQtyUnit === 'K' ? 'kg' : ''}`
                : xsdgItem.transportIndex;
            if (expectedNetQty) {
                results.push(this._compareWeight(
                    `${rowLabel}.netQty`,
                    uiRow.netQty,
                    expectedNetQty,
                ));
            }

            // --- Radionuclide details (XSDG ApplicableRadioactiveIsotope) ---
            // The report renders a sub-row per radioactive item with:
            //   Radionuclide Symbol | Chemical/Physical Form | Activity Level | Unit of Measure
            const uiRn = (uiRadionuclideRows || [])[i] || {};
            if (xsdgItem.radionuclideSymbol) {
                results.push(this._compare(
                    `${rowLabel}.radionuclideSymbol`,
                    uiRn.radionuclideSymbol,
                    xsdgItem.radionuclideSymbol,
                ));
            }
            if (xsdgItem.activityLevel) {
                results.push(this._compare(
                    `${rowLabel}.activityLevel`,
                    uiRn.activityLevel,
                    xsdgItem.activityLevel,
                ));
            }
            if (xsdgItem.activityUnit) {
                results.push(this._compare(
                    `${rowLabel}.unitOfMeasure`,
                    uiRn.unitOfMeasure,
                    xsdgItem.activityUnit,
                ));
            }
            // Chemical/physical form: only populated if XSDG carries a value, else empty.
            results.push(this._compare(
                `${rowLabel}.chemicalPhysicalForm`,
                uiRn.chemicalPhysicalForm,
                xsdgItem.chemicalPhysicalForm || '',
            ));
        }

        const allPassed = results.every(r => r.status === VALIDATION_STATUS.PASS);
        Logger.info('ERR-NtmXsdgValidator', `Hazmat rows validation: ${allPassed ? 'ALL PASSED' : 'FAILURES'}`, {
            total: results.length,
            passed: results.filter(r => r.status === VALIDATION_STATUS.PASS).length,
            failed: results.filter(r => r.status !== VALIDATION_STATUS.PASS).length,
        });
        return { results, allPassed };
    }

    // ==================== EMERGENCY CONTACT / HANDLING / VERIFIED-BY ====================

    /**
     * Validates the static Emergency Contact number shown on the report.
     * This value is the same for all scenarios (CHEMTREC domestic number).
     * @param {Object} reportData - Extracted UI report data
     * @returns {{ results: Array, allPassed: boolean }}
     */
    static validateEmergencyContact(reportData) {
        const results = [];
        const ui = reportData.emergencyContact || {};

        const expected = this.EXPECTED_EMERGENCY_CONTACT_DOMESTIC;
        const normalize = (s) => String(s ?? '').replace(/[\s\-]+/g, '');
        results.push({
            field: 'emergencyContactDomestic',
            expected,
            actual: ui.domestic || '',
            status: normalize(ui.domestic) === normalize(expected)
                ? VALIDATION_STATUS.PASS
                : VALIDATION_STATUS.FAIL,
        });

        const allPassed = results.every(r => r.status === VALIDATION_STATUS.PASS);
        Logger.info('ERR-NtmXsdgValidator', `Emergency contact validation: ${allPassed ? 'PASSED' : 'FAILED'}`, { results });
        return { results, allPassed };
    }

    /**
     * Validates the Special Handling Info section. It is populated only if the
     * XSDG carries a special-handling value; otherwise the report shows it empty.
     * @param {Object} reportData - Extracted UI report data
     * @param {import('./XsdgParser.js').XsdgData} xsdgData - Parsed XSDG data
     * @returns {{ results: Array, allPassed: boolean }}
     */
    static validateSpecialHandling(reportData, xsdgData) {
        const results = [];
        const expected = String(xsdgData?.specialHandlingInfo ?? '').trim();
        const uiValue = String(reportData?.specialHandlingInfo ?? '').trim();

        results.push({
            field: 'specialHandlingInfo',
            expected: expected || '(empty — no value in XSDG)',
            actual: uiValue || '(empty)',
            status: this._normalizeText(uiValue) === this._normalizeText(expected)
                ? VALIDATION_STATUS.PASS
                : VALIDATION_STATUS.FAIL,
        });

        const allPassed = results.every(r => r.status === VALIDATION_STATUS.PASS);
        Logger.info('ERR-NtmXsdgValidator', `Special handling validation: ${allPassed ? 'PASSED' : 'FAILED'}`, { results });
        return { results, allPassed };
    }

    /**
     * Validates the "Verified By" name and employee number against the XSDG
     * declarant authentication details.
     * @param {Object} reportData - Extracted UI report data
     * @param {import('./XsdgParser.js').XsdgData} xsdgData - Parsed XSDG data
     * @returns {{ results: Array, allPassed: boolean }}
     */
    static validateVerifiedBy(reportData, xsdgData) {
        const results = [];
        const ui = reportData.verificationInfo || {};

        if (xsdgData?.verifiedByName) {
            results.push(this._compare(
                'verifiedByName',
                ui.verifiedByName,
                xsdgData.verifiedByName,
            ));
        }

        if (xsdgData?.verifiedByEmpNum) {
            // Emp numbers may carry leading zeros (e.g. "00797971"); compare exact trimmed values.
            const expEmp = String(xsdgData.verifiedByEmpNum).trim();
            const uiEmp = String(ui.verifiedByEmpNum ?? '').trim();
            results.push({
                field: 'verifiedByEmpNum',
                expected: expEmp,
                actual: uiEmp,
                status: uiEmp === expEmp || uiEmp.replace(/^0+/, '') === expEmp.replace(/^0+/, '')
                    ? VALIDATION_STATUS.PASS
                    : VALIDATION_STATUS.FAIL,
            });
        }

        const allPassed = results.every(r => r.status === VALIDATION_STATUS.PASS);
        Logger.info('ERR-NtmXsdgValidator', `Verified-by validation: ${allPassed ? 'PASSED' : 'FAILED'}`, { results });
        return { results, allPassed };
    }

    // ==================== STATIC SECTIONS / END-OF-REPORT ====================

    /**
     * Static notice blocks that must appear on EVERY Emergency Response Report
     * regardless of flight/booking (the bin/unit-location note, USG-13 compartment
     * limits, the "all items OK" line and the loader-verification statement).
     * @type {Array<{field: string, text: string}>}
     */
    static EXPECTED_STATIC_NOTICES = [
        { field: 'binUnitLocationNote', text: 'Bin/Unit Location can be amended by Loading Crew Chief' },
        { field: 'usg13LimitsHeader', text: 'USG-13 Limits per COMPARTMENT' },
        { field: 'usg13NonFlammableGas', text: '75kg Non-flammable Gas' },
        { field: 'usg13OtherDgs', text: '25 kg other DGs' },
        { field: 'allItemsOk', text: 'All items OK for Passenger and Cargo Aircraft' },
        { field: 'loaderVerifies', text: 'Loader verifies that prior to placing the material on board the aircraft' },
    ];

    /**
     * Validates that the static notice blocks (same on all screens) are present.
     * @param {Object} reportData - Extracted UI report data
     * @returns {{ results: Array, allPassed: boolean }}
     */
    static validateStaticSections(reportData) {
        const results = [];
        const body = this._normalizeText(reportData?.staticNoticesText ?? '');

        for (const notice of this.EXPECTED_STATIC_NOTICES) {
            const present = body.includes(this._normalizeText(notice.text));
            results.push({
                field: notice.field,
                expected: notice.text,
                actual: present ? notice.text : '(not found on screen)',
                status: present ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL,
            });
        }

        const allPassed = results.every(r => r.status === VALIDATION_STATUS.PASS);
        Logger.info('ERR-NtmXsdgValidator', `Static sections validation: ${allPassed ? 'PASSED' : 'FAILED'}`, { results });
        return { results, allPassed };
    }

    /**
     * Validates the "End of Emergency Response Report" footer line, which echoes
     * the flight date, flight number, origin and destination. These are checked
     * against the NTM-derived expected values.
     * @param {Object} reportData - Extracted UI report data
     * @param {import('./NtmParser.js').NtmData} ntmData - Parsed NTM data
     * @returns {{ results: Array, allPassed: boolean }}
     */
    static validateEndOfReport(reportData, ntmData) {
        const results = [];
        const footer = String(reportData?.endOfReport ?? '');
        const ntmFlight = ntmData?.flightInfo || {};

        if (!footer) {
            results.push({
                field: 'endOfReportFooter',
                expected: 'End of Emergency Response Report footer',
                actual: '(not found on screen)',
                status: VALIDATION_STATUS.FAIL,
            });
            return { results, allPassed: false };
        }

        const footerNorm = footer.toUpperCase();

        // Flight date
        if (ntmFlight.flightDate) {
            const expDate = this._normalizeDate(ntmFlight.flightDate);
            results.push({
                field: 'endOfReport.flightDate',
                expected: ntmFlight.flightDate,
                actual: footer,
                status: footer.includes(ntmFlight.flightDate) || footer.includes(expDate)
                    ? VALIDATION_STATUS.PASS
                    : VALIDATION_STATUS.FAIL,
            });
        }

        // Flight number (NTM "0327" → footer "327"); match as a whole token
        if (ntmFlight.flightNumber) {
            const expNum = String(ntmFlight.flightNumber).replace(/^0+/, '');
            const footerNumMatch = new RegExp(`FLT\\s*NUM\\s*0*${expNum}\\b`, 'i').test(footer)
                || new RegExp(`\\b0*${expNum}\\b`).test(footer);
            results.push({
                field: 'endOfReport.flightNumber',
                expected: ntmFlight.flightNumber,
                actual: footer,
                status: footerNumMatch ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL,
            });
        }

        // Origin
        if (ntmFlight.origin) {
            const expOrig = String(ntmFlight.origin).toUpperCase();
            results.push({
                field: 'endOfReport.origin',
                expected: ntmFlight.origin,
                actual: footer,
                status: new RegExp(`FROM\\s*${expOrig}\\b`, 'i').test(footer) || footerNorm.includes(expOrig)
                    ? VALIDATION_STATUS.PASS
                    : VALIDATION_STATUS.FAIL,
            });
        }

        // Destination
        if (ntmFlight.destination) {
            const expDest = String(ntmFlight.destination).toUpperCase();
            results.push({
                field: 'endOfReport.destination',
                expected: ntmFlight.destination,
                actual: footer,
                status: new RegExp(`TO\\s*${expDest}\\b`, 'i').test(footer) || footerNorm.includes(expDest)
                    ? VALIDATION_STATUS.PASS
                    : VALIDATION_STATUS.FAIL,
            });
        }

        const allPassed = results.every(r => r.status === VALIDATION_STATUS.PASS);
        Logger.info('ERR-NtmXsdgValidator', `End-of-report validation: ${allPassed ? 'PASSED' : 'FAILED'}`, { results });
        return { results, allPassed };
    }

    // ==================== PER-ULD (MULTI-BOX) VALIDATION ====================

    /**
     * Validates the report on a per-ULD basis.
     *
     * A report that covers multiple ULDs renders one box per ULD. Each UI box is
     * matched to its NTM ULD group by Unit Num, and the box's hazmat rows are
     * validated, in order, against that ULD's NTM DG items (pieces, net weight,
     * packing group, RQ) while the shared per-AWB fields (proper shipping name,
     * class/division, UN id, AWB) are cross-checked against the XSDG.
     *
     * @param {Object} reportData - Extracted UI report data (must include `boxes`)
     * @param {import('./NtmParser.js').NtmData} ntmData - Parsed NTM data
     * @param {import('./XsdgParser.js').XsdgData} xsdgData - Parsed XSDG data
     * @returns {{ results: Array, allPassed: boolean, boxResults: Array }}
     */
    static validatePerUld(reportData, ntmData, xsdgData) {
        const results = [];
        const boxResults = [];
        const boxes = reportData?.boxes || [];
        const ntmGroups = NtmParser.groupByUld(ntmData?.dgItems || []);

        // Shared per-AWB XSDG values (same for every ULD box on this AWB).
        const xsdgItems = xsdgData?.dgItems || [];
        const sharedXsdg = xsdgItems[0] || {};

        // 1. Number of ULD boxes must equal the number of NTM ULD groups.
        results.push({
            field: 'uldBoxCount',
            expected: String(ntmGroups.length),
            actual: String(boxes.length),
            status: boxes.length === ntmGroups.length ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL,
        });

        // Index the UI boxes by their (normalized) unit number for matching.
        const boxByUld = new Map();
        for (const b of boxes) boxByUld.set(this._normalizeUld(b.unitNum), b);

        // 2. Validate each NTM ULD group against its matching UI box.
        for (const group of ntmGroups) {
            const sectionResults = [];
            const normUld = this._normalizeUld(group.uld);
            const box = boxByUld.get(normUld);

            // 2a. A UI box must exist for this ULD.
            sectionResults.push({
                field: 'unitNum',
                expected: group.uld,
                actual: box ? box.unitNum : '(no box found)',
                status: box ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL,
            });

            if (!box) {
                boxResults.push({ uld: group.uld, results: sectionResults });
                results.push(...sectionResults.map(r => ({ ...r, field: `uld[${group.uld}].${r.field}` })));
                continue;
            }

            // 2b. AWB shown on the box matches the XSDG AWB.
            if (xsdgData?.awbNumber) {
                const normXsdgAwb = this._normalizeAwb(xsdgData.awbNumber);
                const normBoxAwb = this._normalizeAwb(box.awbNumber || '');
                sectionResults.push({
                    field: 'awbNumber',
                    expected: xsdgData.awbNumber,
                    actual: box.awbNumber || '',
                    status: normBoxAwb === normXsdgAwb ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL,
                });
            }

            // 2c. Row count for this ULD.
            sectionResults.push({
                field: 'rowCount',
                expected: String(group.items.length),
                actual: String(box.hazmatRows.length),
                status: box.hazmatRows.length === group.items.length
                    ? VALIDATION_STATUS.PASS
                    : VALIDATION_STATUS.FAIL,
            });

            // 2d. Validate each row of the box against the ULD's NTM items (in order).
            const rowCount = Math.max(box.hazmatRows.length, group.items.length);
            for (let i = 0; i < rowCount; i++) {
                const uiRow = box.hazmatRows[i];
                const ntmItem = group.items[i];
                const rowLabel = `row[${i}]`;

                if (!uiRow || !ntmItem) {
                    sectionResults.push({
                        field: `${rowLabel}.present`,
                        expected: ntmItem ? 'UI row present' : 'no NTM item',
                        actual: uiRow ? 'UI row present' : 'missing',
                        status: VALIDATION_STATUS.FAIL,
                    });
                    continue;
                }

                // Shared (per-AWB) XSDG value, matched by UN id when possible.
                const xsdgItem = xsdgItems.find(
                    x => this._normalizeUnid(x.unid) === this._normalizeUnid(ntmItem.unid)
                ) || sharedXsdg;

                // Proper Shipping Name (XSDG shared; fall back to NTM).
                sectionResults.push(this._compareContains(
                    `${rowLabel}.properShippingName`,
                    uiRow.properShippingName,
                    xsdgItem.properShippingName || ntmItem.properShippingName,
                ));

                // Class / Division (XSDG shared; fall back to NTM).
                sectionResults.push(this._compare(
                    `${rowLabel}.classDivision`,
                    uiRow.classDivision,
                    xsdgItem.classDivision || ntmItem.classDivision,
                ));

                // UN / ID number (XSDG shared; fall back to NTM).
                const expUnid = xsdgItem.unid || ntmItem.unid;
                sectionResults.push({
                    field: `${rowLabel}.unid`,
                    expected: expUnid,
                    actual: uiRow.unIdNumber,
                    status: this._normalizeUnid(uiRow.unIdNumber) === this._normalizeUnid(expUnid)
                        ? VALIDATION_STATUS.PASS
                        : VALIDATION_STATUS.FAIL,
                });

                // Number of pieces (NTM per-ULD).
                sectionResults.push({
                    field: `${rowLabel}.numPcs`,
                    expected: String(ntmItem.pieces),
                    actual: uiRow.numPcs,
                    status: String(uiRow.numPcs || '').trim() === String(ntmItem.pieces).trim()
                        ? VALIDATION_STATUS.PASS
                        : VALIDATION_STATUS.FAIL,
                });

                // Net quantity / weight (NTM per-ULD). NTM is numeric with a unit flag
                // ("K" = kg); build a unit-bearing value so it normalizes against the
                // UI's "26.000kg".
                const expectedNetQty = `${ntmItem.netQty}${ntmItem.netQtyUnit === 'K' ? 'kg' : ''}`;
                sectionResults.push(this._compareWeight(
                    `${rowLabel}.netQty`,
                    uiRow.netQty,
                    expectedNetQty,
                ));

                // Packing group (NTM per-ULD).
                if (ntmItem.packingGroup) {
                    const normUiPg = (uiRow.packingGroup || '').split('-')[0].trim().toUpperCase();
                    const normExpPg = (ntmItem.packingGroup || '').split('-')[0].trim().toUpperCase();
                    sectionResults.push({
                        field: `${rowLabel}.packingGroup`,
                        expected: ntmItem.packingGroup,
                        actual: uiRow.packingGroup,
                        status: normUiPg === normExpPg ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL,
                    });
                }

                // Reportable quantity (NTM per-ULD; blank UI cell means "N").
                const expectedRq = ntmItem.rq === 'Y' ? 'Y' : 'N';
                const actualRq = (uiRow.rq || '').trim() === '' ? 'N' : (uiRow.rq || '').trim();
                sectionResults.push({
                    field: `${rowLabel}.rq`,
                    expected: expectedRq,
                    actual: actualRq,
                    status: expectedRq.toLowerCase() === actualRq.toLowerCase()
                        ? VALIDATION_STATUS.PASS
                        : VALIDATION_STATUS.FAIL,
                });
            }

            boxResults.push({ uld: group.uld, results: sectionResults });
            results.push(...sectionResults.map(r => ({ ...r, field: `uld[${group.uld}].${r.field}` })));
        }

        const allPassed = results.every(r => r.status === VALIDATION_STATUS.PASS);
        Logger.info('ERR-NtmXsdgValidator', `Per-ULD validation: ${allPassed ? 'ALL PASSED' : 'FAILURES'}`, {
            boxes: boxes.length,
            ntmGroups: ntmGroups.length,
            total: results.length,
            failed: results.filter(r => r.status !== VALIDATION_STATUS.PASS).length,
        });
        return { results, allPassed, boxResults };
    }

    /**
     * Generates an HTML report with one comparison table per ULD box.
     * @param {Array<{uld: string, results: Array}>} boxResults
     * @returns {string} HTML content
     */
    static generatePerUldHtml(boxResults) {
        const totalChecks = boxResults.reduce((s, b) => s + b.results.length, 0);
        const totalFailed = boxResults.reduce(
            (s, b) => s + b.results.filter(r => r.status !== VALIDATION_STATUS.PASS).length, 0);
        const overallColor = totalFailed === 0 ? '#2e7d32' : '#c62828';
        const overallLabel = totalFailed === 0 ? '\u2705 ALL ULD BOXES MATCHED' : `\u274c ${totalFailed} MISMATCH(ES)`;

        const boxSections = boxResults.map(box => {
            const passed = box.results.filter(r => r.status === VALIDATION_STATUS.PASS).length;
            const failed = box.results.filter(r => r.status !== VALIDATION_STATUS.PASS).length;
            const boxColor = failed === 0 ? '#2e7d32' : '#c62828';
            const rows = box.results.map(r => {
                const cls = r.status === VALIDATION_STATUS.PASS ? 'pass' : 'fail';
                const icon = r.status === VALIDATION_STATUS.PASS ? '\u2705' : '\u274c';
                return `<tr class="${cls}">
                    <td>${escHtml(r.field)}</td>
                    <td><code>${escHtml(String(r.expected ?? ''))}</code></td>
                    <td><code>${escHtml(String(r.actual ?? ''))}</code></td>
                    <td>${icon} ${r.status}</td>
                </tr>`;
            }).join('');
            return `<h3 style="border-left-color:${boxColor}">ULD: ${escHtml(box.uld)}
                <span style="font-size:0.8em;color:${boxColor}">(${passed} matched, ${failed} mismatched)</span></h3>
            <table><tr><th>Field</th><th>Expected (NTM per-ULD / XSDG shared)</th><th>Actual (UI Box)</th><th>Status</th></tr>
            ${rows || '<tr><td colspan="4">No rows</td></tr>'}
            </table>`;
        }).join('');

        return `<!DOCTYPE html>
<html><head><meta charset="UTF-8">
<style>
  body { font-family: Arial, sans-serif; margin: 20px; color: #333; }
  h2 { color: #1976d2; border-bottom: 2px solid #1976d2; padding-bottom: 6px; }
  h3 { color: #444; margin-top: 24px; border-left: 4px solid #1976d2; padding-left: 10px; }
  .summary { font-size: 1.05em; margin-bottom: 14px; }
  .overall { font-weight: bold; color: ${overallColor}; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 18px; }
  th, td { border: 1px solid #ddd; padding: 8px 10px; text-align: left; vertical-align: top; }
  th { background: #1976d2; color: #fff; }
  .pass { background: #e8f5e9; color: #2e7d32; }
  .fail { background: #ffebee; color: #c62828; }
  code { background: #f5f5f5; padding: 2px 5px; border-radius: 3px; font-size: 0.92em; }
</style>
</head><body>
<h2>Per-ULD Validation \u2014 UI Boxes vs NTM (per ULD) + XSDG (shared)</h2>
<p class="summary"><b>ULD boxes:</b> ${boxResults.length} &nbsp;|&nbsp;
  <b>Total checks:</b> ${totalChecks} &nbsp;|&nbsp;
  <span class="overall">${overallLabel}</span></p>
${boxSections || '<p>No ULD boxes found.</p>'}
</body></html>`;
    }

    // ==================== FULL VALIDATION WRAPPER ====================

    /**
     * Runs all validation areas and returns a combined summary.
     * Attaches rich HTML comparison table and JSON results to Allure.
     *
     * @param {Object} reportData - UI report data
     * @param {import('./XsdgParser.js').XsdgData} xsdgData - Parsed XSDG data
     * @param {import('./NtmParser.js').NtmData} ntmData - Parsed NTM data
     * @returns {Promise<{allResults: Array, overallPassed: boolean, summary: Object}>}
     */
    static async validateAll(reportData, xsdgData, ntmData) {
        return allure.step('Full Validation: UI (Actual) vs NTM + XSDG (Expected)', async () => {
            const flightResult = this.validateFlightInfo(reportData, ntmData.flightInfo);
            const awbResult = this.validateAwbInfo(reportData, xsdgData);
            const perUldResult = this.validatePerUld(reportData, ntmData, xsdgData);
            const emergencyResult = this.validateEmergencyContact(reportData);
            const handlingResult = this.validateSpecialHandling(reportData, xsdgData);
            const verifiedByResult = this.validateVerifiedBy(reportData, xsdgData);
            const staticResult = this.validateStaticSections(reportData);
            const endOfReportResult = this.validateEndOfReport(reportData, ntmData);

            const allResults = [
                ...flightResult.results,
                ...awbResult.results,
                ...perUldResult.results,
                ...emergencyResult.results,
                ...handlingResult.results,
                ...verifiedByResult.results,
                ...staticResult.results,
                ...endOfReportResult.results,
            ];

            const passed = allResults.filter(r => r.status === VALIDATION_STATUS.PASS).length;
            const failed = allResults.filter(r => r.status !== VALIDATION_STATUS.PASS).length;
            const overallPassed = failed === 0;

            const summary = {
                total: allResults.length,
                passed,
                failed,
                overallPassed,
                flightInfoPassed: flightResult.allPassed,
                awbPassed: awbResult.allPassed,
                perUldPassed: perUldResult.allPassed,
                emergencyContactPassed: emergencyResult.allPassed,
                specialHandlingPassed: handlingResult.allPassed,
                verifiedByPassed: verifiedByResult.allPassed,
                staticSectionsPassed: staticResult.allPassed,
                endOfReportPassed: endOfReportResult.allPassed,
            };

            await allure.attachment('Full Validation Results (JSON)',
                JSON.stringify(allResults, null, 2), 'application/json');
            await allure.attachment('Per-ULD Validation (UI Boxes vs NTM + XSDG)',
                this.generatePerUldHtml(perUldResult.boxResults), 'text/html');
            await allure.attachment('Validation Summary HTML',
                this._generateHtmlReport(allResults, xsdgData, ntmData), 'text/html');

            Logger.info('ERR-NtmXsdgValidator', `Overall validation: ${overallPassed ? 'ALL PASSED' : 'FAILURES'}`, summary);

            return {
                allResults, overallPassed, summary,
                flightResult, awbResult, perUldResult,
                emergencyResult, handlingResult, verifiedByResult,
                staticResult, endOfReportResult,
            };
        });
    }

    // ==================== PRIVATE HELPERS ====================

    /**
     * Normalizes a date string to MM/DD/YYYY format for comparison.
     * Handles YYYY-MM-DD and MM/DD/YYYY inputs.
     * @param {string} dateStr
     * @returns {string}
     * @private
     */
    static _normalizeDate(dateStr) {
        if (!dateStr) return '';
        // YYYY-MM-DD → MM/DD/YYYY
        const isoMatch = dateStr.match(/^(\d{4})-(\d{2})-(\d{2})$/);
        if (isoMatch) return `${isoMatch[2]}/${isoMatch[3]}/${isoMatch[1]}`;
        return dateStr;
    }

    /**
     * Normalizes a UNID string for comparison.
     * "UN2915" → "2915", "U2915" → "2915", "2915" → "2915"
     * @param {string} unid
     * @returns {string}
     * @private
     */
    static _normalizeUnid(unid) {
        return String(unid || '').trim().replace(/^UN?/i, '');
    }

    /**
     * Normalizes an AWB for loose comparison.
     * Extracts only the digit portion to handle different formatting:
     * "001-24456040" → "24456040", "001ORD24456040" → "24456040"
     * @param {string} awb
     * @returns {string}
     * @private
     */
    static _normalizeAwb(awb) {
        // Keep only digits, then strip leading zeros
        const digitsOnly = String(awb || '').replace(/\D/g, '');
        return digitsOnly.replace(/^0+/, '');
    }

    /**
     * Normalizes a ULD / unit number for comparison (upper-cased, alphanumerics only).
     * "AKE 72464 AA" → "AKE72464AA".
     * @param {string} uld
     * @returns {string}
     * @private
     */
    static _normalizeUld(uld) {
        return String(uld || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    }

    /**
     * Normalizes free text for comparison (collapses whitespace, lower-cases).
     * @param {string} str
     * @returns {string}
     * @private
     */
    static _normalizeText(str) {
        return String(str ?? '').replace(/\s+/g, ' ').trim().toLowerCase();
    }

    /**
     * Normalizes a weight/quantity string.
     * Strips trailing decimal zeros and maps unit abbreviations.
     * @param {string} str
     * @returns {string}
     * @private
     */
    static _normalizeWeightStr(str) {
        // Strip "TI" (Transport Index) suffix that the UI appends to radioactive net quantities
        // e.g. "1.000TI" → "1.000", "0.200TI" → "0.200"
        const s = String(str ?? '').trim().replace(/\s*TI\s*$/i, '');
        const match = s.match(/^([\d.]+)\s*(.*)$/);
        if (!match) return s.toLowerCase();

        const num = parseFloat(match[1]);
        let unit = match[2].trim().toLowerCase();
        const unitMap = {
            l: 'liter', kg: 'kilogram', g: 'gram', ml: 'milliliter',
            lb: 'pound', oz: 'ounce', gal: 'gallon',
        };
        unit = unitMap[unit] || unit;

        return `${num}${unit}`;
    }

    /**
     * Generates a focused HTML comparison table for a single validation section.
     * Shows each field with its Expected (source) value, the Actual (UI screen)
     * value, and the PASS/FAIL status — making the UI-vs-source comparison explicit.
     *
     * @param {string} title - Section heading (e.g. "Flight Info — NTM vs UI Screen")
     * @param {Array} results - Validation results for this section
     * @param {string} expectedSource - Label for the expected column (e.g. "NTM", "XSDG", "XSDG/NTM")
     * @returns {string} HTML content
     */
    static generateSectionHtml(title, results, expectedSource = 'NTM/XSDG') {
        const passed = results.filter(r => r.status === VALIDATION_STATUS.PASS).length;
        const failed = results.filter(r => r.status !== VALIDATION_STATUS.PASS).length;
        const overallColor = failed === 0 ? '#2e7d32' : '#c62828';
        const overallLabel = failed === 0 ? '\u2705 ALL MATCHED' : `\u274c ${failed} MISMATCH(ES)`;

        const rows = results.map(r => {
            const cls = r.status === VALIDATION_STATUS.PASS ? 'pass' : 'fail';
            const icon = r.status === VALIDATION_STATUS.PASS ? '\u2705' : '\u274c';
            return `<tr class="${cls}">
                <td>${escHtml(r.field)}</td>
                <td><code>${escHtml(String(r.expected ?? ''))}</code></td>
                <td><code>${escHtml(String(r.actual ?? ''))}</code></td>
                <td>${icon} ${r.status}</td>
            </tr>`;
        }).join('');

        return `<!DOCTYPE html>
<html><head><meta charset="UTF-8">
<style>
  body { font-family: Arial, sans-serif; margin: 20px; color: #333; }
  h2 { color: #1976d2; border-bottom: 2px solid #1976d2; padding-bottom: 6px; }
  .summary { font-size: 1.05em; margin-bottom: 14px; }
  .overall { font-weight: bold; color: ${overallColor}; }
  table { width: 100%; border-collapse: collapse; }
  th, td { border: 1px solid #ddd; padding: 8px 10px; text-align: left; vertical-align: top; }
  th { background: #1976d2; color: #fff; }
  .pass { background: #e8f5e9; color: #2e7d32; }
  .fail { background: #ffebee; color: #c62828; }
  code { background: #f5f5f5; padding: 2px 5px; border-radius: 3px; font-size: 0.92em; }
</style>
</head><body>
<h2>${escHtml(title)}</h2>
<p class="summary"><b>Total:</b> ${results.length} &nbsp;|&nbsp;
  <span style="color:#2e7d32"><b>Matched:</b> ${passed}</span> &nbsp;|&nbsp;
  <span style="color:#c62828"><b>Mismatched:</b> ${failed}</span> &nbsp;|&nbsp;
  <span class="overall">${overallLabel}</span></p>
<table>
  <tr><th>Field</th><th>Expected (${escHtml(expectedSource)})</th><th>Actual (UI Screen)</th><th>Status</th></tr>
  ${rows || '<tr><td colspan="4">No results</td></tr>'}
</table>
</body></html>`;
    }

    /**
     * Generates a rich HTML validation comparison report for Allure.
     * Mirrors the DB validator's _generateHtmlReport style but labels
     * columns as "Expected (NTM/XSDG)" vs "Actual (UI)".
     * @param {Array} results - All validation results
     * @param {import('./XsdgParser.js').XsdgData} xsdgData - Parsed XSDG data
     * @param {import('./NtmParser.js').NtmData} ntmData - Parsed NTM data
     * @returns {string} HTML content
     * @private
     */
    static _generateHtmlReport(results, xsdgData, ntmData) {
        const passed = results.filter(r => r.status === VALIDATION_STATUS.PASS).length;
        const failed = results.filter(r => r.status !== VALIDATION_STATUS.PASS).length;
        const overallColor = failed === 0 ? '#2e7d32' : '#c62828';
        const overallLabel = failed === 0 ? '✅ ALL PASSED' : `❌ ${failed} FAILURE(S)`;

        // Section grouping for readability
        const sections = [
            { label: 'Flight Info (NTM → UI)', prefix: 'flight', source: 'NTM' },
            { label: 'AWB Info (XSDG → UI)', prefix: 'awb', source: 'XSDG' },
            { label: 'Hazmat Rows (XSDG + NTM → UI)', prefix: 'row', source: 'XSDG + NTM' },
            { label: 'Row Count', prefix: 'hazmat', source: 'XSDG' },
        ];

        const renderRows = (filterFn) => results
            .filter(r => filterFn(r.field))
            .map(r => {
                const cls = r.status === VALIDATION_STATUS.PASS ? 'pass' : 'fail';
                const icon = r.status === VALIDATION_STATUS.PASS ? '✅' : '❌';
                return `<tr class="${cls}">
                    <td>${r.field}</td>
                    <td><code>${escHtml(String(r.expected ?? ''))}</code></td>
                    <td><code>${escHtml(String(r.actual ?? ''))}</code></td>
                    <td>${icon} ${r.status}</td>
                </tr>`;
            }).join('');

        const flightRows = renderRows(f => ['flightNumber','flightDate','origin','destination','unitNumber'].includes(f));
        const awbRows = renderRows(f => ['awbNumber','awbHeaders','awbOrigin','awbTotalPackages'].includes(f));
        const uldCountRows = renderRows(f => f === 'uldBoxCount');
        const perUldRows = renderRows(f => f.startsWith('uld['));
        const emergencyRows = renderRows(f => f === 'emergencyContactDomestic');
        const handlingRows = renderRows(f => f === 'specialHandlingInfo');
        const verifiedByRows = renderRows(f => ['verifiedByName','verifiedByEmpNum'].includes(f));
        const staticFields = this.EXPECTED_STATIC_NOTICES.map(n => n.field);
        const staticRows = renderRows(f => staticFields.includes(f));
        const endOfReportRows = renderRows(f => f === 'endOfReportFooter' || f.startsWith('endOfReport.'));

        const ntmFlight = ntmData?.flightInfo || {};
        const xsdgSummary = xsdgData ? [
            `AWB: ${xsdgData.awbNumber}`,
            `Shipper: ${xsdgData.shipperName}`,
            `Origin: ${xsdgData.origin} → ${xsdgData.destination}`,
            `DG Items: ${xsdgData.dgItems?.length ?? 0}`,
            `Emergency Contact: ${xsdgData.emergencyContact} (${xsdgData.emergencyPhone})`,
        ].join('<br>') : 'N/A';

        const ntmSummary = ntmData ? [
            `Flight: AA${ntmFlight.flightNumber}`,
            `Date: ${ntmFlight.flightDate}`,
            `Route: ${ntmFlight.origin} → ${ntmFlight.destination}`,
            `DG Items: ${ntmData.dgItems?.length ?? 0}`,
        ].join('<br>') : 'N/A';

        return `<!DOCTYPE html>
<html><head><meta charset="UTF-8">
<style>
  body { font-family: Arial, sans-serif; margin: 20px; color: #333; }
  h2 { color: #1976d2; border-bottom: 2px solid #1976d2; padding-bottom: 6px; }
  h3 { color: #444; margin-top: 24px; border-left: 4px solid #1976d2; padding-left: 10px; }
  .summary-box { background: #f5f5f5; border: 1px solid #ddd; padding: 12px 16px; border-radius: 6px; margin-bottom: 20px; display: flex; gap: 32px; }
  .summary-box .stat { text-align: center; }
  .summary-box .stat .num { font-size: 2em; font-weight: bold; }
  .source-box { background: #e3f2fd; border: 1px solid #90caf9; padding: 10px 16px; border-radius: 6px; margin-bottom: 16px; }
  .source-box h4 { margin: 0 0 6px; color: #1565c0; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 24px; }
  th, td { border: 1px solid #ddd; padding: 8px 10px; text-align: left; }
  th { background: #1976d2; color: #fff; }
  .pass { background: #e8f5e9; color: #2e7d32; }
  .fail { background: #ffebee; color: #c62828; }
  code { background: #f5f5f5; padding: 2px 4px; border-radius: 3px; font-size: 0.9em; }
  .overall { font-size: 1.2em; font-weight: bold; color: ${overallColor}; }
</style>
</head><body>
<h2>Emergency Response Report — NTM + XSDG vs UI Validation</h2>

<div class="summary-box">
  <div class="stat"><div class="num">${results.length}</div><div>Total Checks</div></div>
  <div class="stat"><div class="num" style="color:#2e7d32">${passed}</div><div>Passed</div></div>
  <div class="stat"><div class="num" style="color:#c62828">${failed}</div><div>Failed</div></div>
  <div class="stat"><div class="overall">${overallLabel}</div></div>
</div>

<div style="display:flex;gap:16px;margin-bottom:20px">
  <div class="source-box" style="flex:1"><h4>📄 NTM (Expected Flight Data)</h4>${ntmSummary}</div>
  <div class="source-box" style="flex:1"><h4>📋 XSDG (Expected DG Data)</h4>${xsdgSummary}</div>
</div>

<h3>Flight Info Validation — NTM vs UI</h3>
<table><tr><th>Field</th><th>Expected (NTM)</th><th>Actual (UI)</th><th>Status</th></tr>
${flightRows || '<tr><td colspan="4">No flight info results</td></tr>'}
</table>

<h3>AWB Info Validation — XSDG vs UI</h3>
<table><tr><th>Field</th><th>Expected (XSDG)</th><th>Actual (UI)</th><th>Status</th></tr>
${awbRows || '<tr><td colspan="4">No AWB results</td></tr>'}
</table>

<h3>ULD Box Count — NTM vs UI</h3>
<table><tr><th>Field</th><th>Expected (NTM)</th><th>Actual (UI)</th><th>Status</th></tr>
${uldCountRows || '<tr><td colspan="4">No count results</td></tr>'}
</table>

<h3>Per-ULD Hazmat Detail — NTM (per ULD) + XSDG (shared) vs UI Boxes</h3>
<table><tr><th>Field</th><th>Expected (XSDG/NTM)</th><th>Actual (UI)</th><th>Status</th></tr>
${perUldRows || '<tr><td colspan="4">No per-ULD results</td></tr>'}
</table>

<h3>Emergency Contact Num (Static) — vs UI</h3>
<table><tr><th>Field</th><th>Expected (Static)</th><th>Actual (UI)</th><th>Status</th></tr>
${emergencyRows || '<tr><td colspan="4">No emergency contact results</td></tr>'}
</table>

<h3>Special Handling Info — XSDG vs UI</h3>
<table><tr><th>Field</th><th>Expected (XSDG)</th><th>Actual (UI)</th><th>Status</th></tr>
${handlingRows || '<tr><td colspan="4">No special handling results</td></tr>'}
</table>

<h3>Verified By — XSDG vs UI</h3>
<table><tr><th>Field</th><th>Expected (XSDG)</th><th>Actual (UI)</th><th>Status</th></tr>
${verifiedByRows || '<tr><td colspan="4">No verified-by results</td></tr>'}
</table>

<h3>Static Notices (Same on all screens) — Expected vs UI</h3>
<table><tr><th>Field</th><th>Expected (Static)</th><th>Actual (UI)</th><th>Status</th></tr>
${staticRows || '<tr><td colspan="4">No static notice results</td></tr>'}
</table>

<h3>End of Report Footer — NTM vs UI</h3>
<table><tr><th>Field</th><th>Expected (NTM)</th><th>Actual (UI Footer)</th><th>Status</th></tr>
${endOfReportRows || '<tr><td colspan="4">No end-of-report results</td></tr>'}
</table>

</body></html>`;
    }

    /**
     * Compares two values for equality (case-insensitive, trimmed).
     * @param {string} field
     * @param {*} actual - UI value
     * @param {*} expected - NTM/XSDG value
     * @returns {Object} Validation result
     * @private
     */
    static _compare(field, actual, expected) {
        const a = String(actual ?? '').trim().toLowerCase();
        const e = String(expected ?? '').trim().toLowerCase();
        return {
            field,
            expected: String(expected ?? '').trim(),
            actual: String(actual ?? '').trim(),
            status: a === e ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL,
        };
    }

    /**
     * Compares using "contains" logic — actual should contain expected substring.
     * Used for proper shipping names where UI may abbreviate.
     * @param {string} field
     * @param {*} actual - UI value
     * @param {*} expected - XSDG value
     * @returns {Object}
     * @private
     */
    static _compareContains(field, actual, expected) {
        const a = String(actual ?? '').trim().toLowerCase();
        const e = String(expected ?? '').trim().toLowerCase();
        const found = a.includes(e) || e.includes(a);
        return {
            field,
            expected: String(expected ?? '').trim(),
            actual: String(actual ?? '').trim(),
            status: found ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL,
        };
    }

    /**
     * Compares two weight/quantity values with unit normalization.
     * @param {string} field
     * @param {*} actual - UI value
     * @param {*} expected - NTM/XSDG value
     * @returns {Object}
     * @private
     */
    static _compareWeight(field, actual, expected) {
        const normActual = this._normalizeWeightStr(actual);
        const normExpected = this._normalizeWeightStr(expected);
        const matched = normActual === normExpected;

        // When the values are equivalent, present a cleaned numeric form for BOTH
        // columns so UI display formatting (e.g. trailing zeros and the "TI" suffix
        // in "0.200TI") does not look like a mismatch against the source "0.2".
        const cleanNum = (s) => {
            const stripped = String(s ?? '').trim().replace(/\s*TI\s*$/i, '');
            const m = stripped.match(/^([\d.]+)(.*)$/);
            if (!m) return String(s ?? '').trim();
            return `${parseFloat(m[1])}${m[2].trim()}`;
        };

        return {
            field,
            expected: matched ? cleanNum(expected) : String(expected ?? '').trim(),
            actual: matched ? cleanNum(actual) : String(actual ?? '').trim(),
            status: matched ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL,
        };
    }
}
