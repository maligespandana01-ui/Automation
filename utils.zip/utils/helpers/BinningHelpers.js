/**
 * @charset UTF-8
 * BinningHelpers.js - Utility methods for binning automation
 *
 * Provides:
 * - UNID generation (origin prefix + random digits)
 * - Random bin location selection
 * - XSDG/NTM template placeholder replacement from CSV flight data
 * - CSV flight data reader
 */
import fs from 'fs';
import path from 'path';
import { replaceDatePlaceholders } from './DateUtils.js';
import { Logger } from './Logger.js';

/**
 * Generates a random UNID in format: first 3 letters of origin + random 3-5 digit number.
 * Example: origin "DFW" → "DFW4821" or "DFW12345"
 * @param {string} origin - 3-letter origin airport code (e.g., "DFW", "MIA", "CLT")
 * @returns {string} Generated UNID (e.g., "DFW4821")
 */
export function generateUnid(origin) {
    const prefix = origin.substring(0, 3).toUpperCase();
    const digitCount = Math.floor(Math.random() * 3) + 3; // 3, 4, or 5 digits
    const min = Math.pow(10, digitCount - 1);
    const max = Math.pow(10, digitCount) - 1;
    const randomNum = Math.floor(Math.random() * (max - min + 1)) + min;
    const unid = `${prefix}${randomNum}`;
    Logger.info('BinningHelpers', `Generated UNID: ${unid} (origin: ${origin})`);
    return unid;
}

/**
 * Available bin locations in the AutoNOTOC Bin Assignment screen.
 */
const BIN_LOCATIONS = ['A1', 'A2', 'F1', 'F2'];
const BIN_COMPARTMENTS = {
    'A1': 'A1 (AFT)',
    'A2': 'A2 (AFT)',
    'F1': 'F1 (FWD)',
    'F2': 'F2 (FWD)',
};

/**
 * Selects a random bin location from the available options.
 * @param {string[]} [exclude=[]] - Bin locations to exclude (e.g., already assigned)
 * @returns {{ binLocation: string, compartment: string }}
 */
export function getRandomBinLocation(exclude = []) {
    const available = BIN_LOCATIONS.filter(b => !exclude.includes(b));
    if (available.length === 0) {
        Logger.warn('BinningHelpers', 'All bin locations excluded, falling back to A1');
        return { binLocation: 'A1', compartment: BIN_COMPARTMENTS['A1'] };
    }
    const selected = available[Math.floor(Math.random() * available.length)];
    Logger.info('BinningHelpers', `Random bin location selected: ${selected}`);
    return { binLocation: selected, compartment: BIN_COMPARTMENTS[selected] };
}

/**
 * Gets a different random bin location from the current one (for change bin tests).
 * @param {string} currentBin - Current bin location to avoid
 * @returns {{ binLocation: string, compartment: string }}
 */
export function getDifferentBinLocation(currentBin) {
    return getRandomBinLocation([currentBin]);
}

/**
 * Reads the flight data CSV and returns parsed rows.
 * @param {string} csvPath - Absolute path to the CSV file
 * @param {string} timezone - Timezone for date placeholder resolution
 * @returns {Array<Object>} Parsed flight data rows
 */
export function readFlightDataCsv(csvPath, timezone) {
    const raw = fs.readFileSync(csvPath, 'utf-8');
    const lines = raw.trim().split('\n');
    const headers = lines[0].split(',').map(h => h.trim());
    const rows = [];

    for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',').map(v => v.trim());
        const row = {};
        headers.forEach((h, idx) => {
            let val = values[idx] || '';
            // Resolve date placeholders
            if (val.includes('${date')) {
                val = replaceDatePlaceholders(val, timezone);
            }
            row[h] = val;
        });
        rows.push(row);
    }
    Logger.info('BinningHelpers', `Read ${rows.length} flight data rows from CSV`);
    return rows;
}

/**
 * Replaces all placeholders in an XSDG XML template with actual values.
 * Placeholders: ${awb1}, ${flightNumber}, ${origin}, ${destination}, ${date|...}, ${unid}
 * @param {string} template - XSDG XML template string
 * @param {Object} replacements - Key-value pairs for replacement
 * @param {string} replacements.awb - AWB number
 * @param {string} replacements.flightNumber - Flight number
 * @param {string} replacements.origin - Origin airport code
 * @param {string} replacements.destination - Destination airport code
 * @param {string} [replacements.unid] - UNID number (optional, fills in XSDG UNID_NBR)
 * @param {string} timezone - Timezone for date resolution
 * @returns {string} Resolved XSDG XML
 */
export function resolveXsdgTemplate(template, replacements, timezone) {
    let xml = template;
    xml = xml.replaceAll('${awb1}', replacements.awb);
    xml = xml.replaceAll('${flightNumber}', replacements.flightNumber);
    xml = xml.replaceAll('${origin}', replacements.origin);
    xml = xml.replaceAll('${destination}', replacements.destination);
    if (replacements.unid) {
        xml = xml.replaceAll('${unid}', replacements.unid);
    }
    xml = replaceDatePlaceholders(xml, timezone);
    return xml;
}

/**
 * Replaces all placeholders in an NTM message template with actual values.
 * Also injects the generated UNID into the NTM DNG line.
 * @param {string} template - NTM message template string
 * @param {Object} replacements - Key-value pairs
 * @param {string} replacements.awb - AWB number
 * @param {string} replacements.flightNumber - Flight number
 * @param {string} replacements.origin - Origin airport code
 * @param {string} replacements.destination - Destination airport code
 * @param {string} [replacements.unid] - UNID number (optional)
 * @param {string} timezone - Timezone for date resolution
 * @returns {string} Resolved NTM message
 */
export function resolveNtmTemplate(template, replacements, timezone) {
    let ntm = template;
    ntm = ntm.replaceAll('${awb1}', replacements.awb);
    ntm = ntm.replaceAll('${flightNumber}', replacements.flightNumber);
    ntm = ntm.replaceAll('${origin}', replacements.origin);
    ntm = ntm.replaceAll('${destination}', replacements.destination);
    if (replacements.unid) {
        ntm = ntm.replaceAll('${unid}', replacements.unid);
    }
    ntm = replaceDatePlaceholders(ntm, timezone);
    return ntm;
}

/**
 * Fetches flight details from a test data entry (NTM/XSDG test case).
 * Returns the flight date, number, origin, and destination for UI form filling.
 * @param {Object} testCase - Test case data object
 * @param {string} timezone - Timezone for date resolution
 * @returns {{ flightDate: string, flightNumber: string, origin: string, destination: string }}
 */
export function fetchFlightDetailsFromTestData(testCase, timezone) {
    return {
        flightDate: testCase.flightDate.includes('${date')
            ? replaceDatePlaceholders(testCase.flightDate, timezone)
            : testCase.flightDate,
        flightNumber: testCase.flightNumber,
        origin: testCase.origin,
        destination: testCase.destination,
    };
}
