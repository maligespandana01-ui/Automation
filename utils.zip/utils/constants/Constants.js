// constants.js

export const TIMEOUTS = {
    V_SHORT: 2000,
    SHORT: 5000,
    MEDIUM: 10000,
    LONG: 20000,
    EXECUTION_TIMEOUT: 0,
};

export const STATUS_CODES = {
    OK: 200,
    CREATED: 201,
    ACCEPTED: 202,
    NO_CONTENT: 204,
    BAD_REQUEST: 400,
    UNAUTHORIZED: 401,
    FORBIDDEN: 403,
    NOT_FOUND: 404,
    INTERNAL_SERVER_ERROR: 500,
};

export const VALIDATION_STATUS = {
    PASS: 'PASS',
    FAIL: 'FAIL',
    SKIP: 'IGNORED'
};

export const DEFAULT_VALUES = {
    NOT_FOUND: '(not found)',
    MISSING: '(missing)',
    EMPTY: '(empty)',
    NA: 'N/A'
};

export const ENV_CONFIG_KEYS = {
    //environments
    DEVELOPMENT: 'development',
    PRODUCTION: 'production',
    STAGING: 'staging',

    //config keys
    CARGO_API: 'cargoApi',
    PARSE_ENDPOINT: 'parseEndpoint',

    //url keys
    URL_BASE: 'URL_BASE',
    URL_RAMPLINK: 'URL_RAMPLINK',
    URL_ICARGO: 'URL_ICARGO',
    URL_OPSHUB: 'URL_OPSHUB',
    URL_HAZRAPS: 'URL_HAZRAPS',
    URL_AUTONOTOC_HAZRAPS_STAGE_LEGACY: 'URL_AUTONOTOC_HAZRAPS_STAGE_LEGACY',
    URL_ACARS: 'URL_ACARS',
    URL_ICARGO_EXTERNAL: 'URL_ICARGO_EXTERNAL',

    //db config keys
    DB_HOST: 'DB_HOST',
    DB_PORT: 'DB_PORT',
    DB_NAME: 'DB_NAME',
    DB_USERNAME: 'DB_USERNAME',
    DB_PASSWORD: 'DB_PASSWORD',

    //endpoints
    API_ENDPOINT_NOTOC_PARSE: 'API_ENDPOINT_NOTOC_PARSE',
    API_ENDPOINT_NOTOC_TRIGGER: 'API_ENDPOINT_NOTOC_TRIGGER',
    API_ENDPOINT_NOTOC_HEADER_CONTENT_TYPE: 'API_ENDPOINT_NOTOC_HEADER_CONTENT_TYPE',
    API_ENDPOINT_NOTOC_RAMPLINK_NOTIFICATION: 'API_ENDPOINT_NOTOC_RAMPLINK_NOTIFICATION',
    API_ENDPOINT_OPSHUB_FLIGHT_STATUS: 'API_ENDPOINT_OPSHUB_FLIGHT_STATUS',
    API_ENDPOINT_OPSHUB_FLIGHT_INFO: 'API_ENDPOINT_OPSHUB_FLIGHT_INFO',
    API_ENDPOINT_GET_CREW_BASE: 'API_ENDPOINT_GET_CREW_BASE',
    API_ENDPOINT_FLIGHT_CREW_BASE_MAINTAIN: 'API_ENDPOINT_FLIGHT_CREW_BASE_MAINTAIN',
    API_ENDPOINT_FLIGHT_CREW_BASE_DELETE: 'API_ENDPOINT_FLIGHT_CREW_BASE_DELETE',
    API_ENDPOINT_FLIGHT_CREW_BASE_LIST: 'API_ENDPOINT_FLIGHT_CREW_BASE_LIST',
    API_ENDPOINT_FTM_UPLINK: 'API_ENDPOINT_FTM_UPLINK',
    URL_AUTONOTOC_LEGACY_INTERFACEAPP_STAGE: 'URL_AUTONOTOC_LEGACY_INTERFACEAPP_STAGE',
    API_ENDPOINT_HAZRAPS_LEGACY: 'API_ENDPOINT_HAZRAPS_LEGACY',
    API_ENDPOINT_HAZRAPS_REWRITE: 'API_ENDPOINT_HAZRAPS_REWRITE',
    URL_AUTONOTOC_HAZRAPS_STAGE: 'URL_AUTONOTOC_HAZRAPS_STAGE',

    //url keys
    URL_BASE: 'URL_BASE',
    URL_RAMPLINK: 'URL_RAMPLINK',
    URL_ICARGO: 'URL_ICARGO',
    URL_OPSHUB: 'URL_OPSHUB',
    URL_HAZRAPS: 'URL_HAZRAPS',
    URL_ACARS: 'URL_ACARS',
    URL_ICARGO_EXTERNAL: 'URL_ICARGO_EXTERNAL',

    //db config keys
    DB_HOST: 'DB_HOST',
    DB_PORT: 'DB_PORT',
    DB_NAME: 'DB_NAME',
    DB_USERNAME: 'DB_USERNAME',
    DB_PASSWORD: 'DB_PASSWORD',

    //endpoints
    API_ENDPOINT_NOTOC_PARSE: 'API_ENDPOINT_NOTOC_PARSE',
    API_ENDPOINT_NOTOC_TRIGGER: 'API_ENDPOINT_NOTOC_TRIGGER',
    API_ENDPOINT_NOTOC_HEADER_CONTENT_TYPE: 'API_ENDPOINT_NOTOC_HEADER_CONTENT_TYPE',
    API_ENDPOINT_NOTOC_RAMPLINK_NOTIFICATION: 'API_ENDPOINT_NOTOC_RAMPLINK_NOTIFICATION',
    API_ENDPOINT_OPSHUB_FLIGHT_STATUS: 'API_ENDPOINT_OPSHUB_FLIGHT_STATUS',
    API_ENDPOINT_OPSHUB_FLIGHT_INFO: 'API_ENDPOINT_OPSHUB_FLIGHT_INFO',
    API_ENDPOINT_GET_CREW_BASE: 'API_ENDPOINT_GET_CREW_BASE',
    API_ENDPOINT_FLIGHT_CREW_BASE_MAINTAIN: 'API_ENDPOINT_FLIGHT_CREW_BASE_MAINTAIN',
    API_ENDPOINT_FLIGHT_CREW_BASE_DELETE: 'API_ENDPOINT_FLIGHT_CREW_BASE_DELETE',
    API_ENDPOINT_FLIGHT_CREW_BASE_LIST: 'API_ENDPOINT_FLIGHT_CREW_BASE_LIST',
    API_ENDPOINT_BIN_ASSIGN: 'API_ENDPOINT_BIN_ASSIGN',

    //content types
    CONTENT_TYPE: 'text/plain',
    CONTENT_TYPE_XML: 'application/xml',
    CONTENT_TYPE_JSON: 'application/json',
    CONTENT_TYPE_HTML: 'text/html',
    CONTENT_TYPE_JSON: 'application/json',

    //AutoNOTOC UI urls
    URL_AUTONOTOC_NONPROD: 'URL_AUTONOTOC_NONPROD',
    URL_AUTONOTOC_BIN_LOCATION: 'URL_AUTONOTOC_BIN_LOCATION',
    URL_AUTONOTOC_EMERGENCY_RESPONSE: 'URL_AUTONOTOC_EMERGENCY_RESPONSE',

    //creds
    ICARGO_USERNAME: 'ICARGO_USERNAME',
    ICARGO_PASSWORD: 'ICARGO_PASSWORD',
    AUTONOTOC_LEGACY_STAGE_USERNAME: 'AUTONOTOC_LEGACY_STAGE_USERNAME',
    AUTONOTOC_LEGACY_STAGE_PASSWORD: 'AUTONOTOC_LEGACY_STAGE_PASSWORD'
};

/* ================= HTTP METHODS ================= */

export const HTTP_METHODS = Object.freeze({
    GET: 'get',
    POST: 'post',
    PUT: 'put',
    DELETE: 'delete',
    PATCH: 'patch'
});

//files
export const FILE_PATHS = {
    ENV_CONFIG: 'config/env.config.json',
    LOGS_DIR: 'logs/',
    REPORTS_DIR: 'reports/',
    NTM_TEST_CASES: 'data\\test_data\\awb_validation_data_with_ntm.json',
    NTM_PROCESSING_TEST_DATA: 'data\\test_data\\icargo_ntm_processing\\ntm_processing_test_data.json',
    NTM_PROCESSING_TEST_DATA_TEMPLATE: 'data\\test_data\\icargo_ntm_processing\\TEMPLATE\\ntm_processing_test_data_template.json',
    NTM_PROCESSING_TEST_DATA_OUTPUT: 'data\\test_data\\icargo_ntm_processing\\generated\\ntm_processing_test_data.json',
    NTM_PROCESSING_TEST_DATA_XML_OUTPUT_FOLDER: 'data\\test_data\\icargo_ntm_processing\\generated\\XSDGs\\',
    // HAZRAPS_PROCESSING_TEST_DATA: 'data\\test_data\\hazraps_processing\\TEMPLATE\\hazraps_processing_test_data_template.json',
    HAZRAPS_PROCESSING_TEST_DATA_TEMPLATE: 'data\\test_data\\hazraps_processing\\TEMPLATE\\hazraps_processing_test_data_template.json',
    HAZRAPS_PROCESSING_TEST_DATA_XML_TEMPLATE_FOLDER: 'data\\test_data\\hazraps_processing\\TEMPLATE\\XMLs\\',
    HAZRAPS_PROCESSING_TEST_DATA_GENERATED: 'data\\test_data\\hazraps_processing\\generated\\hazraps_processing_test_data_generated.json',
    HAZRAPS_PROCESSING_TEST_DATA_XML_GENERATED_FOLDER: 'data\\test_data\\hazraps_processing\\generated\\XMLs\\',
    HAZRAPS_ICARGO_INTEGRATION_TEST_DATA_TEMPLATE: 'data\\test_data\\hazraps_icargo_integration\\TEMPLATE\\hazraps_icargo_integration_test_data_template.json',
    HAZRAPS_ICARGO_INTEGRATION_TEST_DATA_XML_TEMPLATE_FOLDER: 'data\\test_data\\hazraps_icargo_integration\\TEMPLATE\\XMLs\\',
    HAZRAPS_ICARGO_INTEGRATION_TEST_DATA_GENERATED: 'data\\test_data\\hazraps_icargo_integration\\generated\\hazraps_icargo_integration_test_data_generated.json',
    RAMPLINK_ACCEPT_CASES: 'data\\test_data\\ramplink_notification_validation.json',
    DB_QUERIES: 'data\\test_data\\database_queries\\dbqueries.json',
    FLIGHT_INFO_TEST_CASES: 'data\\test_data\\OpsHub\\flightInfo_TestData.json',
    FLIGHT_STATUS_TEST_CASES: 'data\\test_data\\OpsHub\\flightStatus_TestData.json',
    GET_CREW_BASE_TEST_CASES: 'data\\test_data\\OpsHub\\Get_Crew_Base_TestData.json',
    FLIGHT_CREW_BASE_POST_TEST_CASES: 'data\\test_data\\OpsHub\\GetFlight_CrewBase_Maintain_TestData.json',
    FLIGHT_CREW_BASE_DELETE_TEST_CASES: 'data\\test_data\\OpsHub\\GetFlight_CrewBase_DELETE_TestData.json',
    FTM_UPLINK_TEST_CASES: 'data\\test_data\\OpsHub\\ftm_uplink_TestData.json',
    BIN_COMPREHENSIVE_TEST_DATA: 'data\\test_data\\autonotoc\\bin_comprehensive_test_data.json',
    BIN_TEST_CASES_CSV: 'data\\test_data\\autonotoc\\BinLocationAssignment_TestCases.csv'
};

export const DEFAULTS = {
    DEFAULT_TIMEZONE: 'DEFAULT_TIMEZONE',
};