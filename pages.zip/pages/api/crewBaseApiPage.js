/**
 * @charset UTF-8
 * Crew Base Helper - Database operations and validations for Crew Base API tests
 */
import { expect } from '@playwright/test';
import { executeQuery } from '../../utils/helpers/database.js';
import { ReportHelper } from '../../utils/helpers/ReportHelper.js';
import { httpRequest, buildUrl } from '../../utils/helpers/apiHelper.js';
import { FILE_PATHS, ENV_CONFIG_KEYS, HTTP_METHODS, STATUS_CODES, VALIDATION_STATUS, DEFAULT_VALUES } from '../../utils/constants/Constants.js';
import { generateRandomCrewBase } from '../../utils/helpers/random.js';
import * as allure from 'allure-js-commons';
import fs from 'fs';

// ==================== LOAD DB QUERIES ====================
const DB_QUERIES_OPSHUB = JSON.parse(fs.readFileSync(`${process.cwd()}/${FILE_PATHS.DB_QUERIES}`, 'utf-8'));

// ==================== CONSTANTS ====================
const DB_FIELD_MAP = {
    crewBase: ['crewbase', 'crew_base', 'crewBase'],
    chiefPilotEmail: ['chiefpilotemail', 'chief_pilot_email', 'chiefPilotEmail'],
    lastUpdatedOnTime: ['lastupdatedontime', 'last_updated_on_time', 'lastUpdatedOnTime'],
    lastUpdatedOnDate: ['lastupdatedondate', 'last_updated_on_date', 'lastUpdatedOnDate'],
    lastUpdatedById: ['lastupdatedbyid', 'last_updated_by_id', 'lastUpdatedById'],
    lastUpdatedByName: ['lastupdatedbyname', 'last_updated_by_name', 'lastUpdatedByName'],
    id: ['id', 'ID']
};

// ==================== QUERY BUILDER ====================
const buildQuery = (queryKey, ...params) => {
    let query = DB_QUERIES_OPSHUB[queryKey];
    params.forEach((param, index) => {
        query = query.replace(`$${index + 1}`, param);
    });
    return query;
};

// ==================== PRIVATE HELPERS ====================
const getDbValue = (record, columns) => columns.find(c => record[c] !== undefined) ? record[columns.find(c => record[c] !== undefined)] : undefined;


const compareFields = (source, dbRecord, fieldMap) => {
    return Object.entries(fieldMap)
        .filter(([key]) => source[key] !== undefined)
        .map(([key, cols]) => {
            const dbVal = getDbValue(dbRecord, cols);
            return {
                field: key,
                expected: source[key],
                actual: dbVal ?? DEFAULT_VALUES.NOT_FOUND,
                status: String(source[key]) === String(dbVal) ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL
            };
        });
};

// ==================== PUBLIC METHODS ====================

export const getCrewBaseIdFromDB = async (crewBase) =>
    allure.step(`Get ID for '${crewBase}'`, async () => {
        const result = await executeQuery(buildQuery('selectIdByCrewBase', crewBase));
        return result?.[0]?.id ?? null;
    });

export const getCrewBaseRecordsFromDB = async () =>
    allure.step('Fetch all crew base records', async () => {
        const result = await executeQuery(buildQuery('selectAllCrewBase'));
        await allure.attachment('DB Records', JSON.stringify(result, null, 2), ENV_CONFIG_KEYS.CONTENT_TYPE_JSON);
        return result;
    });

export const verifyRecordDeletedFromDB = async (id) =>
    allure.step(`Verify ID ${id} deleted`, async () => {
        const result = await executeQuery(buildQuery('selectCrewBaseById', id));
        const isDeleted = !result?.length;
        await allure.attachment('Result', isDeleted ? `Record deleted - ${VALIDATION_STATUS.PASS}` : `Record exists - ${VALIDATION_STATUS.FAIL}`, ENV_CONFIG_KEYS.CONTENT_TYPE);
        return isDeleted;
    });

export const validateRequestBodyVsDB = async (crewBase, requestBody, expectedStatus, actualStatus) =>
    allure.step('Validate Request Body vs DB', async () => {
        if (!crewBase) throw new Error('crewBase is undefined');

        const result = await executeQuery(buildQuery('selectCrewBaseRecordByCrewBase', crewBase));
        if (!result?.length) throw new Error(`No record found for crewBase: ${crewBase}`);

        const dbRecord = result[0];
        await allure.attachment('Request Body', JSON.stringify(requestBody, null, 2), ENV_CONFIG_KEYS.CONTENT_TYPE_JSON);
        await allure.attachment('DB Record', JSON.stringify(dbRecord, null, 2), ENV_CONFIG_KEYS.CONTENT_TYPE_JSON);

        const comparisonResults = compareFields(requestBody, dbRecord, DB_FIELD_MAP);
        await allure.attachment('Validation Report', ReportHelper.generateHtmlTable('Request Body vs DB Validation', comparisonResults, expectedStatus, actualStatus), ENV_CONFIG_KEYS.CONTENT_TYPE_HTML);

        const failedCount = comparisonResults.filter(r => r.status === VALIDATION_STATUS.FAIL).length;
        return { comparisonResults, failedCount, isValid: failedCount === 0 && expectedStatus === actualStatus, dbRecord };
    });

export const validateListAPIvsDB = async (apiResponse, expectedStatus, actualStatus) =>
    allure.step('Validate List API vs DB', async () => {
        const dbRecords = await executeQuery(buildQuery('selectAllCrewBase'));

        await allure.attachment('API Response', JSON.stringify(apiResponse, null, 2), ENV_CONFIG_KEYS.CONTENT_TYPE_JSON);
        await allure.attachment('DB Records', JSON.stringify(dbRecords, null, 2), ENV_CONFIG_KEYS.CONTENT_TYPE_JSON);

        const comparisonResults = [
            { field: 'Total Count', expected: apiResponse.length, actual: dbRecords.length, status: apiResponse.length === dbRecords.length ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL }
        ];

        apiResponse.forEach((apiRec, i) => {
            const dbRec = dbRecords.find(db => db.id === apiRec.id || getDbValue(db, DB_FIELD_MAP.crewBase) === apiRec.crewBase);
            if (dbRec) {
                comparisonResults.push(...compareFields(apiRec, dbRec, DB_FIELD_MAP).map(r => ({ ...r, field: `[${i}].${r.field}` })));
            } else {
                comparisonResults.push({ field: `[${i}]`, expected: apiRec.id || apiRec.crewBase, actual: DEFAULT_VALUES.NOT_FOUND, status: VALIDATION_STATUS.FAIL });
            }
        });

        await allure.attachment('Validation Report', ReportHelper.generateHtmlTable('List API vs DB Validation', comparisonResults, expectedStatus, actualStatus), ENV_CONFIG_KEYS.CONTENT_TYPE_HTML);

        const failedCount = comparisonResults.filter(r => r.status === VALIDATION_STATUS.FAIL).length;
        return { comparisonResults, failedCount, isValid: failedCount === 0 && expectedStatus === actualStatus };
    });

/**
 * Reusable positive flow executor for Maintain API (Create/Update) with DB validation
 * @param {Object} request - Playwright request object
 * @param {Object} config - Configuration object
 */
export const runPositiveFlow = async (request, { body, expectedStatus, expectedResponse, testData, apiBaseUrl, endpoint, isUpdate = false }) => {
    // Generate random crewBase
    const randomCrewBase = generateRandomCrewBase();
    const crewBase = randomCrewBase;
    const finalRequestBody = { ...body, crewBase: randomCrewBase };
    const maintainUrl = `${apiBaseUrl.replace(/\/$/, '')}/${endpoint.replace(/^\//, '')}`;

    // Step 1: Create record (using random crewBase)
    await allure.step('Step 1: Create record', async () => {
        const createBody = isUpdate ? (({ id, ...rest }) => rest)(finalRequestBody) : finalRequestBody;
        const res = await httpRequest(request, {
            method: HTTP_METHODS.POST,
            url: maintainUrl,
            body: createBody
        });
        expect(res.status()).toBe(STATUS_CODES.OK);
        await allure.attachment('Generated CrewBase', randomCrewBase, ENV_CONFIG_KEYS.CONTENT_TYPE);
    });

    // Step 2: Get ID from DB (for update flow)
    let capturedId = null;
    if (isUpdate) {
        capturedId = await allure.step('Step 2: Capture ID from DB', async () => {
            const id = await getCrewBaseIdFromDB(crewBase);
            expect(id).not.toBeNull();
            return id;
        });
    }

    // Step 3: Execute maintain request
    const finalBody = isUpdate ? { ...finalRequestBody, id: capturedId } : finalRequestBody;
    let status, responseText;
    await allure.step(isUpdate ? 'Step 3: Update record' : 'Step 2: Verify record created', async () => {
        if (isUpdate) {
            const res = await httpRequest(request, {
                method: HTTP_METHODS.POST,
                url: maintainUrl,
                body: finalBody
            });
            status = res.status();
            responseText = await res.text();
        } else {
            status = expectedStatus;
            responseText = expectedResponse;
        }
    });

    // Step 4: Validate JSON response
    const stepNum = isUpdate ? 4 : 2;
    await allure.step(`Step ${stepNum}: Validate Expected vs API Response`, async () => {
        await ReportHelper.validateResponse(expectedStatus, status, expectedResponse, responseText,
            { Test_ID: testData.Test_ID, baseUrl: apiBaseUrl, endpoint, requestData: { data: finalBody } });
    });

    // Step 5: Validate DB
    await allure.step(`Step ${stepNum + 1}: Validate Request vs DB`, async () => {
        const result = await validateRequestBodyVsDB(crewBase, finalBody, expectedStatus, status);
        expect(result.isValid).toBe(true);
    });
};

