export const LOGIN_PAGE = {
    USERNAME_INPUT: '#username',
    NEXT_BUTTON: '//button[normalize-space()="Next"]',
    PASSWORD_INPUT: '#password',
    LOGIN_BUTTON: '//button[normalize-space()="Submit"]',
}

export class LoginPage {
    constructor(page) {
        this.page = page;
    }

    async enterUsername(username) {
        await this.page.fill(LOGIN_PAGE.USERNAME_INPUT, username);
    }
}