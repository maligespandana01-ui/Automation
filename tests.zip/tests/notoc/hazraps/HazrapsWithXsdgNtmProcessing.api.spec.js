﻿import { test, expect } from '@playwright/test';
import fs from 'fs';
import path from 'path';
import { executeQuery, executeOracleQuery } from '../../../utils/helpers/database.js';
import { FILE_PATHS, ENV_CONFIG_KEYS, TIMEOUTS, DEFAULTS } from '../../../utils/constants/Constants.js';
import { getEnvVariable } from '../../../utils/config/EnvLoader.js';
import * as allure from 'allure-js-commons';
import { BrowserHelpers } from '../../../utils/helpers/BrowserHelpers.js';
import { LoginPage } from '../../../pages/ui/notoc_legacy/LoginPage.js';
import { NtmXsdgMessagesPostingPage, NTM_XSDG_MESSAGES_POSTING_PAGE } from '../../../pages/ui/notoc_legacy/NtmXsdgMessagesPostingPage.js';
import { generateAwb } from '../../../utils/helpers/awbUtils.js';
import { replaceDatePlaceholders } from '../../../utils/helpers/DateUtils.js';
import { normalizeArrayDict, readJsonFile } from '../../../utils/helpers/JsonUtils.js';
import { diff } from 'deep-diff';
import util from 'node:util';
util.inspect.defaultOptions.maxStringLength = null;

/* ==================== CONFIGURATION FLAGS ==================== */
const executeThroughWebInterfaceApp = true; // Posts XSDG/NTM via AutoNOTOC Legacy Interface App (MQ) so both Rewrite and Legacy receive the messages
const convertNullToBlankInNormalization = true;
const ignoreKeyFieldsDuringValidation = [
    'aioboxcount', 'displayedpackinggroup', 'opboxcount', 'notocdisplaysort',
    'ID', 'CREATED_AT', 'UPDATED_AT', 'MESSAGE_ID', 'CORRELATION_ID',
    'MESSAGEID', 'packinggroup', 'messageid', 'insert_timestamp',
    'update_timestamp', 'unitsequence', 'legsequence', 'updateddate'
];

/* ==================== LOAD TEST DATA AND DB QUERIES ==================== */
const testDataFilePath = path.join(process.cwd(), FILE_PATHS.HAZRAPS_ICARGO_INTEGRATION_TEST_DATA_TEMPLATE);
const testDataList = readJsonFile(testDataFilePath);
const dbQueriesFilePath = path.join(process.cwd(), FILE_PATHS.DB_QUERIES);
const dbQueries = readJsonFile(dbQueriesFilePath);
const timezone = getEnvVariable(DEFAULTS.DEFAULT_TIMEZONE) || 'Asia/Kolkata';

/* ==================== API ENDPOINTS ==================== */
const apiBaseUrl = getEnvVariable(ENV_CONFIG_KEYS.URL_AUTONOTOC_HAZRAPS_STAGE);
const apiProcessContentType = getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_NOTOC_HEADER_CONTENT_TYPE);
const apiRewriteEndpoint = getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_HAZRAPS_REWRITE);
const apiLegacyHazrapsUrl = getEnvVariable(ENV_CONFIG_KEYS.URL_AUTONOTOC_HAZRAPS_STAGE_LEGACY);
const apiLegacyEndpoint = getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_HAZRAPS_LEGACY);
const apiBinAssignEndpoint = getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_BIN_ASSIGN);
const apiICargoBaseUrl = getEnvVariable(ENV_CONFIG_KEYS.URL_ICARGO);
const apiNotocTriggerEndpoint = getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_NOTOC_TRIGGER);

/* ==================== NO MODULE-LEVEL SHARED STATE ==================== */
/* All state is managed via a ctx object inside each test case */

/**
 * Extracts a value between XML tags from the given XML string.
 */
function extractXmlTag(xml, tag) {
    const match = xml.match(new RegExp(`<${tag}>(.*?)</${tag}>`));
    return match ? match[1].trim() : '';
}

/**
 * Prepares a DB query for a given table, replacing AWB, flight, date, and ntm_messageid placeholders.
 */
function prepareTableQuery(tableName, ctx) {
    let tableQuery = dbQueries[tableName];
    if (!tableQuery) return null;

    tableQuery = tableQuery.replace('${awbs}', `('${ctx.generatedAwb}')`);
    tableQuery = tableQuery.replace('${flights}', `('${ctx.flightNumber}')`);
    tableQuery = replaceDatePlaceholders(tableQuery, timezone);

    if (tableQuery.includes('${ntm_messageid}')) {
        if (ctx.ntmAuditData && ctx.ntmAuditData.length > 0) {
            const msgId = ctx.ntmAuditData[0].messageid || ctx.ntmAuditData[0].MESSAGEID || '';
            tableQuery = tableQuery.replace('${ntm_messageid}', `'${msgId}'`);
        } else {
            return null;
        }
    }

    return tableQuery;
}

/**
 * Queries both Postgres (Rewrite) and Oracle (Legacy) for a table list.
 * Shows Rewrite DB data, Legacy DB data, and differences per table in Allure.
 */
async function captureAndCompareBothDbs(ctx, phaseLabel, tableList = [], previousSnapshot = null) {
    const postgresSnapshot = {};
    const oracleSnapshot = {};

    await allure.step(`DB Comparison â€” ${phaseLabel}`, async () => {
        for (const currentTable of tableList) {
            const tableQuery = prepareTableQuery(currentTable, ctx);
            if (!tableQuery) {
                console.warn(`Skipping ${currentTable} â€” query not found or unresolved placeholders`);
                postgresSnapshot[currentTable] = [];
                oracleSnapshot[currentTable] = [];
                continue;
            }

            let postgresResult = [], oracleResult = [];
            try {
                postgresResult = await executeQuery(tableQuery, 3, TIMEOUTS.V_SHORT);
            } catch (error) {
                console.error(`Postgres query error for ${currentTable}: ${error.message}`);
            }
            try {
                oracleResult = await executeOracleQuery(tableQuery, {}, {}, 3, TIMEOUTS.V_SHORT);
            } catch (error) {
                console.error(`Oracle query error for ${currentTable}: ${error.message}`);
            }

            postgresSnapshot[currentTable] = postgresResult;
            oracleSnapshot[currentTable] = oracleResult;

            const postgresNormalized = await normalizeArrayDict(postgresResult, ignoreKeyFieldsDuringValidation, convertNullToBlankInNormalization);
            const oracleNormalized = await normalizeArrayDict(oracleResult, ignoreKeyFieldsDuringValidation, convertNullToBlankInNormalization);
            const differences = diff(postgresNormalized, oracleNormalized);
            const hasDiff = differences !== undefined;

            const stepLabel = hasDiff ? `DIFFERENCE FOUND â€” ${currentTable}` : `MATCH â€” ${currentTable}`;
            await allure.step(stepLabel, async () => {
                await allure.attachment(`SQL Query â€” ${currentTable}`, tableQuery, 'text/plain');
                await allure.attachment(`Rewrite (Postgres) â€” ${currentTable}`, JSON.stringify(postgresNormalized, null, 2), 'application/json');
                await allure.attachment(`Legacy (Oracle) â€” ${currentTable}`, JSON.stringify(oracleNormalized, null, 2), 'application/json');

                if (hasDiff) {
                    await allure.attachment(`Differences â€” ${currentTable}`, JSON.stringify(differences, null, 2), 'application/json');
                    console.log(`[${phaseLabel}] ${currentTable}: DIFFERENCE FOUND (${differences.length} diff(s))`);
                } else {
                    await allure.attachment(`Differences â€” ${currentTable}`, 'No differences â€” Rewrite and Legacy data match', 'text/plain');
                    console.log(`[${phaseLabel}] ${currentTable}: MATCH â€” data is identical`);
                }

                expect.soft(postgresNormalized, `Rewrite vs Legacy mismatch in ${currentTable} [${phaseLabel}]`).toEqual(oracleNormalized);
            });
        }
    });

    // Phase-over-phase comparison if previous snapshot available
    if (previousSnapshot) {
        await allure.step(`Phase Comparison â€” Previous vs ${phaseLabel} (Rewrite DB)`, async () => {
            for (const currentTable of tableList) {
                const prevData = previousSnapshot.postgres[currentTable] || [];
                const currData = postgresSnapshot[currentTable] || [];
                const prevNorm = await normalizeArrayDict(prevData, ignoreKeyFieldsDuringValidation, convertNullToBlankInNormalization);
                const currNorm = await normalizeArrayDict(currData, ignoreKeyFieldsDuringValidation, convertNullToBlankInNormalization);
                const differences = diff(prevNorm, currNorm);
                const hasDiff = differences !== undefined;

                const stepLabel = hasDiff ? `CHANGED â€” ${currentTable} (${differences.length} change(s))` : `UNCHANGED â€” ${currentTable}`;
                await allure.step(stepLabel, async () => {
                    await allure.attachment(`Previous Phase â€” ${currentTable}`, JSON.stringify(prevNorm, null, 2), 'application/json');
                    await allure.attachment(`Current Phase (${phaseLabel}) â€” ${currentTable}`, JSON.stringify(currNorm, null, 2), 'application/json');
                    if (hasDiff) {
                        await allure.attachment(`Changes â€” ${currentTable}`, JSON.stringify(differences, null, 2), 'application/json');
                    } else {
                        await allure.attachment(`Changes â€” ${currentTable}`, 'No changes between phases', 'text/plain');
                    }
                });
            }
        });
    }

    return { postgres: postgresSnapshot, oracle: oracleSnapshot };
}

/* ====================================================================
   TEST SUITE — Action-driven: each test case defines its own ACTIONS[]
   Supported actions: HAZRAPS, XSDG, NTM, BIN_ADD, DB_COMPARE
   ==================================================================== */
test.describe('Hazraps with iCargo Integration - End to End Validation', () => {
    for (const currentTestData of testDataList) {
        const testCaseId = currentTestData.TEST_CASE_ID;
        const scenarioTitle = currentTestData.SCENARIO_TITLE;
        const actions = currentTestData.ACTIONS || [];

        test(`[${testCaseId}] ${scenarioTitle}`, async ({ request }) => {
            await allure.description(`[${testCaseId}] ${scenarioTitle}\nActions: ${actions.map(a => a.ACTION).join(' → ')}`);
            await allure.severity('critical');
            await allure.displayName(`${testCaseId} — ${scenarioTitle}`);

            // Shared context for this test case
            const ctx = {
                generatedAwb: '', hazrapsXmlContent: '',
                awbPrefix: '', flightNumber: '', flightDate: '',
                legOrigin: '', legDestination: '',
                unidNumber: '', properShippingName: '', hazardClass: '',
                subRisk: '', packingGroup: '', quantity: '', weight: '',
                uom: '', packingInstruction: '',
                shipperName: '', shipperAddr1: '', shipperAddr2: '',
                consigneeName: '', consigneeAddr1: '', consigneeAddr2: '',
                xsdgXmlMessage: '', ntmTextMessage: '', ntmAuditData: null
            };
            let lastDbSnapshot = null;
            let notocPage = null;

            // Process each action sequentially
            for (let actionIdx = 0; actionIdx < actions.length; actionIdx++) {
                const action = actions[actionIdx];
                const actionType = action.ACTION;
                const stepNum = actionIdx + 1;

                /* ──────────── HAZRAPS ──────────── */
                if (actionType === 'HAZRAPS') {
                    await allure.step(`Action ${stepNum}: HAZRAPS — Post to Rewrite + Legacy`, async () => {
                        await allure.step('Generate AWB and prepare Hazraps XML', async () => {
                            ctx.generatedAwb = generateAwb();
                            console.log(`[${testCaseId}] Generated AWB: ${ctx.generatedAwb}`);
                            await allure.attachment('Generated AWB', ctx.generatedAwb, 'text/plain');

                            const hazrapsXmlPath = path.join(process.cwd(), currentTestData.HAZRAPS_XML);
                            let xmlTemplate = fs.readFileSync(hazrapsXmlPath, 'utf-8');
                            const originalAwb = extractXmlTag(xmlTemplate, 'AWB_NBR');
                            xmlTemplate = xmlTemplate.replaceAll(originalAwb, ctx.generatedAwb);
                            xmlTemplate = replaceDatePlaceholders(xmlTemplate, timezone);
                            ctx.hazrapsXmlContent = xmlTemplate;

                            ctx.awbPrefix = extractXmlTag(xmlTemplate, 'AWB_PREFIX');
                            ctx.flightNumber = extractXmlTag(xmlTemplate, 'FLT_NBR');
                            ctx.flightDate = extractXmlTag(xmlTemplate, 'FLT_DATE');
                            ctx.legOrigin = extractXmlTag(xmlTemplate, 'LEG_FROM') || extractXmlTag(xmlTemplate, 'AWB_ORIG');
                            ctx.legDestination = extractXmlTag(xmlTemplate, 'LEG_TO');
                            ctx.unidNumber = extractXmlTag(xmlTemplate, 'UNID_NBR');
                            ctx.properShippingName = extractXmlTag(xmlTemplate, 'PSN');
                            ctx.hazardClass = extractXmlTag(xmlTemplate, 'CLASS');
                            ctx.subRisk = extractXmlTag(xmlTemplate, 'SUB_RISK');
                            ctx.packingGroup = extractXmlTag(xmlTemplate, 'PG_RAM');
                            ctx.quantity = extractXmlTag(xmlTemplate, 'PCS');
                            ctx.weight = extractXmlTag(xmlTemplate, 'PCWGT');
                            ctx.uom = extractXmlTag(xmlTemplate, 'UOM');
                            ctx.packingInstruction = extractXmlTag(xmlTemplate, 'PI');
                            ctx.shipperName = extractXmlTag(xmlTemplate, 'SHPR_NAME');
                            ctx.shipperAddr1 = extractXmlTag(xmlTemplate, 'SHPR_ADDR1');
                            ctx.shipperAddr2 = extractXmlTag(xmlTemplate, 'SHPR_ADDR2');
                            ctx.consigneeName = extractXmlTag(xmlTemplate, 'CGNE_NAME');
                            ctx.consigneeAddr1 = extractXmlTag(xmlTemplate, 'CGNE_ADDR1');
                            ctx.consigneeAddr2 = extractXmlTag(xmlTemplate, 'CGNE_ADDR2');

                            await allure.attachment('Booking Details', JSON.stringify({
                                awb: `${ctx.awbPrefix}-${ctx.generatedAwb}`, flight: `AA${ctx.flightNumber}`,
                                flightDate: ctx.flightDate, route: `${ctx.legOrigin} → ${ctx.legDestination}`,
                                unid: ctx.unidNumber, psn: ctx.properShippingName, class: ctx.hazardClass
                            }, null, 2), 'application/json');
                        });

                        await allure.step('POST Hazraps XML → Rewrite Endpoint', async () => {
                            const url = `${apiBaseUrl}${apiRewriteEndpoint}`;
                            await allure.attachment('Request URL', url, 'text/plain');
                            await allure.attachment('Hazraps XML Posted', ctx.hazrapsXmlContent, 'application/xml');
                            const resp = await request.post(url, { headers: { 'Content-Type': apiProcessContentType }, data: ctx.hazrapsXmlContent, timeout: TIMEOUTS.LONG * 3 });
                            await allure.attachment('Response', `Status: ${resp.status()}\nBody: ${await resp.text()}`, 'text/plain');
                            console.log(`Rewrite API: Status=${resp.status()}`);
                        });

                        await allure.step('POST Hazraps XML → Legacy Endpoint', async () => {
                            const url = `${apiLegacyHazrapsUrl}${apiLegacyEndpoint}`;
                            await allure.attachment('Request URL', url, 'text/plain');
                            await allure.attachment('Hazraps XML Posted', ctx.hazrapsXmlContent, 'application/xml');
                            const resp = await request.post(url, { headers: { 'Content-Type': apiProcessContentType }, data: ctx.hazrapsXmlContent, timeout: TIMEOUTS.LONG * 3 });
                            await allure.attachment('Response', `Status: ${resp.status()}\nBody: ${await resp.text()}`, 'text/plain');
                            console.log(`Legacy API: Status=${resp.status()}`);
                        });

                        await new Promise(resolve => setTimeout(resolve, TIMEOUTS.MEDIUM));
                    });
                }

                /* ──────────── BIN_ADD ──────────── */
                else if (actionType === 'BIN_ADD') {
                    const binAddData = currentTestData.BIN_ADD;
                    if (!binAddData || !Array.isArray(binAddData) || binAddData.length === 0) {
                        console.warn(`[${testCaseId}] BIN_ADD action skipped — no BIN_ADD data in test case`);
                        continue;
                    }
                    await allure.step(`Action ${stepNum}: BIN_ADD — Post ${binAddData.length} bin assignment(s)`, async () => {
                        const binUrl = `${apiBaseUrl}${apiBinAssignEndpoint}`;
                        await allure.attachment('BIN Assign URL', binUrl, 'text/plain');

                        const placeholders = {
                            '${awb}': ctx.generatedAwb, '${flightNumber}': ctx.flightNumber,
                            '${flightDate}': ctx.flightDate, '${origin}': ctx.legOrigin,
                            '${destination}': ctx.legDestination, '${legDestination}': ctx.legDestination,
                            '${awbDestination}': ctx.legDestination, '${unid}': ctx.unidNumber,
                            '${class}': ctx.hazardClass, '${classOrDiv}': ctx.hazardClass,
                            '${pkgGroupRamcat}': ctx.packingGroup, '${quantity}': ctx.quantity,
                            '${weight}': ctx.weight, '${piecesInUnit}': ctx.quantity
                        };

                        for (let i = 0; i < binAddData.length; i++) {
                            const entry = JSON.parse(JSON.stringify(binAddData[i]));
                            for (const key of Object.keys(entry)) {
                                if (typeof entry[key] === 'string') {
                                    for (const [ph, val] of Object.entries(placeholders)) {
                                        entry[key] = entry[key].replaceAll(ph, val);
                                    }
                                    entry[key] = replaceDatePlaceholders(entry[key], timezone);
                                }
                            }
                            await allure.attachment(`BIN_ADD Payload ${i + 1}`, JSON.stringify(entry, null, 2), 'application/json');
                            const resp = await request.post(binUrl, {
                                headers: { 'Content-Type': 'application/json' },
                                data: JSON.stringify(entry),
                                timeout: TIMEOUTS.LONG * 3
                            });
                            await allure.attachment(`BIN_ADD Response ${i + 1}`, `Status: ${resp.status()}\nBody: ${await resp.text()}`, 'text/plain');
                            console.log(`[${testCaseId}] BIN_ADD ${i + 1}: Status=${resp.status()}`);
                        }
                        await new Promise(resolve => setTimeout(resolve, TIMEOUTS.MEDIUM));
                    });
                }

                /* ──────────── XSDG ──────────── */
                else if (actionType === 'XSDG') {
                    await allure.step(`Action ${stepNum}: XSDG — Load, Replace Placeholders and Post`, async () => {
                        const xsdgSource = currentTestData.XSDG;
                        if (!xsdgSource) {
                            console.warn(`[${testCaseId}] XSDG action skipped — no XSDG path in test case`);
                            return;
                        }
                        const xsdgFilePath = path.join(process.cwd(), xsdgSource);
                        let xsdgXml = fs.readFileSync(xsdgFilePath, 'utf-8');
                        xsdgXml = xsdgXml.replaceAll('${awb}', ctx.generatedAwb);
                        xsdgXml = replaceDatePlaceholders(xsdgXml, timezone);
                        ctx.xsdgXmlMessage = xsdgXml;
                        await allure.attachment('XSDG XML', ctx.xsdgXmlMessage, 'application/xml');

                        if (executeThroughWebInterfaceApp) {
                            if (!notocPage) {
                                notocPage = await BrowserHelpers.launchBrowser();
                                const loginPage = new LoginPage(notocPage);
                                await loginPage.loginToNotocInterfaceApp(
                                    getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_USERNAME),
                                    getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_PASSWORD)
                                );
                                const ntmXsdgPage = new NtmXsdgMessagesPostingPage(notocPage);
                                await ntmXsdgPage.refreshPageUntilProperlyLoaded();
                            }
                            await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_XSDG_MESSAGE_HYPERLINK).click();
                            await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.XSDG_MESSAGE_TEXTAREA).fill(ctx.xsdgXmlMessage, { timeout: TIMEOUTS.LONG });
                            await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_TO_MQ_BUTTON).click();
                            await notocPage.waitForTimeout(500);
                            await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_ONE_MORE_MESSAGE_BUTTON).click({ timeout: TIMEOUTS.LONG });
                        } else {
                            const url = `${apiICargoBaseUrl}${apiNotocTriggerEndpoint}`;
                            await allure.attachment('Request URL', url, 'text/plain');
                            const resp = await request.post(url, { headers: { 'Content-Type': apiProcessContentType }, data: ctx.xsdgXmlMessage, timeout: TIMEOUTS.LONG * 3 });
                            await allure.attachment('XSDG Response', `Status: ${resp.status()}\nBody: ${await resp.text()}`, 'text/plain');
                            console.log(`XSDG posted via API: Status=${resp.status()}`);
                        }
                        await new Promise(resolve => setTimeout(resolve, TIMEOUTS.SHORT || 5000));
                    });
                }

                /* ──────────── NTM ──────────── */
                else if (actionType === 'NTM') {
                    await allure.step(`Action ${stepNum}: NTM — Replace Placeholders and Post`, async () => {
                        const rawNtm = currentTestData.NTM;
                        if (!rawNtm) {
                            console.warn(`[${testCaseId}] NTM action skipped — no NTM string in test case`);
                            return;
                        }
                        let ntmMsg = rawNtm.replaceAll('${awb}', ctx.generatedAwb);
                        ntmMsg = replaceDatePlaceholders(ntmMsg, timezone);
                        ctx.ntmTextMessage = ntmMsg;
                        await allure.attachment('NTM Message', ctx.ntmTextMessage, 'text/plain');

                        if (executeThroughWebInterfaceApp) {
                            if (!notocPage) {
                                notocPage = await BrowserHelpers.launchBrowser();
                                const loginPage = new LoginPage(notocPage);
                                await loginPage.loginToNotocInterfaceApp(
                                    getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_USERNAME),
                                    getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_PASSWORD)
                                );
                                const ntmXsdgPage = new NtmXsdgMessagesPostingPage(notocPage);
                                await ntmXsdgPage.refreshPageUntilProperlyLoaded();
                            }
                            await notocPage.goto(getEnvVariable(ENV_CONFIG_KEYS.URL_AUTONOTOC_LEGACY_INTERFACEAPP_STAGE));
                            await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_NTM_MESSAGE_HYPERLINK).click();
                            await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.NTM_MESSAGE_TEXTAREA).waitFor({ timeout: TIMEOUTS.LONG });
                            await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.NTM_MESSAGE_TEXTAREA).fill(ctx.ntmTextMessage, { timeout: TIMEOUTS.LONG });
                            await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_TO_MQ_BUTTON).click();
                            await notocPage.waitForTimeout(500);
                            await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_ONE_MORE_MESSAGE_BUTTON).waitFor({ state: 'visible', timeout: TIMEOUTS.LONG });
                            await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_ONE_MORE_MESSAGE_BUTTON).click();
                        } else {
                            const url = `${apiICargoBaseUrl}${apiNotocTriggerEndpoint}`;
                            await allure.attachment('Request URL', url, 'text/plain');
                            const resp = await request.post(url, { headers: { 'Content-Type': apiProcessContentType }, data: ctx.ntmTextMessage, timeout: TIMEOUTS.LONG * 3 });
                            await allure.attachment('NTM Response', `Status: ${resp.status()}\nBody: ${await resp.text()}`, 'text/plain');
                            console.log(`NTM posted via API: Status=${resp.status()}`);
                        }
                        await new Promise(resolve => setTimeout(resolve, TIMEOUTS.SHORT || 5000));
                    });
                }

                /* ──────────── DB_COMPARE ──────────── */
                else if (actionType === 'DB_COMPARE') {
                    const label = action.LABEL || `DB Compare (Action ${stepNum})`;
                    const tableList = action.TABLES || [];

                    await allure.step(`Action ${stepNum}: DB_COMPARE — ${label}`, async () => {
                        await new Promise(resolve => setTimeout(resolve, TIMEOUTS.MEDIUM));
                        const snapshot = await captureAndCompareBothDbs(ctx, label, tableList, lastDbSnapshot);
                        lastDbSnapshot = snapshot;
                    });
                }

                else {
                    console.warn(`[${testCaseId}] Unknown action type: ${actionType}`);
                }
            } // end actions loop

            // Close browser if opened
            if (notocPage) {
                try { const browser = notocPage.context().browser(); await browser.close(); } catch (e) { /* ignore */ }
            }

            // Final summary
            await allure.step('Test Summary', async () => {
                await allure.attachment('AWB', `${ctx.awbPrefix}-${ctx.generatedAwb}`, 'text/plain');
                if (ctx.hazrapsXmlContent) await allure.attachment('Hazraps XML', ctx.hazrapsXmlContent, 'application/xml');
                if (ctx.xsdgXmlMessage) await allure.attachment('XSDG XML', ctx.xsdgXmlMessage, 'application/xml');
                if (ctx.ntmTextMessage) await allure.attachment('NTM Message', ctx.ntmTextMessage, 'text/plain');
                await allure.attachment('Actions Executed', actions.map((a, i) => `${i + 1}. ${a.ACTION}${a.LABEL ? ` (${a.LABEL})` : ''}`).join('\n'), 'text/plain');
            });
        });
    }
});

// ── HOW TO RUN ──
// 1. Clean old results:  Remove-Item -Recurse -Force allure-results\*
// 2. Run the test:       npx playwright test tests/notoc/hazraps/HazrapsWithXsdgNtmProcessing.api.spec.js
// 3. Generate report:    npx allure generate --clean --single-file allure-results -o allure-report
// 4. Open report:        npx allure open allure-report