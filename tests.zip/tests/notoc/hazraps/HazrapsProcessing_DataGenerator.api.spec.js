import { expect, test } from '@playwright/test';
import { FILE_PATHS } from '../../../utils/constants/Constants.js';
import { readJsonFile } from '../../../utils/helpers/JsonUtils.js';
import * as allure from 'allure-js-commons';
import path from 'path';
import { getEnvVariable } from '../../../utils/config/EnvLoader.js';
import { ENV_CONFIG_KEYS, DEFAULTS } from '../../../utils/constants/Constants.js';
import { executeOracleQuery } from '../../../utils/helpers/database.js';
import { TIMEOUTS } from '../../../utils/constants/Constants.js';
import { generateAwb } from '../../../utils/helpers/awbUtils.js';
import { getDateWithOffset, isMatchingDateFormat, parse_MMddYYYY, replaceDatePlaceholders } from '../../../utils/helpers/DateUtils.js';
import fs from 'fs';

import util from "node:util";
util.inspect.defaultOptions.maxStringLength = null;


// Load Test Data
const templateFilePath = path.join(process.cwd(), FILE_PATHS.HAZRAPS_PROCESSING_TEST_DATA_TEMPLATE);
const templateData = readJsonFile(templateFilePath);
const timezone = getEnvVariable(DEFAULTS.DEFAULT_TIMEZONE) || 'Asia/Kolkata'; // Default to IST timezone if not set in env variables
const dbQueriesFilePath = path.join(process.cwd(), FILE_PATHS.DB_QUERIES);
const dbQueries = readJsonFile(dbQueriesFilePath);
const xmls_generated_folder_path = path.join(process.cwd(), FILE_PATHS.HAZRAPS_PROCESSING_TEST_DATA_XML_GENERATED_FOLDER);
//API URL and Endpoints
const apiLegacyHazrapsUrl = getEnvVariable(ENV_CONFIG_KEYS.URL_AUTONOTOC_HAZRAPS_STAGE_LEGACY);
const apiProcessContentType = getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_NOTOC_HEADER_CONTENT_TYPE);
//Endpoints
const apiLegacyEndpoint = getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_HAZRAPS_LEGACY);

//final test data array map - make this global
let finalTestData = [];
//iCargo interface retry count for flaky issues
//parallel execution count for processing template test data
const testDataParallelLimit = Number(process.env.HAZRAPS_TEST_DATA_PARALLEL_LIMIT || 5);

test.describe.serial('Hazraps Processing Test Data Generation', async () => {
    test('Generate Hazraps processing test data from template', async ({ request }) => {
        //Loop through each test case in the test data template
        const generatedTestDataEntries = [];

        for (let startIndex = 0; startIndex < templateData.length; startIndex += testDataParallelLimit) {
            const currentBatch = templateData.slice(startIndex, startIndex + testDataParallelLimit);
            const currentBatchEntries = await Promise.all(currentBatch.map(async (currentTestData, batchIndex) => {
                const index = startIndex + batchIndex;
                let currentTestDataEntry = {};
                const testCaseIdCounter = index + 1;
                const testCaseId = `TC_${String(testCaseIdCounter).padStart(4, '0')}`;

                try {
                    //allure log - generating test data for current test case
                    await allure.step(`GENERATING TEST DATA FROM TEMPLATE FOR TC: ${testCaseIdCounter}`, async () => {
                        console.log(`GENERATING TEST TEMPLATE FOR TC: ${testCaseIdCounter}`);

                        //Fetch all keys in current test data
                        const testDataKeys = Object.keys(currentTestData);

                        //add all keys and data to finalTestData except "EXECUTION_SEQUENCE", "TEST_CASE_ID", and "S_NO"
                        for (const currentKey of testDataKeys) {
                            if (currentKey !== 'EXECUTION_SEQUENCE' && currentKey !== 'TEST_CASE_ID' && currentKey !== 'S_NO') {
                                currentTestDataEntry[currentKey] = currentTestData[currentKey];
                            }
                        }

                        //insert test case id and s.no. in currentTestDataEntry
                        currentTestDataEntry.TEST_CASE_ID = testCaseId;
                        currentTestDataEntry.S_NO = testCaseIdCounter;
                        currentTestDataEntry.EXECUTION_SEQUENCE = {};

                        //verify execution sequence is present in order "1", "2", "3", etc. in current test data, if not throw error
                        const executionSequenceKeys = Object.keys(currentTestData.EXECUTION_SEQUENCE);
                        for (let i = 0; i < executionSequenceKeys.length; i++) {
                            if (executionSequenceKeys[i] !== String(i + 1)) {
                                throw new Error(`Execution sequence is not in order for TC: ${testCaseId}. Please check and re-run again`);
                            }
                            //add execution sequence to currentTestDataEntry
                            currentTestDataEntry.EXECUTION_SEQUENCE[executionSequenceKeys[i]] = currentTestData.EXECUTION_SEQUENCE[executionSequenceKeys[i]];
                        }

                        //awbs map
                        let generatedAwbsMap = {};
                        let awbsInCurrentTestScenario = {};
                        for (const currentExecutionSequence of Object.keys(currentTestData.EXECUTION_SEQUENCE)) {
                            //XMLs
                            let xmls_dynamic = [];
                            let xmls_actual = [];
                            let xmls_generated = [];
                            let xmls_dynamic_paths = [];
                            //AWBs Map
                            // let awbsInCurrentSequence = {};

                            if (currentTestData.EXECUTION_SEQUENCE[currentExecutionSequence].hasOwnProperty('XMLs')) {
                                //fail if XMLs are not in array format
                                if (!Array.isArray(currentTestData.EXECUTION_SEQUENCE[currentExecutionSequence].XMLs)) {
                                    throw new Error(`XMLs should be in array format for TC: ${testCaseId}. Please check and re-run again`);
                                }
                                //loop through XMLs arrays
                                for (let i = 0; i < currentTestData.EXECUTION_SEQUENCE[currentExecutionSequence].XMLs.length; i++) {
                                    //extract awb number or text from XML which is between '001-' and '_'
                                    const xml_or_path = currentTestData.EXECUTION_SEQUENCE[currentExecutionSequence].XMLs[i];

                                    //if xml is xml file path, then read the file and get the content of the file as xml
                                    let xmlContent = xml_or_path;
                                    if (xml_or_path.endsWith('.xml')) {
                                        //handle exception if file is not found or any error in reading file
                                        try {
                                            xmlContent = fs.readFileSync(xml_or_path, 'utf-8');
                                        } catch (error) {
                                            throw new Error(`Error in reading XML file at path: ${xml_or_path} for TC: ${testCaseId}. Error details: ${error instanceof Error ? (error.stack || error.message) : String(error)}`);
                                        }
                                    }

                                    //store actual xml content in xmls_actual array
                                    xmls_actual.push(xmlContent);

                                    //replace xml awb with regex ${1}, ${2}, etc.
                                    const awbMatch = xmlContent.match(/<AWB_NBR>(.*?)<\/AWB_NBR>/);
                                    let awb = '';
                                    if (awbMatch && awbMatch[1]) {
                                        //extract awb between - and _
                                        const awbParts = awbMatch[1].split('-');
                                        awb = awbParts.length > 1 ? awbParts[1] : awbParts[0];
                                        //add awb to awbs map with key as xml 
                                        // awbsInCurrentSequence[awb] = '${awb' + (i + 1) + '}';
                                        if (!awbsInCurrentTestScenario.hasOwnProperty(awb)) {
                                            //add to awbsInCurrentTestScenario with incremental placeholder value
                                            awbsInCurrentTestScenario[awb] = '${awb' + (Object.keys(awbsInCurrentTestScenario).length + 1) + '}';
                                        }
                                    }
                                    else {
                                        throw new Error(`AWB number not found in XML ${(i + 1)} for TC: ${testCaseId}. Please check the XML content and re-run again`);
                                    }
                                    //replace all awb with awbsMap value in xml
                                    xmls_dynamic[i] = xmlContent.replaceAll(awb, awbsInCurrentTestScenario[awb]);

                                    //if awb is already mapped to ${awb1}, ${awb2}, etc. in awbsInCurrentTestScenario, then use the same placeholder value, 
                                    // else generate new awb and map to new placeholder value in awbsInCurrentTestScenario
                                    if (generatedAwbsMap.hasOwnProperty(awb)) {
                                        xmls_generated[i] = xmlContent.replaceAll(awb, generatedAwbsMap[awb]);
                                    }
                                    else {
                                        //generate random awb number and replace in xml, store to xml_generated
                                        let generatedAwb = generateAwb();
                                        //execute sql query to check if generated awb is already present in database
                                        //check if all counts are 0, if not generate new awb
                                        let awbExists = true;
                                        let awbCheckAttempt = 0;
                                        while (awbExists) {
                                            const query = dbQueries.AWBS_COUNT.replaceAll('${awb}', generatedAwb);
                                            const result = await executeOracleQuery(query);
                                            awbExists = Object.values(result[0]).some(count => count > 0);
                                            if (awbExists) {
                                                generatedAwb = generateAwb();
                                            }

                                            //fail if generated awb is not unique after 5 attempts to avoid infinite loop
                                            awbCheckAttempt++;
                                            if (awbCheckAttempt >= 5) {
                                                throw new Error(`Generated AWB ${generatedAwb} is not unique after 5 attempts for TC: ${testCaseId}. Please check the AWB generation logic and re-run again`);
                                            }
                                        }
                                        xmls_generated[i] = xmlContent.replaceAll(awb, generatedAwb);
                                        generatedAwbsMap[awb] = generatedAwb;
                                    }

                                    //write generated xml to output folder with same xml file name
                                    let xmlOutputFileName = '';
                                    if (xml_or_path.endsWith('.xml')) {
                                        xmlOutputFileName = path.basename(xml_or_path);
                                    }
                                    else {
                                        //if xml is not from file, then create a file name using test case id, execution sequence, and xml index
                                        xmlOutputFileName = `TC_${String(testCaseIdCounter).padStart(4, '0')}_Seq_${currentExecutionSequence}_XML_${i + 1}.xml`;
                                    }
                                    const outputPath = path.join(xmls_generated_folder_path, `${xmlOutputFileName}`);
                                    try {
                                        //create folder if not exists
                                        if (!fs.existsSync(xmls_generated_folder_path)) {
                                            fs.mkdirSync(xmls_generated_folder_path, { recursive: true });
                                        }
                                        fs.writeFileSync(outputPath, xmls_dynamic[i], 'utf-8');
                                        //get relative path from current working directory and store in xmls_dynamic_paths
                                        const relativePath = path.relative(process.cwd(), outputPath);
                                        xmls_dynamic_paths[i] = relativePath;
                                    }
                                    catch (error) {
                                        throw new Error(`Error in writing generated XML to file at path: ${outputPath} for TC: ${testCaseId}. Error details: ${error instanceof Error ? (error.stack || error.message) : String(error)}`);
                                    }
                                }
                            }
                            currentTestDataEntry.EXECUTION_SEQUENCE[`${currentExecutionSequence}`].XMLs = xmls_dynamic_paths;

                            //log generated XMLs for current execution sequence in allure step
                            await allure.step(`Generated XMLs TC: ${testCaseIdCounter} - Execution Sequence: ${currentExecutionSequence}`, async () => {
                                console.log(`Generated XMLs for TC: ${testCaseId} - Execution Sequence: ${currentExecutionSequence}: \n${xmls_generated.join('\n\n')}`);
                            });

                            //log actual xml, dynamic xml, and generated xml for current execution sequence in allure step for better traceability
                            await allure.step(`Traceability - Actual Hazraps XMLs, Dynamic XMLs, and Generated XMLs for TC: ${testCaseIdCounter} - Execution Sequence: ${currentExecutionSequence}`, async () => {
                                for (let i = 0; i < xmls_actual.length; i++) {
                                    console.log(`Actual XML ${(i + 1)} for TC: ${testCaseId} - Execution Sequence: ${currentExecutionSequence}: \n${xmls_actual[i]}`);
                                    console.log(`Dynamic XML ${(i + 1)} for TC: ${testCaseId} - Execution Sequence: ${currentExecutionSequence}: \n${xmls_dynamic[i]}`);
                                    console.log(`Generated XML ${(i + 1)} for TC: ${testCaseId} - Execution Sequence: ${currentExecutionSequence}: \n${xmls_generated[i]}`);
                                }

                                //add actual xml, dynamic xml, and generated xml to allure attachment
                                await allure.attachment(`Traceability_XMLs_ExecutionSequence_${currentExecutionSequence}.txt`, xmls_actual.map((xml, index) => `Actual XML ${(index + 1)}:\n${xml}\n\nDynamic XML ${(index + 1)}:\n${xmls_dynamic[index]}\n\nGenerated XML ${(index + 1)}:\n${xmls_generated[index]}\n\n`).join('\n'), 'text/plain');
                            });

                            // Log request details for XML hits and log XML index for better traceability
                            await allure.step(`Send POST request to Legacy API for Hazraps XMLs`, async () => {
                                await allure.attachment('Request URL', `${apiLegacyHazrapsUrl}${apiLegacyEndpoint}`, 'text/plain');
                                await allure.attachment('Request Headers', JSON.stringify({ 'Content-Type': apiProcessContentType }, null, 2), 'application/xml');
                                //loop through each xml and hit the API to trigger the process and log to allure
                                for (let i = 0; i < xmls_generated.length; i++) {
                                    let currentXML = xmls_generated[i];
                                    //replace date placeholders in currentXML
                                    currentXML = replaceDatePlaceholders(currentXML, timezone);
                                    let response = await request.post(`${apiLegacyHazrapsUrl}${apiLegacyEndpoint}`, {
                                        headers: {
                                            'Content-Type': 'application/xml'
                                        },
                                        data: currentXML
                                    });
                                    await allure.attachment('Request Body', currentXML, 'application/xml');
                                    const responseStatus = await response.status();
                                    const responseBody = await response.body();
                                    //assert 200 status
                                    expect(responseStatus).toBe(200);
                                    await allure.attachment(`Response for XML ${(i + 1)}`, `Status: ${responseStatus}\nBody: ${responseBody}`, 'text/plain');
                                }
                            });

                            //custom delay for hazraps processing to happen
                            await new Promise(resolve => setTimeout(resolve, TIMEOUTS.MEDIUM));

                            //TABLES
                            let tables_data_dynamic = {};
                            await allure.step(`QUERY AND STORE TABLES DATA TC: ${testCaseIdCounter} - EXECUTION SEQUENCE: ${currentExecutionSequence}`, async () => {
                                let tables = [];
                                if (currentTestData.EXECUTION_SEQUENCE[currentExecutionSequence].hasOwnProperty('TABLES')) {
                                    //fail if tables map is empty or not in array format
                                    if (Object.keys(currentTestData.EXECUTION_SEQUENCE[currentExecutionSequence].TABLES).length === 0) {
                                        throw new Error(`TABLES map is empty for TC: ${testCaseId}. Please check and re-run again`);
                                    }

                                    //loop through table keys
                                    tables = currentTestData.EXECUTION_SEQUENCE[currentExecutionSequence].TABLES;
                                    let messageid = '';
                                    for (const currentTableKey of Object.keys(tables)) {
                                        //fetch table query from dbqueries.json using currentTableKey, if not found throw error
                                        const tableQueryTemplate = dbQueries[currentTableKey];
                                        if (!tableQueryTemplate) {
                                            throw new Error(`Table query not found for key: ${currentTableKey} in dbqueries.json for TC: ${testCaseId}. Please check and re-run again`);
                                        }

                                        //replace ${awbs} with ('${awb1}', '${awb2}', etc.) in tableQueryTemplate using awbsMap values
                                        let tableQuery = tableQueryTemplate;
                                        if (tableQueryTemplate.includes('${awbs}')) {
                                            const awbsList = Object.values(generatedAwbsMap).map(awb => `'${awb}'`).join(', ');
                                            tableQuery = tableQuery.replaceAll('${awbs}', `(${awbsList})`)
                                        }

                                        //extract flight number from xmls_generated
                                        const flightMatch = xmls_generated[0].match(/<FLT_NBR>(.*?)<\/FLT_NBR>/);
                                        let flightNumber = flightMatch ? flightMatch[1].replace(/^0+/, '') : null;
                                        tableQuery = tableQuery.replaceAll('${flights}', `('${flightNumber}')`);

                                        //replace ${flightNumber} and ${flightDate} placeholders for FLIGHT_STATUS / FLIGHT_CACHE queries
                                        if (tableQuery.includes('${flightNumber}') || tableQuery.includes('${flightDate}')) {
                                            const flightDateMatch = xmls_generated[0].match(/<FLT_DATE>(.*?)<\/FLT_DATE>/);
                                            const flightDate = flightDateMatch ? flightDateMatch[1] : '';
                                            tableQuery = tableQuery.replaceAll('${flightNumber}', flightNumber || '').replaceAll('${flightDate}', flightDate);
                                        }

                                        //replace date placeholders in tableQuery
                                        tableQuery = replaceDatePlaceholders(tableQuery, timezone);

                                        //execute table query and store result in tables map
                                        let queryResult = [];
                                        try {
                                            queryResult = await executeOracleQuery(tableQuery);
                                            console.log(`Executed query for table ${currentTableKey} for TC: ${testCaseId} - Execution Sequence: ${currentExecutionSequence}. Query: ${tableQuery}. Result: ${JSON.stringify(queryResult)}`);
                                        } catch (error) {
                                            throw new Error(`Error in executing query for table ${currentTableKey} for TC: ${testCaseId} - Execution Sequence: ${currentExecutionSequence}. Query: ${tableQuery}. Error details: ${error instanceof Error ? (error.stack || error.message) : String(error)}`);
                                        }
                                        //if queryResult contains MESSAGEID column, store the value as messageid
                                        if (messageid.length === 0 && queryResult.length > 0 && (queryResult[0].hasOwnProperty('MESSAGEID') || queryResult[0].hasOwnProperty('messageid'))) {
                                            messageid = queryResult[0].MESSAGEID || queryResult[0].messageid;
                                        }

                                        //loop through queryResult array of map across all keys, replace dates with ${date|format|offset}
                                        for (const row of queryResult) {
                                            for (const key of Object.keys(row)) {
                                                //if value is date, then convert to ISO string and replace with ${date_key}
                                                if (typeof row[key] === 'string') {
                                                    //check if date is MM/dd/YYYY or ddMMM or MMddYYYYHHmmss format
                                                    if (isMatchingDateFormat(row[key], 'MM/dd/YYYY')) {
                                                        //get date difference in days between current date and dateValue
                                                        const currentDate = new Date();
                                                        const dateValue = parse_MMddYYYY(row[key]);
                                                        const timeDiff = dateValue.getTime() - currentDate.getTime();
                                                        const dayDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
                                                        row[key] = `\${date|MM/dd/YYYY|${dayDiff}}`;
                                                    }
                                                    else if (isMatchingDateFormat(row[key], 'ddMMM')) {
                                                        //get days difference between current date and dateValue
                                                        const currentDate = new Date();
                                                        const dateValue = parse_ddMMM(row[key]);
                                                        const timeDiff = dateValue.getTime() - currentDate.getTime();
                                                        const dayDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
                                                        row[key] = `\${date|ddMMM|${dayDiff}}`;
                                                    }
                                                    // YYYYMMddHHmmss timestamps (e.g. FLIGHT_STATUS UNI_* fields) are real
                                                    // historical values from the DB — keep them as-is instead of replacing
                                                    // with the current date/time which causes validation mismatches.
                                                }
                                            }
                                        }

                                        //loop through queryResult and convert all awb numbers to awb placeholders, trim values
                                        queryResult.forEach(row => {
                                            for (const key of Object.keys(row)) {
                                                // Trim string values
                                                if (typeof row[key] === 'string') {
                                                    row[key] = row[key].trim();
                                                }
                                                // Replace AWB numbers with placeholders
                                                for (const awb in generatedAwbsMap) {
                                                    if (row[key] === generatedAwbsMap[awb]) {
                                                        row[key] = awbsInCurrentTestScenario[awb];
                                                    }
                                                }
                                            }
                                        });

                                        tables_data_dynamic[currentTableKey] = queryResult;
                                        currentTestDataEntry.EXECUTION_SEQUENCE[`${currentExecutionSequence}`].TABLES = tables_data_dynamic;
                                    }
                                    console.log(`Current Execution Sequence: ${currentExecutionSequence}. CurrentTestDataEntry for TC: ${testCaseId}`);
                                    console.log(`Current Test data entry: \n${JSON.stringify(currentTestDataEntry, null, 2)}`);
                                }
                                else {
                                    throw new Error(`TABLES key is missing in execution sequence ${currentExecutionSequence} for TC: ${testCaseId}. Please check and re-run again`);
                                }
                            });
                        }
                    });
                    console.log(`DONE! ${testCaseId}`);
                    return currentTestDataEntry;
                } catch (error) {
                    const errorDetails = error instanceof Error ? (error.stack || error.message) : String(error);
                    console.error(`ERROR in ${testCaseId}. Continuing to next test data.`, errorDetails);
                    return null;
                }
            }));

            generatedTestDataEntries.push(...currentBatchEntries);
        }

        finalTestData = generatedTestDataEntries
            .filter(entry => entry !== null)
            .sort((a, b) => a.S_NO - b.S_NO);

        //write finalTestData to output json file
        const outputFilePath = path.join(process.cwd(), FILE_PATHS.HAZRAPS_PROCESSING_TEST_DATA_GENERATED);
        fs.writeFileSync(outputFilePath, JSON.stringify(finalTestData, null, 2));
    });
});
