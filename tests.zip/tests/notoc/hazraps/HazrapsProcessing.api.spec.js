import { test, expect } from '@playwright/test';
import { FILE_PATHS } from '../../../utils/constants/Constants.js';
import { normalizeArrayDict, readJsonFile } from '../../../utils/helpers/JsonUtils.js';
import * as allure from 'allure-js-commons';
import path from 'path';
import { getEnvVariable } from '../../../utils/config/EnvLoader.js';
import { ENV_CONFIG_KEYS, DEFAULTS } from '../../../utils/constants/Constants.js';
import { executeQuery, executeOracleQuery } from '../../../utils/helpers/database.js';
import { TIMEOUTS } from '../../../utils/constants/Constants.js';
import { generateAwb } from '../../../utils/helpers/awbUtils.js';
import { replaceDatePlaceholders } from '../../../utils/helpers/DateUtils.js';
import fs from 'fs';

import util from "node:util";
util.inspect.defaultOptions.maxStringLength = null;

//flags
const convertNullToBlankInNormalization = true; // Set this flag to true if you want to convert null values to blank during validation
const ignoreKeyFieldsDuringValidation = ['messageid','legsequence','notocdisplaysort','updateddate','insert_timestamp','update_timestamp','unitsequence']; // List of key fields to ignore during data validation in tables
const ignoreTablesDuringValidation = ['FLIGHT_CACHE']; // List of tables to ignore during validation, you can add table names in this list if there are any tables for which you want to skip validation
// Load Test Data
const dataFilePath = path.join(process.cwd(), FILE_PATHS.HAZRAPS_PROCESSING_TEST_DATA_GENERATED);
const testData = readJsonFile(dataFilePath);
const timezone = getEnvVariable(DEFAULTS.DEFAULT_TIMEZONE) || 'Asia/Kolkata'; // Default to IST timezone if not set in env variables
const dbQueriesFilePath = path.join(process.cwd(), FILE_PATHS.DB_QUERIES);
const dbQueries = readJsonFile(dbQueriesFilePath);

//API URL and Endpoints
const apiBaseUrl = getEnvVariable(ENV_CONFIG_KEYS.URL_AUTONOTOC_HAZRAPS_STAGE);
const apiProcessContentType = getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_NOTOC_HEADER_CONTENT_TYPE);
//Endpoints
const apiRewriteEndpoint = getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_HAZRAPS_REWRITE);
const apiLegacyHazrapsUrl = getEnvVariable(ENV_CONFIG_KEYS.URL_AUTONOTOC_HAZRAPS_STAGE);
const apiLegacyEndpoint = getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_HAZRAPS_LEGACY);

test.describe('Hazraps Processing Validation Tests', () => {
    //Loop through each test case in the test data
    for (const currentTestData of testData) {
        //Store data for each test case
        const scenarioTitle = currentTestData.SCENARIO_TITLE;
        const testCaseId = currentTestData.TEST_CASE_ID;
        const executionSequence = currentTestData.EXECUTION_SEQUENCE;

        test(`[${testCaseId}] Hazraps Processing Test for: ${scenarioTitle}`, { tag: ['@sanity', '@regression'] }, async ({ request }) => {
            //Variables
            let awbs_sequence_list = {};
            // Allure annotations
            await allure.description(`Testing Hazraps Processing API with scenario: ${scenarioTitle}`);
            await allure.severity('critical');
            await allure.owner('QA Team');
            await allure.displayName(`${testCaseId} - ${scenarioTitle}`);

            // Allure - Add test data as attachment
            await allure.parameter('Base URL', apiBaseUrl);
            await allure.parameter('Hazraps Rewrite POST Endpoint', apiRewriteEndpoint);
            await allure.parameter('Content Type', apiProcessContentType);
            await allure.parameter('Scenario', scenarioTitle);

            //loop through the executionSequences map, execute each sequence one by one and validate results
            for (const currentExecutionSequence of Object.keys(executionSequence)) {
                await allure.step(`EXECUTION SEQUENCE: ${currentExecutionSequence}`, async () => {
                    //store values
                    let hazraps_xmls = executionSequence[currentExecutionSequence].XMLs;
                    let tables = executionSequence[currentExecutionSequence].TABLES;
                    let currentSequenceXMLsList = [];

                    console.log(`Hazraps XMLs for current execution sequence: ${JSON.stringify(hazraps_xmls)}`);

                    // Hit XMLs to Hazraps API
                    // Add as allure step mentioning the number of XMLs being hit in the current execution sequence
                    await allure.step(`Generating AWB's for XMLs - Total XMLs: ${hazraps_xmls.length}`, async () => {
                        for (let currentXML of hazraps_xmls) {
                            let randomAwbNumber;
                            //check if XML is file path or actual content, if it is file path read the content of the file
                            if (currentXML.endsWith('.xml')) {
                                const xmlFilePath = path.join(process.cwd(), currentXML);
                                currentXML = fs.readFileSync(xmlFilePath, 'utf-8');
                            }

                            //firstly check if the XML has placeholder
                            if (currentXML.includes('\${awb')) {
                                //Get the AWB number index
                                const awbIndex = currentXML.match(/\${awb(\d+)}/)[1];

                                //check if the AWB number for the index is already generated in current execution sequence, if yes use it else generate a new one and store in map
                                if (awbs_sequence_list[`\${awb${awbIndex}}`]) {
                                    randomAwbNumber = awbs_sequence_list[`\${awb${awbIndex}}`];
                                } else {
                                    randomAwbNumber = generateAwb();
                                    awbs_sequence_list[`\${awb${awbIndex}}`] = randomAwbNumber;
                                }

                                //replaceAll the placeholder in XML with the generated AWB number
                                currentXML = currentXML.replaceAll(`\${awb${awbIndex}}`, randomAwbNumber);
                                //replace all date placeholders in XML with current date in required format
                                currentXML = replaceDatePlaceholders(currentXML, timezone);
                                currentSequenceXMLsList.push(currentXML);
                            }
                        }

                        //log to allure the list of AWBs and XMLs generated in the current execution sequence
                        await allure.attachment(`AWBs generated in Execution Sequence ${currentExecutionSequence}`, JSON.stringify(awbs_sequence_list, null, 2), 'application/json');
                        await allure.attachment(`XMLs generated in Execution Sequence ${currentExecutionSequence}`, JSON.stringify(currentSequenceXMLsList, null, 2), 'application/json');
                    });

                    // Allure - Add execution sequence data as attachments
                    await allure.attachment(`Execution Sequence - ${currentExecutionSequence} - XMLs`, JSON.stringify(currentSequenceXMLsList, null, 2), 'application/json');

                    //add actual xml, dynamic xml, and generated xml to allure attachment
                    await allure.attachment(`Traceability_XMLs_ExecutionSequence_${currentExecutionSequence}.txt`, currentSequenceXMLsList.map((xml, index) => `XML ${(index + 1)}:\n${xml}\n\n`).join('\n'), 'text/plain');
                    await allure.attachment(`Execution Sequence - ${currentExecutionSequence} - TABLES`, JSON.stringify(tables, null, 2), 'application/json');

                    //Hit XML to Hazraps API and log to allure
                    // Log request details for XML hits and log xml index for better traceability
                    await allure.step(`Send POST request to Rewrite API for Hazraps XMLs`, async () => {
                        await allure.attachment('Request URL', `${apiBaseUrl}${apiRewriteEndpoint}`, 'text/plain');
                        await allure.attachment('Request Headers', JSON.stringify({ 'Content-Type': apiProcessContentType }, null, 2), 'application/json');
                        //loop through each xml and hit the API to trigger the process and log to allure
                        for (let i = 0; i < currentSequenceXMLsList.length; i++) {
                            let currentXML = currentSequenceXMLsList[i];
                            let response = await request.post(`${apiBaseUrl}${apiRewriteEndpoint}`, {
                                headers: { 'Content-Type': apiProcessContentType },
                                data: currentXML,
                                timeout: TIMEOUTS.LONG * 3
                            });
                            await allure.attachment('Request Body', currentXML, 'text/plain');
                            const responseStatus = await response.status();
                            const responseBody = await response.body();
                            await allure.attachment(`Response for XML ${(i + 1)}`, `Status: ${responseStatus}\nBody: ${responseBody}`, 'text/plain');
                        }
                    });
                   
                   

                    //custom delay for Hazraps processing to happen
                    await new Promise(resolve => setTimeout(resolve, TIMEOUTS.MEDIUM));

                    //set all awbs to into db query format for querying in tables
                    let awbs = '(' + Object.values(awbs_sequence_list).map(awb => `'${awb}'`).join(', ') + ')';

                    //Validate data in Tables
                    //loop through each table keys in the current execution sequence and validate data
                    await allure.step(`Validate data in tables for Execution Sequence: ${currentExecutionSequence}`, async () => {
                        
                        for (const currentTable of Object.keys(tables)) {
                            if (ignoreTablesDuringValidation.includes(currentTable)) {
                                console.log(`Skipping validation for table: ${currentTable}`);
                                continue;
                            }
                            await allure.step(`${currentTable}`, async () => {
                                let tableData = tables[currentTable];

                                //fetch tableQuery from dbConfig using currentTable keywhich 
                                let tableQuery = dbQueries[currentTable];
                                if (!tableQuery) {
                                    throw new Error(`DB query details not found for table: ${currentTable} in DB_QUERIES.json. Please check the DB_QUERIES.json file and add the details for ${currentTable}`);
                                }

                                //loop through each awbs generated in the current execution sequence and replaceAll in query
                                for (const currentAwbIndex of Object.keys(awbs_sequence_list)) {
                                    console.log(`Current Table: ${currentTable}, Query before replacing AWB placeholder: ${tableQuery}`);
                                    //replace tableData json with awb numbers (awb1, awb2, awb3...) if there are any placeholders
                                    //loop through tableData array
                                    for (let i = 0; i < tableData.length; i++) {
                                        //loop through each key of the object and replace value if it matches with any awb placeholder
                                        for (const key of Object.keys(tableData[i])) {
                                            if (typeof tableData[i][key] === 'string') {
                                                //loop through awbSequenceList and replace all placeholders in the tableData with actual awb numbers
                                                tableData[i][key] = tableData[i][key].replaceAll(currentAwbIndex, awbs_sequence_list[currentAwbIndex]);
                                            }
                                        }
                                    }
                                }
                                //replace date placeholders in table query and data with current date in required format if there is any placeholder for date, assuming the placeholder is ${date} and the required format is YYYY-MM-DD, you can adjust the regex and date formatting logic as per your actual placeholders and required formats
                                tableQuery = replaceDatePlaceholders(tableQuery, timezone);
                                tableData = replaceDatePlaceholders(tableData, timezone);
                                //replace ${awbs} placeholder in query with actual awb numbers in db query format for IN clause
                                tableQuery = tableQuery.replaceAll('${awbs}', awbs);
                                //extract flight number and date from the XMLs and replace in query for FLIGHT_STATUS / FLIGHT_CACHE
                                if (tableQuery.includes('${flightNumber}') || tableQuery.includes('${flightDate}')) {
                                    const xmlSource = currentSequenceXMLsList[0] || '';
                                    const flightNumberMatch = xmlSource.match(/<FLT_NBR>(.*?)<\/FLT_NBR>/);
                                    const flightDateMatch = xmlSource.match(/<FLT_DATE>(.*?)<\/FLT_DATE>/);
                                    const flightNumber = flightNumberMatch ? flightNumberMatch[1].replace(/^0+/, '') : '';
                                    const flightDate = flightDateMatch ? flightDateMatch[1] : '';
                                    tableQuery = tableQuery.replaceAll('${flightNumber}', flightNumber).replaceAll('${flightDate}', flightDate);
                                }

                                //execute DB query and get actual results - use Oracle executor for FLIGHT_STATUS and FLIGHT_CACHE (Oracle-only tables)
                                const oracleTables = ['FLIGHT_STATUS', 'FLIGHT_CACHE'];
                                let tableQueryResult;
                                try {
                                    if (oracleTables.includes(currentTable)) {
                                        tableQueryResult = await executeOracleQuery(tableQuery, {}, {}, 3, TIMEOUTS.V_SHORT);
                                    } else {
                                        tableQueryResult = await executeQuery(tableQuery, 3, TIMEOUTS.V_SHORT);
                                    }
                                }
                                catch (error) {
                                    console.error(`Error executing query for table ${currentTable}: ${error.message}`);
                                    await allure.step(`Error executing query for table ${currentTable}: ${error.message}`, async () => {
                                        await allure.attachment('Query', tableQuery, 'text/plain');
                                        await allure.attachment('Error Message', error.message, 'text/plain');
                                    });
                                    return; // Use return instead of continue to exit the allure.step callback
                                }
                                console.log(`Query Result of table ${currentTable}:`, tableQueryResult);
                                //validate actual results with expected data - placeholder for actual validation logic
                                const normalizedTableQueryResult = await normalizeArrayDict(tableQueryResult, ignoreKeyFieldsDuringValidation, convertNullToBlankInNormalization);
                                const normalizedExpectedData = await normalizeArrayDict(tableData, ignoreKeyFieldsDuringValidation, convertNullToBlankInNormalization);
                                //Add allure step mentioning the table name being validated
                                await allure.step(`Validating data for table: ${currentTable}`, async () => {
                                    //Soft assertion to compare actual and expected data, so that even if validation fails for one table, it continues with other tables and logs all failures in the end
                                    expect.soft(normalizedTableQueryResult, `Data mismatch found in table: ${currentTable}`).toEqual(normalizedExpectedData);
                                    //attach actual and expected data in allure for better debugging in case of failure
                                    await allure.attachment(`Actual Data - ${currentTable}`, JSON.stringify(normalizedTableQueryResult, null, 2), 'application/json');
                                    await allure.attachment(`Expected Data - ${currentTable}`, JSON.stringify(normalizedExpectedData, null, 2), 'application/json');
                                });
                            });
                        }
                    });
                });
            }
        });
    }
});





//npx playwright test tests/notoc/hazraps/HazrapsProcessing_DataGenerator.api.spec.js
//npx playwright test tests/notoc/hazraps/HazrapsProcessing.api.spec.js
//npx allure generate --clean --single-file allure-results -o allure-report






//npx playwright test tests/notoc/
//npx playwright test tests/notoc/hazraps/HazrapsProcessing.api.spec.js
//npx allure generate --clean --single-file allure-results -o allure-report

//npx playwright test tests\notoc\e2e\EmergencyResponseReport.ntm-xsdg.e2e.spec.js

//npx playwright test tests/notoc/e2e/EmergencyResponseReport.ntm-xsdg.e2e.spec.js