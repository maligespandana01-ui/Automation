import { test, expect } from '@playwright/test';
import fs from 'fs';
import { executeQuery, closeDb } from '../../utils/helpers/database.js';
import { randomNumber, formatTime } from '../../utils/helpers/random.js';
import { generateAwb } from '../../utils/helpers/awbUtils.js';
import { httpRequest } from '../../utils/helpers/apiHelper.js';
import { FILE_PATHS, ENV_CONFIG_KEYS, TIMEOUTS } from '../../utils/constants/Constants.js';
import { getEnvVariable } from '../../utils/config/EnvLoader.js';
import { substitutePlaceholders } from '../../utils/helpers/GenericHelpers.js';

/* ==================== ENV ==================== */
const BASE_URL = getEnvVariable(ENV_CONFIG_KEYS.URL_RAMPLINK);
const ENDPOINT = getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_NOTOC_RAMPLINK_NOTIFICATION);

/* ==================== LOAD TEST DATA ==================== */
const testCases = JSON.parse(fs.readFileSync(`${process.cwd()}/${FILE_PATHS.RAMPLINK_ACCEPT_CASES}`, 'utf-8'));

/* ==================== LOAD QUERIES FILE FOR THIS CURRENT TEST SCENARIOS ==================== */
const QUERIES = JSON.parse(fs.readFileSync(`${process.cwd()}/${FILE_PATHS.DB_QUERIES}`, 'utf-8'));

/* ==================== DB QUERY KEYS ==================== */
const DB = {
  POLL: 'pollByAwbAndType',
  COUNT: 'rowCountByAwb',
  TIMELINE: 'lifecycleTimeline'
};

/* ==================== DB RAW QUERIES FROM FILE ==================== */
const RAW_QUERIES = {
  POLL_BY_AWB_AND_TYPE: QUERIES[DB.POLL],
  ROW_COUNT_BY_AWB: QUERIES[DB.COUNT],
  LIFECYCLE_TIMELINE: QUERIES[DB.TIMELINE]
};

/* ==================== UTIL ==================== */
const sleep = ms => new Promise(r => setTimeout(r, ms));
const attach = (ti, name, body, type = 'text/plain') =>
  ti.attach(name, {
    body: typeof body === 'string' ? body : JSON.stringify(body, null, 2),
    contentType: type
  });

/* ==================== RANDOM ==================== */
const generateMessageId = () => randomNumber(10);
const randomCargoType = () => ['PPS', 'CARGO', 'M-E'][Math.floor(Math.random() * 3)];

/* ==================== XML Replace ==================== */
const mutate = {
  awb: (x, v) => x.replace(/<AWBNum>.*?<\/AWBNum>/, `<AWBNum>${v}</AWBNum>`),
  msg: x => x.replace(/<MessageID>.*?<\/MessageID>/, `<MessageID>${generateMessageId()}</MessageID>`),
  cargo: x => x.replace(/<CargoType>.*?<\/CargoType>/, `<CargoType>${randomCargoType()}</CargoType>`),
  time: x => x.replace(/<SourceTimeStamp>.*?<\/SourceTimeStamp>/,
    `<SourceTimeStamp>${formatTime("MM/dd/yyyy HH:mm:ss")}</SourceTimeStamp>`),
  type: (x, from, to) =>
    x.replace(`<MessageType>${from}</MessageType>`, `<MessageType>${to}</MessageType>`)
};

/* ==================== TESTS ==================== */
test.describe.parallel('RAMPLINK API – ACCEPT → MODIFY → DELETE', () => {
  testCases.forEach(tc => {
    test(`${tc.Scenario} @accept @lifecycle`, async ({ request }, ti) => {
      //initialize variables
      const baseXml = fs.readFileSync(tc.XML, 'utf-8');
      const awb = generateAwb(ti.workerIndex);
      const acceptQuery = substitutePlaceholders(RAW_QUERIES.POLL_BY_AWB_AND_TYPE, awb, '%ACCEPT%');
      const modifyQuery = substitutePlaceholders(RAW_QUERIES.POLL_BY_AWB_AND_TYPE, awb, '%MODIFY%');
      const deleteQuery = substitutePlaceholders(RAW_QUERIES.POLL_BY_AWB_AND_TYPE, awb, '%DELETE%');
      const awbRowsQuery = substitutePlaceholders(RAW_QUERIES.ROW_COUNT_BY_AWB, awb);

      /* ---------- ACCEPT ---------- */
      const acceptXml = mutate.cargo(
        mutate.msg(
          mutate.awb(baseXml, awb)
        )
      );

      const acceptResp = await httpRequest(request, {
        url: `${BASE_URL.replace(/\/$/, '')}/${ENDPOINT.replace(/^\//, '')}`,
        body: acceptXml,
        headers: { 'Content-Type': ENV_CONFIG_KEYS.CONTENT_TYPE_XML }
      });

      await attach(ti, 'ACCEPT Request', acceptXml, 'application/xml');
      await attach(ti, 'ACCEPT Response', await acceptResp.text());

      expect(acceptResp.status(), 'ACCEPT Response Status Code').toBe(200);

      const accDb = await executeQuery(acceptQuery, 3, TIMEOUTS.V_SHORT);
      await attach(ti, 'DB ACCEPT Query', acceptQuery);
      await attach(ti, 'DB ACCEPT Row', accDb, 'application/json');

      expect(accDb.length, 'ACCEPT DB Rows count').toBe(1);

      /* ---------- MODIFY ---------- */
      const modifyXml = mutate.cargo(
        mutate.time(
          mutate.msg(
            mutate.type(acceptXml, 'ACCEPT', 'EDIT')
          )
        )
      );

      const modResp = await httpRequest(request, {
        url: `${BASE_URL.replace(/\/$/, '')}/${ENDPOINT.replace(/^\//, '')}`,
        body: modifyXml,
        headers: { 'Content-Type': ENV_CONFIG_KEYS.CONTENT_TYPE_XML }
      });

      expect(modResp.status(), 'MODIFY Response Status Code').toBe(200);

      const modDb = await executeQuery(modifyQuery, 3, TIMEOUTS.V_SHORT);
      expect(modDb.length, 'MODIFY DB Rows count').toBe(1);

      await attach(ti, 'MODIFY - Request', modifyXml, 'application/xml');
      await attach(ti, 'MODIFY - Response', await modResp.text());
      await attach(ti, 'DB MODIFY Query', modifyQuery);
      await attach(ti, 'DB - MODIFY Row', modDb, 'application/json');



      /* ---------- DELETE ---------- */

      const deleteXml = mutate.time(
        mutate.msg(
          mutate.type(modifyXml, 'EDIT', 'DELETE')
        )
      );

      const delResp = await httpRequest(request, {
        url: `${BASE_URL.replace(/\/$/, '')}/${ENDPOINT.replace(/^\//, '')}`,
        body: deleteXml,
        headers: { 'Content-Type': ENV_CONFIG_KEYS.CONTENT_TYPE_XML }
      });

      expect(delResp.status(), 'DELETE Response Status Code').toBe(200);

      const delDb = await executeQuery(deleteQuery, 3, TIMEOUTS.V_SHORT);
      expect(delDb.length, 'DELETE DB Rows count').toBe(1);
      await attach(ti, 'DELETE - Request', deleteXml, 'application/xml');
      await attach(ti, 'DELETE - Response', await delResp.text());
      await attach(ti, 'DB DELETE Query', deleteQuery);
      await attach(ti, 'DB DELETE Row', delDb, 'application/json');

      /* ---------- FINAL ASSERTIONS ---------- */
      const dbRecordsCountRows = await executeQuery(awbRowsQuery, 3, TIMEOUTS.V_SHORT);
      expect(dbRecordsCountRows.length, `FINAL DB Records Row Count for AWB ${awb}`).toBe(3);
      await attach(ti, `Lifecycle Timeline of AWB ${awb}`, dbRecordsCountRows, 'application/json');
    });
  });
});

/* ==================== CLEANUP ==================== */
test.afterAll(closeDb);