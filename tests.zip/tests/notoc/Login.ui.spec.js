import { test, expect } from '@playwright/test';
import { LoginPage, LOGIN_PAGE } from '../../pages/ui/notoc/LoginPage.js';
import { TIMEOUTS } from '../../utils/constants/Constants.js';
import * as allure from 'allure-js-commons';

test.describe('Login to NOTOC', () => {
    let loginPage;
    test.beforeEach(async ({ page }) => {
        loginPage = new LoginPage(page);
        await page.goto(`${process.env.URL_BASE}`);
    });

    test('should display login page elements', { tag: ['@ui'] }, async ({ page }) => {
        console.log(`HEADLESS MODE: ${process.env.HEADLESS}`);
        console.log(`ENVIRONMENT: ${process.env.ENV}`);
        console.log(`BASE URL: ${process.env.URL_BASE}`);
        await expect(page.locator(LOGIN_PAGE.USERNAME_INPUT)).toBeVisible({ timeout: TIMEOUTS.MEDIUM });
        await loginPage.enterUsername('testuser');
        await page.click(LOGIN_PAGE.NEXT_BUTTON);
        await allure.step('Verify password input is visible and take screenshot', async () => {
            await expect(page.locator(LOGIN_PAGE.PASSWORD_INPUT)).toBeVisible();
            await page.screenshot();
        });
    });
});