import { test, expect } from '@playwright/test';
import { FILE_PATHS } from '../../utils/constants/Constants.js';
import { readJsonFile } from '../../utils/helpers/JsonUtils.js';
import * as allure from 'allure-js-commons';
import path from 'path';
import { getEnvVariable } from '../../utils/config/EnvLoader.js';
import { ENV_CONFIG_KEYS } from '../../utils/constants/Constants.js';

// Load Test Data
const dataFilePath = path.join(process.cwd(), FILE_PATHS.NTM_TEST_CASES);
const testData = readJsonFile(dataFilePath);

//API URL and Endpoints
const apiBaseUrl = getEnvVariable(ENV_CONFIG_KEYS.URL_ICARGO);
const apiParseEndpoint = getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_NOTOC_PARSE);
const apiParseContentType = getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_NOTOC_HEADER_CONTENT_TYPE);

test.describe('NTM Parse API Validation Tests', () => {
    //Loop through each test case in the test data
    for (const currentTestData of testData) {
        //Store data for each test case
        const scenarioName = currentTestData.Scenario;
        const expectedParseResult = currentTestData.ExpectedResult;
        const ntm = currentTestData.NTM;

        test(`NTM Parse Test for: ${currentTestData.Scenario}`, { tag: ['@sanity', '@regression'] }, async ({ request }) => {
            //Variables
            let response;
            // Allure annotations
            await allure.description(`Testing NTM Parse API with scenario: ${scenarioName}`);
            await allure.severity('critical');
            await allure.label('@sanity', '@regression');
            await allure.owner('QA Team');
            await allure.displayName(`${scenarioName}`);

            // Allure - Add test data as attachment
            await allure.attachment('Test Data - NTM', ntm, 'text/plain');
            await allure.parameter('Base URL', apiBaseUrl);
            await allure.parameter('Endpoint', apiParseEndpoint);
            await allure.parameter('Content Type', apiParseContentType);
            await allure.parameter('Scenario', scenarioName);
            await allure.parameter('Expected Result', expectedParseResult);

            // Hit API and get response
            await allure.step('Send POST request to Parse API', async () => {
                response = await request.post(`${apiBaseUrl}${apiParseEndpoint}`, {
                    headers: { 'Content-Type': apiParseContentType },
                    data: ntm
                });

                // Log request details
                await allure.attachment('Request URL', `${apiBaseUrl}${apiParseEndpoint}`, 'text/plain');
                await allure.attachment('Request Headers', JSON.stringify({ 'Content-Type': apiParseContentType }, null, 2), 'application/json');
                await allure.attachment('Request Body', ntm, 'text/plain');
            });

            await allure.step('Verify response and validate results', async () => {
                const responseStatus = response.status();
                const responseBody = await response.text();
                const responseOk = response.ok();

                // Add response details as attachments
                await allure.attachment('Response Status', responseStatus.toString(), 'text/plain');
                // Add response body as attachment - JSON if parseable, otherwise plain text
                try {
                    await allure.attachment('Response Body', JSON.stringify(JSON.parse(responseBody), null, 2), 'application/json');
                } catch {
                    await allure.attachment('Response Body', responseBody, 'text/plain');
                }

                // Verify the response status
                expect(responseOk === true ? "Accepted" : "Rejected").toBe(expectedParseResult);

                // Verify custom parse results with API response
                // CODE TO BE WRITTEN BASED ON ACTUAL API RESPONSE STRUCTURE
            });
        });
    }
});