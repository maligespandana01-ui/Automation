/**
 * @charset UTF-8
 * UTF-8 Character Encoding Declaration
 */
import { test, expect } from '@playwright/test';
import { runAPITest, httpRequest, buildUrl } from '../../../utils/helpers/apiHelper.js';
import { getEnvVariable } from '../../../utils/config/EnvLoader.js';
import { FILE_PATHS, ENV_CONFIG_KEYS, HTTP_METHODS } from '../../../utils/constants/Constants.js';
import fs from 'fs';


const flightInfoTestData = JSON.parse(fs.readFileSync(`${process.cwd()}/${FILE_PATHS.FLIGHT_INFO_TEST_CASES}`, 'utf-8'));
const flightStatusTestData = JSON.parse(fs.readFileSync(`${process.cwd()}/${FILE_PATHS.FLIGHT_STATUS_TEST_CASES}`, 'utf-8'));
const crewBaseTestData = JSON.parse(fs.readFileSync(`${process.cwd()}/${FILE_PATHS.GET_CREW_BASE_TEST_CASES}`, 'utf-8'));

const apiBaseUrl = getEnvVariable(ENV_CONFIG_KEYS.URL_OPSHUB);
const endpoints = {
    flightInfo: getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_OPSHUB_FLIGHT_INFO),
    flightStatus: getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_OPSHUB_FLIGHT_STATUS),
    crewBase: getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_GET_CREW_BASE)
};


test.describe('API Validation Tests', () => {
    test.describe('Flight Info API', () => {
        for (const testData of flightInfoTestData) {
            test(`[${testData.Test_ID}] ${testData.Scenario}`, { tag: ['@sanity', '@regression'] }, async ({ request }) => {
                const body = JSON.parse(testData.RequestBody);
                await runAPITest({
                    apiName: 'Flight Info',
                    testData,
                    endpoint: endpoints.flightInfo,
                    requestFn: () => httpRequest(request, {
                        method: HTTP_METHODS.POST,
                        url: buildUrl(apiBaseUrl, endpoints.flightInfo),
                        body
                    }),
                    isQueryParams: false
                });
            });
        }
    });

    test.describe('Flight Status API', () => {
        for (const testData of flightStatusTestData) {
            test(`[${testData.Test_ID}] ${testData.Scenario}`, { tag: ['@sanity', '@regression'] }, async ({ request }) => {
                const body = JSON.parse(testData.RequestBody);
                await runAPITest({
                    apiName: 'Flight Status',
                    testData,
                    endpoint: endpoints.flightStatus,
                    requestFn: () => httpRequest(request, {
                        method: HTTP_METHODS.POST,
                        url: buildUrl(apiBaseUrl, endpoints.flightStatus),
                        body
                    }),
                    isQueryParams: false
                });
            });
        }
    });

    test.describe('Crew Base API', () => {
        for (const testData of crewBaseTestData) {
            test(`[${testData.Test_ID}] ${testData.Scenario}`, { tag: ['@sanity', '@regression'] }, async ({ request }) => {
                const params = JSON.parse(testData.Query_Params);
                const url = `${buildUrl(apiBaseUrl, endpoints.crewBase)}?${new URLSearchParams(params).toString()}`;
                await runAPITest({
                    apiName: 'Crew Base',
                    testData,
                    endpoint: endpoints.crewBase,
                    requestFn: () => httpRequest(request, {
                        method: HTTP_METHODS.GET,
                        url
                    }),
                    isQueryParams: true
                });
            });
        }
    });
});
