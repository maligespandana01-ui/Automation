/**
 * @charset UTF-8
 * Flight Crew Base API Validation Tests
 */
import { test, expect } from '@playwright/test';
import { runAPITest, httpRequest, buildUrl } from '../../../utils/helpers/apiHelper.js';
import { ReportHelper } from '../../../utils/helpers/ReportHelper.js';
import { FILE_PATHS, ENV_CONFIG_KEYS, HTTP_METHODS, STATUS_CODES } from '../../../utils/constants/Constants.js';
import { getCrewBaseIdFromDB, verifyRecordDeletedFromDB, validateRequestBodyVsDB, validateListAPIvsDB, runPositiveFlow } from '../../../pages/api/crewBaseApiPage.js';
import { generateRandomCrewBase } from '../../../utils/helpers/random.js';
import * as allure from 'allure-js-commons';
import { getEnvVariable } from '../../../utils/config/EnvLoader.js';
import fs from 'fs';

// ==================== CONFIG ====================

const postTestData = JSON.parse(fs.readFileSync(`${process.cwd()}/${FILE_PATHS.FLIGHT_CREW_BASE_POST_TEST_CASES}`, 'utf-8'));
const deleteTestData = JSON.parse(fs.readFileSync(`${process.cwd()}/${FILE_PATHS.FLIGHT_CREW_BASE_DELETE_TEST_CASES}`, 'utf-8'));
const apiBaseUrl = getEnvVariable(ENV_CONFIG_KEYS.URL_OPSHUB);
const endpoints = {
    maintain: getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_FLIGHT_CREW_BASE_MAINTAIN),
    delete: getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_FLIGHT_CREW_BASE_DELETE),
    list: getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_FLIGHT_CREW_BASE_LIST)
};


// ==================== TESTS ====================
test.describe('Flight Crew Base API Validation Tests', () => {

    test.describe('Crew Base Maintain & Delete APIs', () => {
        test.describe.configure({ mode: 'parallel' });

        test.describe('Crew Base Maintain (POST) API', () => {
            for (const testData of postTestData) {
                test(`[${testData.Test_ID}] ${testData.Scenario}`, { tag: ['@sanity', '@regression'] }, async ({ request }) => {
                    const body = JSON.parse(testData.RequestBody);
                    const expectedStatus = parseInt(testData['Expected Status']);
                    const expectedResponse = testData['Expected Response'];
                    const maintainUrl = buildUrl(apiBaseUrl, endpoints.maintain);

                    if (expectedStatus === STATUS_CODES.OK && body.crewBase) {
                        if (body.id) {
                            // UPDATE FLOW
                            await runPositiveFlow(request, { body, expectedStatus, expectedResponse, testData, apiBaseUrl, endpoint: endpoints.maintain, isUpdate: true });
                        } else {
                            // CREATE FLOW - Generate random crewBase
                            const randomCrewBase = generateRandomCrewBase();
                            const createBody = { ...body, crewBase: randomCrewBase };
                            let createStatus, createResponse;
                            await allure.step('Step 1: Create record', async () => {
                                const res = await httpRequest(request, {
                                    method: HTTP_METHODS.POST,
                                    url: maintainUrl,
                                    body: createBody
                                });
                                createStatus = res.status();
                                createResponse = await res.text();
                                await allure.attachment('Generated CrewBase', randomCrewBase, ENV_CONFIG_KEYS.CONTENT_TYPE);
                            });
                            await allure.step('Step 2: Validate Expected vs API Response', async () => {
                                await ReportHelper.validateResponse(expectedStatus, createStatus, expectedResponse, createResponse,
                                    { Test_ID: testData.Test_ID, baseUrl: apiBaseUrl, endpoint: endpoints.maintain, requestData: { data: createBody } });
                            });
                            await allure.step('Step 3: Validate Request vs DB', async () => {
                                const result = await validateRequestBodyVsDB(randomCrewBase, createBody, expectedStatus, createStatus);
                                expect(result.isValid).toBe(true);
                            });
                        }
                    } else {
                        // NEGATIVE SCENARIOS
                        await runAPITest({ apiName: 'Crew Base Maintain', testData, endpoint: endpoints.maintain,
                            requestFn: () => httpRequest(request, { method: HTTP_METHODS.POST, url: maintainUrl, body }), isQueryParams: false });
                    }
                });
            }
        });

        test.describe('Crew Base Delete (DELETE) API', () => {
            for (const testData of deleteTestData) {
                test(`[${testData.Test_ID}] ${testData.Scenario}`, { tag: ['@sanity', '@regression'] }, async ({ request }) => {
                    const expectedStatus = parseInt(testData['Expected Status']);

                    if (expectedStatus === STATUS_CODES.OK) {
                        // Generate random crewBase to avoid DB cleanup dependency
                        const randomCrewBase = generateRandomCrewBase();
                        const chiefPilotEmail = testData.chiefPilotEmail;
                        const expectedResponse = testData['Expected Response'];
                        const maintainUrl = buildUrl(apiBaseUrl, endpoints.maintain), deleteUrl = buildUrl(apiBaseUrl, endpoints.delete);

                        await allure.step('Step 1: Create record', async () => {
                            const res = await httpRequest(request, {
                                method: HTTP_METHODS.POST,
                                url: maintainUrl,
                                body: { crewBase: randomCrewBase, chiefPilotEmail }
                            });
                            expect(res.status()).toBe(STATUS_CODES.OK);
                            await allure.attachment('Generated CrewBase', randomCrewBase, ENV_CONFIG_KEYS.CONTENT_TYPE);
                        });

                        const capturedId = await allure.step('Step 2: Capture ID from DB', async () => {
                            const id = await getCrewBaseIdFromDB(randomCrewBase);
                            expect(id).not.toBeNull();
                            return id;
                        });

                        let deleteStatus, deleteResponse;
                        await allure.step('Step 3: Delete record', async () => {
                            const res = await httpRequest(request, {
                                method: HTTP_METHODS.DELETE,
                                url: `${deleteUrl}?id=${capturedId}`
                            });
                            deleteStatus = res.status();
                            deleteResponse = await res.text();
                        });

                        await allure.step('Step 4: Validate Expected vs API Response', async () => {
                            await ReportHelper.validateResponse(expectedStatus, deleteStatus, expectedResponse, deleteResponse,
                                { Test_ID: testData.Test_ID, baseUrl: apiBaseUrl, endpoint: endpoints.delete, requestData: { data: `id=${capturedId}`, isQueryParams: true } });
                        });

                        await allure.step('Step 5: Verify record deleted from DB', async () => {
                            expect(await verifyRecordDeletedFromDB(capturedId)).toBe(true);
                        });
                    } else {
                        // NEGATIVE SCENARIOS
                        const deleteUrl = buildUrl(apiBaseUrl, endpoints.delete);
                        const queryParam = testData.Query_Params ? `?${testData.Query_Params}` : '';
                        await runAPITest({ apiName: 'Crew Base Delete', testData, endpoint: endpoints.delete,
                            requestFn: () => httpRequest(request, { method: HTTP_METHODS.DELETE, url: `${deleteUrl}${queryParam}` }), isQueryParams: true });
                    }
                });
            }
        });
    });

    test.describe('Crew Base List (GET) API', () => {
        test('[TC_001] Retrieve all crew base records', { tag: ['@sanity', '@regression'] }, async ({ request }) => {
            const listUrl = buildUrl(apiBaseUrl, endpoints.list);

            let apiResponse, actualStatus;
            await allure.step('Step 1: Call List API', async () => {
                const res = await httpRequest(request, {
                    method: HTTP_METHODS.GET,
                    url: listUrl
                });
                actualStatus = res.status();
                const text = await res.text();
                await allure.attachment('API URL', listUrl, ENV_CONFIG_KEYS.CONTENT_TYPE);
                await allure.attachment('Response', text, ENV_CONFIG_KEYS.CONTENT_TYPE);
                try { apiResponse = JSON.parse(text); } catch { apiResponse = text; }
                expect(actualStatus).toBe(STATUS_CODES.OK);
            });

            await allure.step('Step 2: Validate API vs DB', async () => {
                const result = await validateListAPIvsDB(apiResponse, STATUS_CODES.OK, actualStatus);
                expect(result.isValid).toBe(true);
            });
        });
    });
});
