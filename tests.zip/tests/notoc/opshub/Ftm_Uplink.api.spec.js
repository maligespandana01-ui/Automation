/**
 * @charset UTF-8
 * FTM Uplink API Validation Tests
 */
import { test, expect } from '@playwright/test';
import { runAPITest, httpRequest, buildUrl } from '../../../utils/helpers/apiHelper.js';
import { getEnvVariable } from '../../../utils/config/EnvLoader.js';
import { FILE_PATHS, ENV_CONFIG_KEYS, HTTP_METHODS } from '../../../utils/constants/Constants.js';
import fs from 'fs';

const ftmUplinkTestData = JSON.parse(fs.readFileSync(`${process.cwd()}/${FILE_PATHS.FTM_UPLINK_TEST_CASES}`, 'utf-8'));


const apiBaseUrl = getEnvVariable(ENV_CONFIG_KEYS.URL_OPSHUB);
const endpoints = {
    ftmUplink: getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_FTM_UPLINK)
};

test.describe('FTM Uplink API Validation Tests', () => {
    test.describe('FTM Uplink - Send FTM Uplink ACARS Endpoint Tests', () => {
        for (const testData of ftmUplinkTestData) {
            test(`[${testData.Test_ID}] FTM Uplink - ${testData.Scenario}`, { tag: ['@sanity', '@regression'] }, async ({ request }) => {
                const body = JSON.parse(testData.RequestBody);
                await runAPITest({
                    apiName: 'FTM Uplink',
                    testData,
                    endpoint: endpoints.ftmUplink,
                    requestFn: () => httpRequest(request, {
                        method: HTTP_METHODS.POST,
                        url: buildUrl(apiBaseUrl, endpoints.ftmUplink),
                        body
                    }),
                    isQueryParams: false
                });
            });
        }
    });
});
