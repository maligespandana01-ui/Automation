﻿/**
 * @charset UTF-8
 * Emergency Response Report â€” NTM + XSDG Source Validation (E2E)
 *
 * Replaces DB-based validation with file-based validation using NTM and XSDG
 * sample files as the source of expected (golden) data.
 *
 * Flow:
 * 1. Read NTM text from ntm_processing_test_data_backup.json
 * 2. Parse NTM â†’ extract flight info (number, date, origin, destination)
 * 3. Read and parse XSDG XML â†’ extract expected hazmat details
 * 4. Login to AutoNOTOC
 * 5. Navigate to Emergency Response Report screen
 * 6. Fill search criteria from NTM flight info and submit
 * 7. Extract full report data from UI
 * 8. Cross-validate UI (actual) vs NTM + XSDG (expected) with Allure steps
 * 9. Export PDF and validate content against NTM/XSDG values
 *
 * Data sources:
 *   NTM: data/test_data/icargo_ntm_processing/TEMPLATE/ntm_processing_test_data_backup.json
 *   XSDG: data/test_data/icargo_ntm_processing/TEMPLATE/XSDG_DATA/emergency resposne report sample.xml
 */
import { test, expect } from '@playwright/test';
import fs from 'fs';
import path from 'path';
import * as allure from 'allure-js-commons';

import { BrowserHelpers } from '../../../utils/helpers/BrowserHelpers.js';
import { AutoNotocLoginPage } from '../../../pages/ui/autonotoc/AutoNotocLoginPage.js';
import { EmergencyResponseReportPage } from '../../../pages/ui/autonotoc/EmergencyResponseReportPage.js';
import { NtmParser } from '../../../utils/helpers/NtmParser.js';
import { XsdgParser } from '../../../utils/helpers/XsdgParser.js';
import { EmergencyResponseNtmXsdgValidator } from '../../../utils/helpers/EmergencyResponseNtmXsdgValidator.js';
import { PdfValidator } from '../../../utils/helpers/PdfValidator.js';
import { getEnvVariable } from '../../../utils/config/EnvLoader.js';
import { ENV_CONFIG_KEYS } from '../../../utils/constants/Constants.js';
import { Logger } from '../../../utils/helpers/Logger.js';

// ==================== DATA FILE PATHS ====================
const NTM_TEST_DATA_FILE = path.resolve(
    process.cwd(),
    'data/test_data/icargo_ntm_processing/TEMPLATE/ntm_processing_test_data_backup.json'
);

const XSDG_XML_FILE = path.resolve(
    process.cwd(),
    'data/test_data/icargo_ntm_processing/TEMPLATE/XSDG_DATA/emergency resposne report sample.xml'
);

const PDF_DOWNLOAD_DIR = path.join(process.cwd(), 'test-results', 'pdf-downloads');

// ==================== LOAD DATA AT MODULE LEVEL ====================

/**
 * Loads NTM text from the test data JSON backup file.
 * @returns {{ ntmText: string, testCaseId: string, scenarioTitle: string }}
 */
function loadNtmTestData() {
    if (!fs.existsSync(NTM_TEST_DATA_FILE)) {
        throw new Error(`NTM test data file not found: ${NTM_TEST_DATA_FILE}`);
    }
    const raw = JSON.parse(fs.readFileSync(NTM_TEST_DATA_FILE, 'utf8'));
    const entry = raw.find(tc => {
        const exec = tc?.EXECUTION_SEQUENCE?.['1'];
        return exec?.NTM && exec.NTM.trim().length > 0;
    });
    if (!entry) throw new Error('No NTM text found in test data file');
    return {
        ntmText: entry.EXECUTION_SEQUENCE['1'].NTM,
        testCaseId: entry.TEST_CASE_ID || 'TC_0001',
        scenarioTitle: entry.SCENARIO_TITLE || 'Emergency Response Report Test',
    };
}

/** Ensures PDF download directory exists. */
function ensureDownloadDir() {
    if (!fs.existsSync(PDF_DOWNLOAD_DIR)) fs.mkdirSync(PDF_DOWNLOAD_DIR, { recursive: true });
}

// ==================== TEST SUITE ====================

test.describe('Emergency Response Report â€” NTM + XSDG Source Validation (E2E)', () => {

    test('[ERR_NTM_01] Validate ERR UI against NTM + XSDG expected data, export PDF', {
        tag: ['@e2e', '@err', '@ntm', '@xsdg', '@validation'],
    }, async () => {

        // â”€â”€ Pre-condition: Load and parse NTM + XSDG data â”€â”€
        const { ntmText, testCaseId, scenarioTitle } = loadNtmTestData();

        await allure.displayName(`ERR NTM+XSDG Validation â€” ${testCaseId}: ${scenarioTitle}`);
        await allure.severity('critical');
        await allure.description(
            `End-to-end validation of the Emergency Response Report.\n\n` +
            `Expected data source: NTM text message + XSDG XML file.\n` +
            `UI values are the ACTUAL data; NTM + XSDG values are the EXPECTED data.\n\n` +
            `Validates:\n` +
            `  - Flight info (number, date, origin, destination) vs NTM\n` +
            `  - AWB number vs XSDG\n` +
            `  - Hazmat rows (PSN, class, UNID, PG, pieces, net qty/TI) vs XSDG + NTM\n` +
            `  - PDF export content\n\n` +
            `NTM file: ntm_processing_test_data_backup.json\n` +
            `XSDG file: emergency resposne report sample.xml`
        );

        // Parse NTM + XSDG
        const ntmData = NtmParser.parse(ntmText);
        const xsdgData = XsdgParser.parse(XSDG_XML_FILE);

        const searchCriteria = {
            flightDate: ntmData.flightInfo.flightDate,
            flightNumber: ntmData.flightInfo.flightNumber,
            origin: ntmData.flightInfo.origin,
        };

        // Attach source data
        await allure.attachment('NTM Raw Text', ntmText, 'text/plain');
        await allure.attachment('NTM Parsed â€” Flight + DG Items', JSON.stringify(ntmData, null, 2), 'application/json');
        await allure.attachment('XSDG Parsed â€” AWB + DG Items', JSON.stringify(xsdgData, null, 2), 'application/json');
        await allure.attachment('Search Criteria (from NTM)', JSON.stringify(searchCriteria, null, 2), 'application/json');

        // Attach expected values clearly
        await allure.attachment('Expected: NTM Flight Info', JSON.stringify(ntmData.flightInfo, null, 2), 'application/json');
        await allure.attachment('Expected: XSDG DG Items', JSON.stringify(xsdgData.dgItems, null, 2), 'application/json');
        await allure.attachment('Expected: XSDG AWB + Shipper', JSON.stringify({
            awbNumber: xsdgData.awbNumber,
            shipperName: xsdgData.shipperName,
            consigneeName: xsdgData.consigneeName,
            origin: xsdgData.origin,
            destination: xsdgData.destination,
            emergencyContact: xsdgData.emergencyContact,
            emergencyPhone: xsdgData.emergencyPhone,
            aircraftLimitation: xsdgData.aircraftLimitation,
        }, null, 2), 'application/json');
        await allure.attachment('Expected: NTM DG Items', JSON.stringify(ntmData.dgItems, null, 2), 'application/json');

        Logger.info('ERR-NTM-Test', 'Parsed NTM flight info', ntmData.flightInfo);
        Logger.info('ERR-NTM-Test', `XSDG: AWB=${xsdgData.awbNumber}, ${xsdgData.dgItems.length} DG items`);

        let browserPage;
        let errPage;
        let reportData;

        try {
            // â”€â”€ Step 1: Launch browser and login â”€â”€
            await allure.step('Step 1: Launch browser and login to AutoNOTOC', async () => {
                browserPage = await BrowserHelpers.launchBrowser();
                const loginPage = new AutoNotocLoginPage(browserPage);
                await loginPage.login(
                    getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_USERNAME),
                    getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_PASSWORD)
                );
                Logger.info('ERR-NTM-Test', 'Login successful');
            });

            // â”€â”€ Step 2: Navigate to ERR screen â”€â”€
            await allure.step('Step 2: Navigate to Emergency Response Report screen', async () => {
                errPage = new EmergencyResponseReportPage(browserPage);
                await errPage.navigateToEmergencyResponseReport();
                await errPage.captureScreenshot('ERR Search Screen');
                Logger.info('ERR-NTM-Test', 'Navigated to ERR screen');
            });

            // â”€â”€ Step 3: Fill search criteria from NTM and submit â”€â”€
            await allure.step(
                `Step 3: Fill search criteria from NTM (flight=${searchCriteria.flightNumber}, date=${searchCriteria.flightDate}, origin=${searchCriteria.origin}) and submit`,
                async () => {
                    await errPage.searchAndSubmit(searchCriteria);
                    const isVisible = await errPage.isReportVisible();
                    expect(isVisible, 'Emergency Response Report should be visible after submit').toBeTruthy();
                    await errPage.captureScreenshot('ERR Report Rendered');
                    Logger.info('ERR-NTM-Test', 'Report rendered successfully after submit');
                }
            );

            // â”€â”€ Step 4: Extract full report data from UI â”€â”€
            await allure.step('Step 4: Extract full report data from UI', async () => {
                reportData = await errPage.extractFullReportData();

                expect(
                    reportData.hazmatRows.length,
                    'Report should contain at least one hazmat detail row'
                ).toBeGreaterThan(0);

                // Attach each UI section clearly, mirroring DB spec style
                await allure.attachment('Actual: UI Flight Info', JSON.stringify(reportData.flightInfo, null, 2), 'application/json');
                await allure.attachment('Actual: UI Hazmat Rows', JSON.stringify(reportData.hazmatRows, null, 2), 'application/json');
                await allure.attachment('Actual: UI AWB Headers', JSON.stringify(reportData.awbHeaders, null, 2), 'application/json');
                await allure.attachment('Actual: UI Bin Location', reportData.binLocation || 'Not Available', 'text/plain');
                await allure.attachment('Actual: UI Unit Number', reportData.unitNumber || 'N/A', 'text/plain');
                await allure.attachment('Actual: UI Full Report Data', JSON.stringify(reportData, null, 2), 'application/json');

                Logger.info('ERR-NTM-Test', 'UI report data extracted', {
                    flightInfo: reportData.flightInfo,
                    hazmatRowCount: reportData.hazmatRows.length,
                    awbHeaders: reportData.awbHeaders,
                });
            });

            // â”€â”€ Step 5: Cross-validate UI vs NTM + XSDG â”€â”€
            await allure.step('Step 5: Cross-validate UI (actual) vs NTM + XSDG (expected)', async () => {

                // 5a. Flight info: NTM â†’ UI
                await allure.step('5a: Validate flight info â€” NTM (expected) vs UI (actual)', async () => {
                    await allure.attachment('Expected: NTM Flight Info', JSON.stringify(ntmData.flightInfo, null, 2), 'application/json');
                    await allure.attachment('Actual: UI Flight Info', JSON.stringify(reportData.flightInfo, null, 2), 'application/json');

                    const result = EmergencyResponseNtmXsdgValidator.validateFlightInfo(reportData, ntmData.flightInfo);
                    await allure.attachment('Flight Info Validation Results', JSON.stringify(result.results, null, 2), 'application/json');
                    await allure.attachment('Flight Info Comparison (NTM vs UI Screen)',
                        EmergencyResponseNtmXsdgValidator.generateSectionHtml(
                            'Flight Info — NTM (Expected) vs UI Screen (Actual)', result.results, 'NTM'),
                        'text/html');

                    for (const r of result.results) {
                        expect.soft(r.status, `Flight ${r.field}: expected="${r.expected}", actual="${r.actual}"`).toBe('PASS');
                    }
                    Logger.info('ERR-NTM-Test', `Flight info validation: ${result.allPassed ? 'ALL PASSED' : 'FAILURES'}`);
                });

                // 5b. AWB info: XSDG â†’ UI
                await allure.step('5b: Validate AWB number â€” XSDG (expected) vs UI (actual)', async () => {
                    await allure.attachment('Expected: XSDG AWB Number', xsdgData.awbNumber, 'text/plain');
                    await allure.attachment('Actual: UI AWB Headers', JSON.stringify(reportData.awbHeaders, null, 2), 'application/json');

                    const result = EmergencyResponseNtmXsdgValidator.validateAwbInfo(reportData, xsdgData);
                    await allure.attachment('AWB Validation Results', JSON.stringify(result.results, null, 2), 'application/json');
                    await allure.attachment('AWB Comparison (XSDG vs UI Screen)',
                        EmergencyResponseNtmXsdgValidator.generateSectionHtml(
                            'AWB Info — XSDG (Expected) vs UI Screen (Actual)', result.results, 'XSDG'),
                        'text/html');

                    for (const r of result.results) {
                        expect.soft(r.status, `AWB ${r.field}: expected="${r.expected}", actual="${r.actual}"`).toBe('PASS');
                    }
                    Logger.info('ERR-NTM-Test', `AWB validation: ${result.allPassed ? 'ALL PASSED' : 'FAILURES'}`);
                });

                // 5c. Per-ULD hazmat rows: NTM (per ULD) + XSDG (shared) â†’ UI boxes
                await allure.step('5c: Validate hazmat detail rows per ULD â€” NTM (per ULD) + XSDG (shared) vs UI boxes', async () => {
                    const ntmGroups = NtmParser.groupByUld(ntmData.dgItems);

                    await allure.attachment('Expected: NTM DG Items grouped by ULD',
                        JSON.stringify(ntmGroups.map(g => ({
                            uld: g.uld,
                            rows: g.items.map(i => ({
                                unid: i.unid, pieces: i.pieces, netQty: `${i.netQty}${i.netQtyUnit}`,
                                packingGroup: i.packingGroup, classDivision: i.classDivision, rq: i.rq,
                            })),
                        })), null, 2), 'application/json');
                    await allure.attachment('Expected: XSDG shared DG data (per AWB)',
                        JSON.stringify({ awbNumber: xsdgData.awbNumber, dgItems: xsdgData.dgItems }, null, 2), 'application/json');
                    await allure.attachment('Actual: UI Report Boxes (per ULD)',
                        JSON.stringify(reportData.boxes, null, 2), 'application/json');

                    const result = EmergencyResponseNtmXsdgValidator.validatePerUld(reportData, ntmData, xsdgData);

                    // Per-box comparison sub-steps with Expected-vs-Actual tables.
                    for (const box of result.boxResults) {
                        await allure.step(`ULD ${box.uld} â€” NTM + XSDG (expected) vs UI box (actual)`, async () => {
                            await allure.attachment(`ULD ${box.uld} Validation Results`,
                                JSON.stringify(box.results, null, 2), 'application/json');
                            await allure.attachment(`ULD ${box.uld} Comparison (NTM + XSDG vs UI Box)`,
                                EmergencyResponseNtmXsdgValidator.generateSectionHtml(
                                    `ULD ${box.uld} — NTM (per ULD) + XSDG (shared) vs UI Box`,
                                    box.results, 'NTM/XSDG'),
                                'text/html');
                            for (const r of box.results) {
                                expect.soft(r.status, `ULD ${box.uld} ${r.field}: expected="${r.expected}", actual="${r.actual}"`).toBe('PASS');
                            }
                        });
                    }

                    await allure.attachment('Per-ULD Validation (all boxes)',
                        EmergencyResponseNtmXsdgValidator.generatePerUldHtml(result.boxResults), 'text/html');
                    await allure.attachment('Per-ULD Validation Results (JSON)',
                        JSON.stringify(result.results, null, 2), 'application/json');

                    // Box count assertion.
                    expect.soft(reportData.boxes.length,
                        `Number of UI ULD boxes should equal NTM ULD groups (${ntmGroups.length})`)
                        .toBe(ntmGroups.length);

                    Logger.info('ERR-NTM-Test', `Per-ULD validation: ${result.allPassed ? 'ALL PASSED' : 'FAILURES'}`, {
                        boxes: reportData.boxes.length,
                        ntmGroups: ntmGroups.length,
                        total: result.results.length,
                        passed: result.results.filter(r => r.status === 'PASS').length,
                        failed: result.results.filter(r => r.status !== 'PASS').length,
                    });
                });

                // 5d. Emergency Contact Num (static, same for all scenarios)
                await allure.step('5d: Validate Emergency Contact Num â€” Static (expected) vs UI (actual)', async () => {
                    await allure.attachment('Actual: UI Emergency Contact', JSON.stringify(reportData.emergencyContact, null, 2), 'application/json');

                    const result = EmergencyResponseNtmXsdgValidator.validateEmergencyContact(reportData);
                    await allure.attachment('Emergency Contact Validation Results', JSON.stringify(result.results, null, 2), 'application/json');
                    await allure.attachment('Emergency Contact Comparison (Static vs UI Screen)',
                        EmergencyResponseNtmXsdgValidator.generateSectionHtml(
                            'Emergency Contact Num — Static (Expected) vs UI Screen (Actual)', result.results, 'Static'),
                        'text/html');

                    for (const r of result.results) {
                        expect.soft(r.status, `EmergencyContact ${r.field}: expected="${r.expected}", actual="${r.actual}"`).toBe('PASS');
                    }
                    Logger.info('ERR-NTM-Test', `Emergency contact validation: ${result.allPassed ? 'ALL PASSED' : 'FAILURES'}`);
                });

                // 5e. Special Handling Info (conditional â€” only populated if XSDG has a value)
                await allure.step('5e: Validate Special Handling Info â€” XSDG (expected) vs UI (actual)', async () => {
                    await allure.attachment('Expected: XSDG Special Handling', xsdgData.specialHandlingInfo || '(empty)', 'text/plain');
                    await allure.attachment('Actual: UI Special Handling', reportData.specialHandlingInfo || '(empty)', 'text/plain');

                    const result = EmergencyResponseNtmXsdgValidator.validateSpecialHandling(reportData, xsdgData);
                    await allure.attachment('Special Handling Validation Results', JSON.stringify(result.results, null, 2), 'application/json');
                    await allure.attachment('Special Handling Comparison (XSDG vs UI Screen)',
                        EmergencyResponseNtmXsdgValidator.generateSectionHtml(
                            'Special Handling Info — XSDG (Expected) vs UI Screen (Actual)', result.results, 'XSDG'),
                        'text/html');

                    for (const r of result.results) {
                        expect.soft(r.status, `SpecialHandling ${r.field}: expected="${r.expected}", actual="${r.actual}"`).toBe('PASS');
                    }
                    Logger.info('ERR-NTM-Test', `Special handling validation: ${result.allPassed ? 'ALL PASSED' : 'FAILURES'}`);
                });

                // 5f. Verified By + Emp Num (from XSDG declarant authentication)
                await allure.step('5f: Validate Verified By + Emp Num â€” XSDG (expected) vs UI (actual)', async () => {
                    await allure.attachment('Expected: XSDG Verified By',
                        `${xsdgData.verifiedByName} / ${xsdgData.verifiedByEmpNum}`, 'text/plain');
                    await allure.attachment('Actual: UI Verification Info', JSON.stringify(reportData.verificationInfo, null, 2), 'application/json');

                    const result = EmergencyResponseNtmXsdgValidator.validateVerifiedBy(reportData, xsdgData);
                    await allure.attachment('Verified By Validation Results', JSON.stringify(result.results, null, 2), 'application/json');
                    await allure.attachment('Verified By Comparison (XSDG vs UI Screen)',
                        EmergencyResponseNtmXsdgValidator.generateSectionHtml(
                            'Verified By — XSDG (Expected) vs UI Screen (Actual)', result.results, 'XSDG'),
                        'text/html');

                    for (const r of result.results) {
                        expect.soft(r.status, `VerifiedBy ${r.field}: expected="${r.expected}", actual="${r.actual}"`).toBe('PASS');
                    }
                    Logger.info('ERR-NTM-Test', `Verified-by validation: ${result.allPassed ? 'ALL PASSED' : 'FAILURES'}`);
                });

                // 5g. Static notice blocks (same on all screens)
                await allure.step('5g: Validate static notice sections â€” Static (expected) vs UI (actual)', async () => {
                    const result = EmergencyResponseNtmXsdgValidator.validateStaticSections(reportData);
                    await allure.attachment('Static Sections Validation Results', JSON.stringify(result.results, null, 2), 'application/json');
                    await allure.attachment('Static Sections Comparison (Static vs UI Screen)',
                        EmergencyResponseNtmXsdgValidator.generateSectionHtml(
                            'Static Notices — Static (Expected) vs UI Screen (Actual)', result.results, 'Static'),
                        'text/html');

                    for (const r of result.results) {
                        expect.soft(r.status, `StaticSection ${r.field}: expected="${r.expected}", actual="${r.actual}"`).toBe('PASS');
                    }
                    Logger.info('ERR-NTM-Test', `Static sections validation: ${result.allPassed ? 'ALL PASSED' : 'FAILURES'}`);
                });

                // 5h. End-of-report footer (flight date / number / origin / destination)
                await allure.step('5h: Validate End of Report footer â€” NTM (expected) vs UI (actual)', async () => {
                    await allure.attachment('Actual: UI End-of-Report Footer', reportData.endOfReport || '(none)', 'text/plain');

                    const result = EmergencyResponseNtmXsdgValidator.validateEndOfReport(reportData, ntmData);
                    await allure.attachment('End of Report Validation Results', JSON.stringify(result.results, null, 2), 'application/json');
                    await allure.attachment('End of Report Comparison (NTM vs UI Footer)',
                        EmergencyResponseNtmXsdgValidator.generateSectionHtml(
                            'End of Report Footer — NTM (Expected) vs UI Screen (Actual)', result.results, 'NTM'),
                        'text/html');

                    for (const r of result.results) {
                        expect.soft(r.status, `EndOfReport ${r.field}: expected="${r.expected}", actual="${r.actual}"`).toBe('PASS');
                    }
                    Logger.info('ERR-NTM-Test', `End-of-report validation: ${result.allPassed ? 'ALL PASSED' : 'FAILURES'}`);
                });

                // Full validation summary with HTML comparison table
                const fullResult = await EmergencyResponseNtmXsdgValidator.validateAll(reportData, xsdgData, ntmData);

                const { summary } = fullResult;
                await allure.attachment('Validation Summary', JSON.stringify(summary, null, 2), 'application/json');

                Logger.info('ERR-NTM-Test',
                    `Full validation: ${fullResult.overallPassed ? 'ALL PASSED' : 'SOME FAILURES'}`,
                    summary
                );
            });

            // â”€â”€ Step 6: Export PDF and validate content â”€â”€
            await allure.step('Step 6: Export Emergency Response Report to PDF and validate', async () => {
                ensureDownloadDir();

                const pdfPath = await errPage.exportToPdf(PDF_DOWNLOAD_DIR);
                expect(fs.existsSync(pdfPath), `PDF should be downloaded at: ${pdfPath}`).toBeTruthy();
                await allure.attachment('PDF File Path', pdfPath, 'text/plain');
                Logger.info('ERR-NTM-Test', `PDF downloaded: ${pdfPath}`);
                await errPage.captureScreenshot('After PDF Export');

                await allure.step('Step 6a: Validate PDF content against UI report data', async () => {
                    const { results: pdfResults, allPassed: pdfAllPassed, pdfText } =
                        await PdfValidator.validateEmergencyResponsePdf(pdfPath, reportData);

                    await allure.attachment('PDF Extracted Text', pdfText, 'text/plain');
                    await allure.attachment('PDF Validation Results', JSON.stringify(pdfResults, null, 2), 'application/json');
                    await allure.attachment('PDF Validation Summary', JSON.stringify({
                        total: pdfResults.length,
                        passed: pdfResults.filter(r => r.status === 'PASS').length,
                        failed: pdfResults.filter(r => r.status !== 'PASS').length,
                        allPassed: pdfAllPassed,
                    }, null, 2), 'application/json');

                    for (const r of pdfResults) {
                        expect.soft(r.status, `PDF ${r.field}: expected "${r.expected}"`).toBe('PASS');
                    }
                    Logger.info('ERR-NTM-Test',
                        `PDF validation: ${pdfAllPassed ? 'ALL PASSED' : 'SOME FAILURES'}`,
                        { total: pdfResults.length, passed: pdfResults.filter(r => r.status === 'PASS').length }
                    );
                });

                PdfValidator.cleanup(pdfPath);
            });

        } finally {
            if (browserPage) {
                const browser = browserPage.context()?.browser();
                if (browser) await browser.close();
            }
        }
    });
});


//node node_modules\allure-commandline\bin\allure generate allure-results --clean -o allure-report
//node node_modules\allure-commandline\bin\allure open allure-report