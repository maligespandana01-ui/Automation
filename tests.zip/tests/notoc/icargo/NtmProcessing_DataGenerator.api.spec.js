import { test } from '@playwright/test';
import { FILE_PATHS } from '../../../utils/constants/Constants.js';
import { readJsonFile } from '../../../utils/helpers/JsonUtils.js';
import * as allure from 'allure-js-commons';
import path from 'path';
import { getEnvVariable } from '../../../utils/config/EnvLoader.js';
import { ENV_CONFIG_KEYS, DEFAULTS } from '../../../utils/constants/Constants.js';
import { executeOracleQuery } from '../../../utils/helpers/database.js';
import { TIMEOUTS } from '../../../utils/constants/Constants.js';
import { generateAwb } from '../../../utils/helpers/awbUtils.js';
import { getDateWithOffset, isMatchingDateFormat, parse_MMddYYYY, replaceDatePlaceholders } from '../../../utils/helpers/DateUtils.js';
import { LoginPage } from '../../../pages/ui/notoc_legacy/LoginPage.js';
import { NtmXsdgMessagesPostingPage, NTM_XSDG_MESSAGES_POSTING_PAGE } from '../../../pages/ui/notoc_legacy/NtmXsdgMessagesPostingPage.js';
import fs from 'fs';
import { BrowserHelpers } from '../../../utils/helpers/BrowserHelpers.js';

import util from "node:util";
util.inspect.defaultOptions.maxStringLength = null;


// Load Test Data
const templateFilePath = path.join(process.cwd(), FILE_PATHS.NTM_PROCESSING_TEST_DATA_TEMPLATE);
const templateData = readJsonFile(templateFilePath);
const timezone = getEnvVariable(DEFAULTS.DEFAULT_TIMEZONE) || 'Asia/Kolkata'; // Default to IST timezone if not set in env variables
const dbQueriesFilePath = path.join(process.cwd(), FILE_PATHS.DB_QUERIES);
const dbQueries = readJsonFile(dbQueriesFilePath);
const xsdgs_generated_folder_path = path.join(process.cwd(), FILE_PATHS.NTM_PROCESSING_TEST_DATA_XML_OUTPUT_FOLDER);
let notocPage;

//final test data array map - make this global
let finalTestData = [];
//iCargo interface retry count for flaky issues
const iCargoInterfaceRetryCount = 5;
//parallel execution count for processing template test data
const testDataParallelLimit = Number(process.env.NTM_TEST_DATA_PARALLEL_LIMIT || 5);

test.describe.serial('iCargo - NTM Processing Test Data Generation', async () => {
    test('Generate NTM processing test data from template', async () => {
        //Loop through each test case in the test data template
        const generatedTestDataEntries = [];

        for (let startIndex = 0; startIndex < templateData.length; startIndex += testDataParallelLimit) {
            const currentBatch = templateData.slice(startIndex, startIndex + testDataParallelLimit);
            const currentBatchEntries = await Promise.all(currentBatch.map(async (currentTestData, batchIndex) => {
                const index = startIndex + batchIndex;
                let currentTestDataEntry = {};
                const testCaseIdCounter = index + 1;
                const testCaseId = `TC_${String(testCaseIdCounter).padStart(4, '0')}`;

                try {
                    //allure log - generating test data for current test case
                    await allure.step(`GENERATING TEST DATA FROM TEMPLATE FOR TC: ${testCaseIdCounter}`, async () => {
                        console.log(`GENERATING TEST TEMPLATE FOR TC: ${testCaseIdCounter}`);

                        //Fetch all keys in current test data
                        const testDataKeys = Object.keys(currentTestData);

                        //add all keys and data to finalTestData except "EXECUTION_SEQUENCE", "TEST_CASE_ID", and "S_NO"
                        for (const currentKey of testDataKeys) {
                            if (currentKey !== 'EXECUTION_SEQUENCE' && currentKey !== 'TEST_CASE_ID' && currentKey !== 'S_NO') {
                                currentTestDataEntry[currentKey] = currentTestData[currentKey];
                            }
                        }

                        //insert test case id and s.no. in currentTestDataEntry
                        currentTestDataEntry.TEST_CASE_ID = testCaseId;
                        currentTestDataEntry.S_NO = testCaseIdCounter;
                        currentTestDataEntry.EXECUTION_SEQUENCE = {};

                        //verify execution sequence is present in order "1", "2", "3", etc. in current test data, if not throw error
                        const executionSequenceKeys = Object.keys(currentTestData.EXECUTION_SEQUENCE);
                        for (let i = 0; i < executionSequenceKeys.length; i++) {
                            if (executionSequenceKeys[i] !== String(i + 1)) {
                                throw new Error(`Execution sequence is not in order for TC: ${testCaseId}. Please check and re-run again`);
                            }
                            //add execution sequence to currentTestDataEntry
                            currentTestDataEntry.EXECUTION_SEQUENCE[executionSequenceKeys[i]] = currentTestData.EXECUTION_SEQUENCE[executionSequenceKeys[i]];
                        }

                        //awbs map
                        let generatedAwbsMap = {};
                        let awbsInCurrentTestScenario = {};
                        for (const currentExecutionSequence of Object.keys(currentTestData.EXECUTION_SEQUENCE)) {
                            //XSDGs
                            let xsdgs_dynamic = [];
                            let xsdgs_actual = [];
                            let xsdgs_generated = [];
                            let xsdgs_dynamic_paths = [];
                            //AWBs Map
                            // let awbsInCurrentSequence = {};

                            if (currentTestData.EXECUTION_SEQUENCE[currentExecutionSequence].hasOwnProperty('XSDGs')) {
                                //fail if xsdgs are not in array format
                                if (!Array.isArray(currentTestData.EXECUTION_SEQUENCE[currentExecutionSequence].XSDGs)) {
                                    throw new Error(`XSDG should be in array format for TC: ${testCaseId}. Please check and re-run again`);
                                }
                                //loop through xsdg arrays
                                for (let i = 0; i < currentTestData.EXECUTION_SEQUENCE[currentExecutionSequence].XSDGs.length; i++) {
                                    //extract awb number or text from xsdg which is between '001-' and '_'
                                    const xsdg_or_path = currentTestData.EXECUTION_SEQUENCE[currentExecutionSequence].XSDGs[i];

                                    //if xsdg is xml file path, then read the file and get the content of the file as xsdg
                                    let xsdgContent = xsdg_or_path;
                                    if (xsdg_or_path.endsWith('.xml')) {
                                        //handle exception if file is not found or any error in reading file
                                        try {
                                            xsdgContent = fs.readFileSync(xsdg_or_path, 'utf-8');
                                        } catch (error) {
                                            throw new Error(`Error in reading XSDG file at path: ${xsdg_or_path} for TC: ${testCaseId}. Error details: ${error instanceof Error ? (error.stack || error.message) : String(error)}`);
                                        }
                                    }

                                    //store actual xsdg content in xsdgs_actual array
                                    xsdgs_actual.push(xsdgContent);

                                    //replace xsdg awb with regex ${1}, ${2}, etc.
                                    const awbMatch = xsdgContent.match(/<ID>(.*?)_/);
                                    let awb = '';
                                    if (awbMatch && awbMatch[1]) {
                                        //extract awb between - and _
                                        const awbParts = awbMatch[1].split('-');
                                        awb = awbParts.length > 1 ? awbParts[1] : awbParts[0];
                                        //add awb to awbs map with key as xsdg 
                                        // awbsInCurrentSequence[awb] = '${awb' + (i + 1) + '}';
                                        if (!awbsInCurrentTestScenario.hasOwnProperty(awb)) {
                                            //add to awbsInCurrentTestScenario with incremental placeholder value
                                            awbsInCurrentTestScenario[awb] = '${awb' + (Object.keys(awbsInCurrentTestScenario).length + 1) + '}';
                                        }
                                    }
                                    else {
                                        throw new Error(`AWB number not found in XSDG ${(i + 1)} for TC: ${testCaseId}. Please check the XSDG content and re-run again`);
                                    }
                                    //replace all awb with awbsMap value in xsdg
                                    xsdgs_dynamic[i] = xsdgContent.replaceAll(awb, awbsInCurrentTestScenario[awb]);

                                    //if awb is already mapped to ${awb1}, ${awb2}, etc. in awbsInCurrentTestScenario, then use the same placeholder value, 
                                    // else generate new awb and map to new placeholder value in awbsInCurrentTestScenario
                                    if (generatedAwbsMap.hasOwnProperty(awb)) {
                                        xsdgs_generated[i] = xsdgContent.replaceAll(awb, generatedAwbsMap[awb]);
                                    }
                                    else {
                                        //generate random awb number and replace in xsdg, store to xsdg_generated
                                        let generatedAwb = generateAwb();
                                        //execute sql query to check if generated awb is already present in database
                                        //check if all counts are 0, if not generate new awb
                                        let awbExists = true;
                                        let awbCheckAttempt = 0;
                                        while (awbExists) {
                                            const query = dbQueries.AWBS_COUNT.replaceAll('${awb}', generatedAwb);
                                            const result = await executeOracleQuery(query);
                                            awbExists = Object.values(result[0]).some(count => count > 0);
                                            if (awbExists) {
                                                generatedAwb = generateAwb();
                                            }

                                            //fail if generated awb is not unique after 5 attempts to avoid infinite loop
                                            awbCheckAttempt++;
                                            if (awbCheckAttempt >= 5) {
                                                throw new Error(`Generated AWB ${generatedAwb} is not unique after 5 attempts for TC: ${testCaseId}. Please check the AWB generation logic and re-run again`);
                                            }
                                        }
                                        xsdgs_generated[i] = xsdgContent.replaceAll(awb, generatedAwb);
                                        generatedAwbsMap[awb] = generatedAwb;
                                    }

                                    //write generated xsdg to output folder with same xml file name
                                    let xsdgOutputFileName = '';
                                    if (xsdg_or_path.endsWith('.xml')) {
                                        xsdgOutputFileName = path.basename(xsdg_or_path);
                                    }
                                    else {
                                        //if xsdg is not from file, then create a file name using test case id, execution sequence, and xsdg index
                                        xsdgOutputFileName = `TC_${String(testCaseIdCounter).padStart(4, '0')}_Seq_${currentExecutionSequence}_XSDG_${i + 1}.xml`;
                                    }
                                    const outputPath = path.join(xsdgs_generated_folder_path, `${xsdgOutputFileName}`);
                                    try {
                                        //create folder if not exists
                                        if (!fs.existsSync(xsdgs_generated_folder_path)) {
                                            fs.mkdirSync(xsdgs_generated_folder_path, { recursive: true });
                                        }
                                        fs.writeFileSync(outputPath, xsdgs_dynamic[i], 'utf-8');
                                        //get relative path from current working directory and store in xsdgs_dynamic_paths
                                        const relativePath = path.relative(process.cwd(), outputPath);
                                        xsdgs_dynamic_paths[i] = relativePath;
                                    }
                                    catch (error) {
                                        throw new Error(`Error in writing generated XSDG to file at path: ${outputPath} for TC: ${testCaseId}. Error details: ${error instanceof Error ? (error.stack || error.message) : String(error)}`);
                                    }
                                }
                            }
                            currentTestDataEntry.EXECUTION_SEQUENCE[`${currentExecutionSequence}`].XSDGs = xsdgs_dynamic_paths;

                            //NTM
                            let ntm_dynamic = '';
                            let ntm_actual = '';
                            let ntm_generated = '';
                            // if ntm is not null or empty, then replace awbs in ntm with awbsMap value
                            if (currentTestData.EXECUTION_SEQUENCE[currentExecutionSequence].hasOwnProperty('NTM')) {
                                ntm_actual = currentTestData.EXECUTION_SEQUENCE[currentExecutionSequence].NTM;
                                ntm_dynamic = ntm_actual;
                                ntm_generated = ntm_actual;
                                for (const awb in awbsInCurrentTestScenario) {
                                    ntm_dynamic = ntm_dynamic.replaceAll(awb, awbsInCurrentTestScenario[awb]);
                                    ntm_generated = ntm_generated.replaceAll(awb, generatedAwbsMap[awb]);
                                }
                            }
                            currentTestDataEntry.EXECUTION_SEQUENCE[`${currentExecutionSequence}`].NTM = ntm_dynamic;

                            //Replace date placeholder in generated NTM
                            ntm_generated = replaceDatePlaceholders(ntm_generated, timezone);

                            //log generated XSDG and NTM for current execution sequence in allure step
                            await allure.step(`Generated XSDGs and NTM for TC: ${testCaseIdCounter} - Execution Sequence: ${currentExecutionSequence}`, async () => {
                                console.log(`Generated XSDGs for TC: ${testCaseId} - Execution Sequence: ${currentExecutionSequence}: \n${xsdgs_generated.join('\n\n')}`);
                                console.log(`Generated NTM for TC: ${testCaseId} - Execution Sequence: ${currentExecutionSequence}: \n${ntm_generated}`);
                            });

                            //log actual xsdg, dynamic xsdg, and generated xsdg for current execution sequence in allure step for better traceability
                            await allure.step(`Traceability - Actual XSDGs, Dynamic XSDGs, and Generated XSDGs for TC: ${testCaseIdCounter} - Execution Sequence: ${currentExecutionSequence}`, async () => {
                                for (let i = 0; i < xsdgs_actual.length; i++) {
                                    console.log(`Actual XSDG ${(i + 1)} for TC: ${testCaseId} - Execution Sequence: ${currentExecutionSequence}: \n${xsdgs_actual[i]}`);
                                    console.log(`Dynamic XSDG ${(i + 1)} for TC: ${testCaseId} - Execution Sequence: ${currentExecutionSequence}: \n${xsdgs_dynamic[i]}`);
                                    console.log(`Generated XSDG ${(i + 1)} for TC: ${testCaseId} - Execution Sequence: ${currentExecutionSequence}: \n${xsdgs_generated[i]}`);
                                }

                                //add ntm, actual xsdg, dynamic xsdg, and generated xsdg to allure attachment
                                await allure.attachment(`Traceability_XSDGs_ExecutionSequence_${currentExecutionSequence}.txt`, xsdgs_actual.map((xsdg, index) => `Actual XSDG ${(index + 1)}:\n${xsdg}\n\nDynamic XSDG ${(index + 1)}:\n${xsdgs_dynamic[index]}\n\nGenerated XSDG ${(index + 1)}:\n${xsdgs_generated[index]}\n\n`).join('\n'), 'text/plain');
                                await allure.attachment(`Traceability_NTM_ExecutionSequence_${currentExecutionSequence}.txt`, `Actual NTM:\n${ntm_actual}\n\nDynamic NTM:\n${ntm_dynamic}\n\nGenerated NTM:\n${ntm_generated}\n\n`, 'text/plain');

                            });

                            //allure step to Hit XSDGs and NTMs through NOTOC Interface app
                            await allure.step(`AutoNOTOC Interface | Post XSDGs and NTMs for TC: ${testCaseIdCounter} - Execution Sequence: ${currentExecutionSequence}`, async () => {
                                if (notocPage === undefined) {
                                    notocPage = await BrowserHelpers.launchBrowser();
                                }

                                const loginPage = new LoginPage(notocPage);
                                await loginPage.loginToNotocInterfaceApp(getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_USERNAME), getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_PASSWORD));

                                //reload the page multiple times if "Post XSDG Message" link is not found
                                const ntmXsdgMessagesPostingPage = new NtmXsdgMessagesPostingPage(notocPage);
                                await ntmXsdgMessagesPostingPage.refreshPageUntilProperlyLoaded();

                                //post xsdg messages in reverse order as they are extracted
                                await allure.step('Post the XSDG messages to Autonotoc Legacy Interface app', async () => {
                                    await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_XSDG_MESSAGE_HYPERLINK).click();
                                    for (let xsdgsIndex = xsdgs_generated.length - 1; xsdgsIndex >= 0; xsdgsIndex--) {
                                        const xsdgMessage = xsdgs_generated[xsdgsIndex];
                                        await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.XSDG_MESSAGE_TEXTAREA).fill(xsdgMessage, { timeout: TIMEOUTS.LONG });
                                        await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_TO_MQ_BUTTON).click();
                                        await notocPage.waitForTimeout(500);
                                        await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_ONE_MORE_MESSAGE_BUTTON).click({ timeout: TIMEOUTS.LONG });
                                    }
                                });

                                //post ntm message
                                if (ntm_generated && ntm_generated.trim() !== '') {
                                    await allure.step('Post the extracted NTM messages to Autonotoc Legacy Interface app', async () => {
                                        await notocPage.goto(getEnvVariable(ENV_CONFIG_KEYS.URL_AUTONOTOC_LEGACY_INTERFACEAPP_STAGE));
                                        await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_NTM_MESSAGE_HYPERLINK).click();
                                        const ntmMessage = ntm_generated;
                                        await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.NTM_MESSAGE_TEXTAREA).waitFor({ timeout: TIMEOUTS.LONG });
                                        await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.NTM_MESSAGE_TEXTAREA).fill(ntmMessage, { timeout: TIMEOUTS.LONG });
                                        await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_TO_MQ_BUTTON).click();
                                        await notocPage.waitForTimeout(500);
                                        await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_ONE_MORE_MESSAGE_BUTTON).waitFor({ state: 'visible', timeout: TIMEOUTS.LONG });
                                        await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_ONE_MORE_MESSAGE_BUTTON).click();
                                    });
                                }
                                else {
                                    await allure.step('No NTM message to post for this execution sequence', async () => {
                                        console.log(`No NTM message to post for TC: ${testCaseId} - Execution Sequence: ${currentExecutionSequence}`);
                                    });
                                }
                            });

                            //custom delay for ntm processing to happen
                            await new Promise(resolve => setTimeout(resolve, TIMEOUTS.MEDIUM));

                            //TABLES
                            let tables_data_dynamic = {};
                            await allure.step(`QUERY AND STORE TABLES DATA TC: ${testCaseIdCounter} - EXECUTION SEQUENCE: ${currentExecutionSequence}`, async () => {
                                let tables = [];
                                if (currentTestData.EXECUTION_SEQUENCE[currentExecutionSequence].hasOwnProperty('TABLES')) {
                                    //fail if tables map is empty or not in array format
                                    if (Object.keys(currentTestData.EXECUTION_SEQUENCE[currentExecutionSequence].TABLES).length === 0) {
                                        throw new Error(`TABLES map is empty for TC: ${testCaseId}. Please check and re-run again`);
                                    }

                                    //loop through table keys
                                    tables = currentTestData.EXECUTION_SEQUENCE[currentExecutionSequence].TABLES;
                                    let messageid = '';
                                    for (const currentTableKey of Object.keys(tables)) {
                                        //fetch table query from dbqueries.json using currentTableKey, if not found throw error
                                        const tableQueryTemplate = dbQueries[currentTableKey];
                                        if (!tableQueryTemplate) {
                                            throw new Error(`Table query not found for key: ${currentTableKey} in dbqueries.json for TC: ${testCaseId}. Please check and re-run again`);
                                        }

                                        //replace ${awbs} with ('${awb1}', '${awb2}', etc.) in tableQueryTemplate using awbsMap values
                                        let tableQuery = tableQueryTemplate;
                                        if (tableQueryTemplate.includes('${awbs}')) {
                                            const awbsList = Object.values(generatedAwbsMap).map(awb => `'${awb}'`).join(', ');
                                            tableQuery = tableQuery.replaceAll('${awbs}', `(${awbsList})`)
                                        }

                                        if (tableQuery.includes('${ntm_messageid}') && messageid !== '') {
                                            tableQuery = tableQuery.replaceAll('${ntm_messageid}', messageid);
                                        }

                                        //extract flight number from ntm_generated
                                        const match = ntm_generated.match(/AA\s*([0-9]+)/);
                                        const flightNumber = match ? match[1] : null;
                                        tableQuery = tableQuery.replaceAll('${flights}', `('${flightNumber}')`);

                                        //replace date placeholders in tableQuery
                                        tableQuery = replaceDatePlaceholders(tableQuery, timezone);

                                        //execute table query and store result in tables map
                                        let queryResult = [];
                                        try {
                                            queryResult = await executeOracleQuery(tableQuery);
                                            console.log(`Executed query for table ${currentTableKey} for TC: ${testCaseId} - Execution Sequence: ${currentExecutionSequence}. Query: ${tableQuery}. Result: ${JSON.stringify(queryResult)}`);
                                        } catch (error) {
                                            throw new Error(`Error in executing query for table ${currentTableKey} for TC: ${testCaseId} - Execution Sequence: ${currentExecutionSequence}. Query: ${tableQuery}. Error details: ${error instanceof Error ? (error.stack || error.message) : String(error)}`);
                                        }
                                        //if queryResult contains MESSAGEID column, store the value as messageid
                                        if (messageid.length === 0 && queryResult.length > 0 && (queryResult[0].hasOwnProperty('MESSAGEID') || queryResult[0].hasOwnProperty('messageid'))) {
                                            messageid = queryResult[0].MESSAGEID || queryResult[0].messageid;
                                        }

                                        //replace all messageid column values in queryResult with ${ntm_messageid}
                                        if (queryResult.length > 0 && (queryResult[0].hasOwnProperty('MESSAGEID') || queryResult[0].hasOwnProperty('messageid'))) {
                                            queryResult.forEach(row => {
                                                if (queryResult[0].hasOwnProperty('MESSAGEID'))
                                                    row.MESSAGEID = '${ntm_messageid}';
                                                else if (queryResult[0].hasOwnProperty('messageid'))
                                                    row.messageid = '${ntm_messageid}';
                                            });
                                        }

                                        //loop through queryResult array of map across all keys, replace dates with ${date|format|offset}
                                        for (const row of queryResult) {
                                            for (const key of Object.keys(row)) {
                                                //if value is date, then convert to ISO string and replace with ${date_key}
                                                if (typeof row[key] === 'string') {
                                                    //check if date is MM/dd/YYYY or ddMMM or MMddYYYYHHmmss format
                                                    if (isMatchingDateFormat(row[key], 'MM/dd/YYYY')) {
                                                        //get date difference in days between current date and dateValue
                                                        const currentDate = new Date();
                                                        const dateValue = parse_MMddYYYY(row[key]);
                                                        const timeDiff = dateValue.getTime() - currentDate.getTime();
                                                        const dayDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
                                                        row[key] = `\${date|MM/dd/YYYY|${dayDiff}}`;
                                                    }
                                                    else if (isMatchingDateFormat(row[key], 'ddMMM')) {
                                                        //get days difference between current date and dateValue
                                                        const currentDate = new Date();
                                                        const dateValue = parse_ddMMM(row[key]);
                                                        const timeDiff = dateValue.getTime() - currentDate.getTime();
                                                        const dayDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
                                                        row[key] = `\${date|ddMMM|${dayDiff}}`;
                                                    }
                                                    else if (isMatchingDateFormat(row[key], 'YYYYMMddHHmmss')) {
                                                        row[key] = getDateWithOffset('YYYYMMddHHmmss', 0, timezone);
                                                    }
                                                }
                                            }
                                        }

                                        //loop through queryResult and convert all awb numbers to awb placeholders, trim values
                                        queryResult.forEach(row => {
                                            for (const key of Object.keys(row)) {
                                                // Trim string values
                                                if (typeof row[key] === 'string') {
                                                    row[key] = row[key].trim();
                                                }
                                                // Replace AWB numbers with placeholders
                                                for (const awb in generatedAwbsMap) {
                                                    if (row[key] === generatedAwbsMap[awb]) {
                                                        row[key] = awbsInCurrentTestScenario[awb];
                                                    }
                                                }
                                            }
                                        });

                                        tables_data_dynamic[currentTableKey] = queryResult;
                                        currentTestDataEntry.EXECUTION_SEQUENCE[`${currentExecutionSequence}`].TABLES = tables_data_dynamic;
                                    }
                                    console.log(`Current Execution Sequence: ${currentExecutionSequence}. CurrentTestDataEntry for TC: ${testCaseId}`);
                                    console.log(`Current Test data entry: \n${JSON.stringify(currentTestDataEntry, null, 2)}`);
                                }
                                else {
                                    throw new Error(`TABLES key is missing in execution sequence ${currentExecutionSequence} for TC: ${testCaseId}. Please check and re-run again`);
                                }
                            });
                        }
                    });
                    console.log(`DONE! ${testCaseId}`);
                    return currentTestDataEntry;
                } catch (error) {
                    const errorDetails = error instanceof Error ? (error.stack || error.message) : String(error);
                    console.error(`ERROR in ${testCaseId}. Continuing to next test data.`, errorDetails);
                    return null;
                }
            }));

            generatedTestDataEntries.push(...currentBatchEntries);
        }

        finalTestData = generatedTestDataEntries
            .filter(entry => entry !== null)
            .sort((a, b) => a.S_NO - b.S_NO);

        //write finalTestData to output json file
        const outputFilePath = path.join(process.cwd(), FILE_PATHS.NTM_PROCESSING_TEST_DATA_OUTPUT);
        fs.writeFileSync(outputFilePath, JSON.stringify(finalTestData, null, 2));

        await allure.step('Close the browser', async () => {
            const browser = notocPage.context().browser();
            await browser.close();
        });
    });
});
