import { test, expect, chromium } from '@playwright/test';
import { FILE_PATHS } from '../../../utils/constants/Constants.js';
import { normalizeArrayDict, readJsonFile } from '../../../utils/helpers/JsonUtils.js';
import * as allure from 'allure-js-commons';
import path from 'path';
import { getEnvVariable } from '../../../utils/config/EnvLoader.js';
import { ENV_CONFIG_KEYS, DEFAULTS } from '../../../utils/constants/Constants.js';
import { executeQuery } from '../../../utils/helpers/database.js';
import { TIMEOUTS } from '../../../utils/constants/Constants.js';
import { generateAwb } from '../../../utils/helpers/awbUtils.js';
import { replaceDatePlaceholders } from '../../../utils/helpers/DateUtils.js';
import fs from 'fs';
import { BrowserHelpers } from '../../../utils/helpers/BrowserHelpers.js';
import { LoginPage } from '../../../pages/ui/notoc_legacy/LoginPage.js';
import { NtmXsdgMessagesPostingPage, NTM_XSDG_MESSAGES_POSTING_PAGE } from '../../../pages/ui/notoc_legacy/NtmXsdgMessagesPostingPage.js';


import util from "node:util";
util.inspect.defaultOptions.maxStringLength = null;

//flags
// Set this flag to true if you want to post XSDGs and NTM through AutoNOTOC Interface Web Application 
const executeThroughWebInterfaceApp = true;
const convertNullToBlankInNormalization = true; // Set this flag to true if you want to convert null values to blank during validation
const iCargoInterfaceRetryCount = 3; // Number of times to retry finding element and reloading page in case of failure in AutoNOTOC Interface app
const ignoreKeyFieldsDuringValidation = ['messageid', 'packinggroup', 'displayedpackinggroup']; // List of key fields to ignore during data validation in tables

// Load Test Data
const dataFilePath = path.join(process.cwd(), FILE_PATHS.NTM_PROCESSING_TEST_DATA_OUTPUT);
const testData = readJsonFile(dataFilePath);
const timezone = getEnvVariable(DEFAULTS.DEFAULT_TIMEZONE) || 'Asia/Kolkata'; // Default to IST timezone if not set in env variables
const dbQueriesFilePath = path.join(process.cwd(), FILE_PATHS.DB_QUERIES);
const dbQueries = readJsonFile(dbQueriesFilePath);

//API URL and Endpoints
const apiBaseUrl = getEnvVariable(ENV_CONFIG_KEYS.URL_ICARGO);
const apiProcessEndpoint = getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_NOTOC_TRIGGER);
const apiProcessContentType = getEnvVariable(ENV_CONFIG_KEYS.API_ENDPOINT_NOTOC_HEADER_CONTENT_TYPE);

test.describe('iCargo - NTM Processing Validation Tests', () => {
    //Loop through each test case in the test data
    for (const currentTestData of testData) {
        //Store data for each test case
        const scenarioTitle = currentTestData.SCENARIO_TITLE;
        const testCaseId = currentTestData.TEST_CASE_ID;
        const executionSequence = currentTestData.EXECUTION_SEQUENCE;

        test(`[${testCaseId}] iCargo NTM Processing Test for: ${scenarioTitle}`, { tag: ['@sanity', '@regression'] }, async ({ request }) => {
            //Variables
            let awbs_sequence_list = {};
            let notocPage;
            // Allure annotations
            await allure.description(`Testing NTM Processing API with scenario: ${scenarioTitle}`);
            await allure.severity('critical');
            await allure.label('@sanity', '@regression');
            await allure.owner('QA Team');
            await allure.displayName(`${testCaseId} - ${scenarioTitle}`);

            // Allure - Add test data as attachment
            // await allure.attachment('Test Data - NTM', ntm, 'text/plain');
            await allure.parameter('Base URL', apiBaseUrl);
            await allure.parameter('Endpoint', apiProcessEndpoint);
            await allure.parameter('Content Type', apiProcessContentType);
            await allure.parameter('Scenario', scenarioTitle);

            //loop through the executionSequences map, execute each sequence one by one and validate results
            for (const currentExecutionSequence of Object.keys(executionSequence)) {
                await allure.step(`EXECUTION SEQUENCE: ${currentExecutionSequence}`, async () => {
                    //store values
                    let xsdgs = executionSequence[currentExecutionSequence].XSDGs;
                    let ntm = executionSequence[currentExecutionSequence].NTM;
                    let tables = executionSequence[currentExecutionSequence].TABLES;
                    let currentSequenceXSDGsList = [];

                    console.log(`XSDGs for current execution sequence: ${JSON.stringify(xsdgs)}`);
                    console.log(`Normal XSDGs for current execution sequence: ${xsdgs}`);
                    console.log(`NTM: ${ntm}`);

                    // Hit XSDGs to trigger API
                    // Add as allure step mentioning the number of XSDGs being hit in the current execution sequence
                    await allure.step(`Generating AWB's for XSDG's - Total XSDGs: ${xsdgs.length}`, async () => {
                        for (let currentXSDG of xsdgs) {
                            let randomAwbNumber;
                            //check if XSDG is file path or actual content, if it is file path read the content of the file
                            if (currentXSDG.endsWith('.xml')) {
                                const xsdgFilePath = path.join(process.cwd(), currentXSDG);
                                currentXSDG = fs.readFileSync(xsdgFilePath, 'utf-8');
                            }

                            //firstly check if the xsdg has placeholder
                            if (currentXSDG.includes('\${awb')) {
                                //Get the AWB number index
                                const awbIndex = currentXSDG.match(/\${awb(\d+)}/)[1];

                                //check if the AWB number for the index is already generated in current execution sequence, if yes use it else generate a new one and store in map
                                if (awbs_sequence_list[`\${awb${awbIndex}}`]) {
                                    randomAwbNumber = awbs_sequence_list[`\${awb${awbIndex}}`];
                                } else {
                                    randomAwbNumber = generateAwb();
                                    awbs_sequence_list[`\${awb${awbIndex}}`] = randomAwbNumber;
                                }

                                //replaceAll the placeholder in xsdg with the generated AWB number
                                currentXSDG = currentXSDG.replaceAll(`\${awb${awbIndex}}`, randomAwbNumber);
                                currentSequenceXSDGsList.push(currentXSDG);
                            }
                        }

                        //log to allure the list of AWBs and XSDGs generated in the current execution sequence
                        await allure.attachment(`AWBs generated in Execution Sequence ${currentExecutionSequence}`, JSON.stringify(awbs_sequence_list, null, 2), 'application/json');
                        await allure.attachment(`XSDGs generated in Execution Sequence ${currentExecutionSequence}`, JSON.stringify(currentSequenceXSDGsList, null, 2), 'application/json');
                    });

                    await allure.step(`Generating NTM for Execution Sequence: ${currentExecutionSequence}`, async () => {
                        // NTM - replace AWB placeholders with generated AWB numbers
                        for (const awbIndex of Object.keys(awbs_sequence_list)) {
                            ntm = ntm.replaceAll(awbIndex, awbs_sequence_list[awbIndex]);
                        }

                        //Replace date in ntm with current date in required format if there is any placeholder for date, assuming the placeholder is ${date} and the required format is YYYY-MM-DD, you can adjust the regex and date formatting logic as per your actual placeholders and required formats
                        //Look for format ${date|dateformat|offset} in ntm and replace with current date with offset in the required dateformat, where offset is optional and can be used to get date with offset from current date like ${date|YYYY-MM-DD|+2} will give date after 2 days from current date in YYYY-MM-DD format
                        ntm = replaceDatePlaceholders(ntm, timezone);
                    });

                    // Allure - Add execution sequence data as attachments
                    await allure.attachment(`Execution Sequence - ${currentExecutionSequence} - NTM`, ntm, 'text/plain');
                    await allure.attachment(`Execution Sequence - ${currentExecutionSequence} - XSDGs`, JSON.stringify(currentSequenceXSDGsList, null, 2), 'application/json');

                    //add ntm, actual xsdg, dynamic xsdg, and generated xsdg to allure attachment
                    await allure.attachment(`Traceability_XSDGs_ExecutionSequence_${currentExecutionSequence}.txt`, currentSequenceXSDGsList.map((xsdg, index) => `XSDG ${(index + 1)}:\n${xsdg}\n\n`).join('\n'), 'text/plain');
                    await allure.attachment(`Traceability_NTM_ExecutionSequence_${currentExecutionSequence}.txt`, `NTM:\n${ntm}\n\n`, 'text/plain');
                    await allure.attachment(`Execution Sequence - ${currentExecutionSequence} - TABLES`, JSON.stringify(tables, null, 2), 'application/json');

                    //Hit NTM to trigger API and log to allure
                    notocPage = await postXsdgsAndNtmUsingInterfaceAppOrAPI(notocPage, executeThroughWebInterfaceApp, request, currentSequenceXSDGsList, ntm, testCaseId, currentExecutionSequence); // Post XSDG and NTM through NOTOC Interface app for better traceability in logs and to avoid any issues with hitting API directly

                    //custom delay for ntm processing to happen
                    await new Promise(resolve => setTimeout(resolve, TIMEOUTS.MEDIUM));

                    //set all awbs to into db query format for querying in tables
                    let awbs = '(' + Object.values(awbs_sequence_list).map(awb => `'${awb}'`).join(', ') + ')';
                    let ntmMessageId;
                    let xsdgMessageId;

                    //Validate data in Tables
                    //loop through each table keys in the current execution sequence and validate data
                    await allure.step(`Validate data in tables for Execution Sequence: ${currentExecutionSequence}`, async () => {
                        ntmMessageId = ''; //reset ntmMessageId before validating tables for current execution sequence, so that messageid from previous execution sequence is not used in current execution sequence validations
                        for (const currentTable of Object.keys(tables)) {
                            await allure.step(`${currentTable}`, async () => {
                                //fetch tableQuery from dbConfig using currentTable keywhich 
                                let tableQuery = dbQueries[currentTable];
                                if (!tableQuery) {
                                    throw new Error(`DB query details not found for table: ${currentTable} in DB_QUERIES.json. Please check the DB_QUERIES.json file and add the details for ${currentTable}`);
                                }
                                let tableData = tables[currentTable];

                                //loop through each awbs generated in the current execution sequence and replaceAll in query
                                for (const currentAwbIndex of Object.keys(awbs_sequence_list)) {
                                    console.log(`Current Table: ${currentTable}, Query before replacing AWB placeholder: ${tableQuery}`);
                                    //replace tableData json with awb numbers (awb1, awb2, awb3...) if there are any placeholders
                                    //loop through tableData array
                                    for (let i = 0; i < tableData.length; i++) {
                                        //loop through each key of the object and replace value if it matches with any awb placeholder
                                        for (const key of Object.keys(tableData[i])) {
                                            if (typeof tableData[i][key] === 'string') {
                                                //loop through awbSequenceList and replace all placeholders in the tableData with actual awb numbers
                                                tableData[i][key] = tableData[i][key].replaceAll(currentAwbIndex, awbs_sequence_list[currentAwbIndex]);
                                            }
                                        }
                                    }
                                }
                                //replace query ntm and xsdg messageid placeholders with actual values if they are already stored from previous table validations
                                tableQuery = tableQuery.replaceAll("${ntm_messageid}", ntmMessageId ? ntmMessageId : '${ntm_messageid}').replaceAll("${xsdg_messageid}", xsdgMessageId ? xsdgMessageId : '${xsdg_messageid}');
                                //replace date placeholders in table query and data with current date in required format if there is any placeholder for date, assuming the placeholder is ${date} and the required format is YYYY-MM-DD, you can adjust the regex and date formatting logic as per your actual placeholders and required formats
                                tableQuery = replaceDatePlaceholders(tableQuery, timezone);
                                tableData = replaceDatePlaceholders(tableData, timezone);
                                //replace ${awbs} placeholder in query with actual awb numbers in db query format for IN clause
                                tableQuery = tableQuery.replaceAll('${awbs}', awbs);
                                //extract flight number from ntm_generated and replace in query
                                const match = ntm.match(/AA\s*([0-9]+)/);
                                const flightNumber = match ? match[1] : null;
                                tableQuery = tableQuery.replaceAll('${flights}', `('${flightNumber}')`);

                                //execute DB query and get actual results - placeholder for actual DB call
                                //handle exception if query execution fails and log the error in allure and continue with next tables, so that even if validation for one table fails, it continues with other tables and logs all failures in the end
                                let tableQueryResult;
                                try {
                                    tableQueryResult = await executeQuery(tableQuery, 3, TIMEOUTS.V_SHORT);
                                }
                                catch (error) {
                                    console.error(`Error executing query for table ${currentTable}: ${error.message}`);
                                    await allure.step(`Error executing query for table ${currentTable}: ${error.message}`, async () => {
                                        await allure.attachment('Query', tableQuery, 'text/plain');
                                        await allure.attachment('Error Message', error.message, 'text/plain');
                                    });
                                    return; // Use return instead of continue to exit the allure.step callback
                                }
                                console.log(`Query Result of table ${currentTable}:`, tableQueryResult);
                                //if table query result contains messageid or message_id, store the value in a variable and replace in other table queries and data where there are placeholders, so that we can validate the messageid in all tables where it is present and store only if ntmMessageId in not already stored from previous tables, because messageid value in not initialized
                                if (currentTable.toLowerCase().includes('ntm') && tableQueryResult.length > 0 && (tableQueryResult[0].MESSAGEID || tableQueryResult[0].MESSAGE_ID || tableQueryResult[0].messageid || tableQueryResult[0].message_id) && !ntmMessageId) {
                                    ntmMessageId = tableQueryResult[0].MESSAGEID || tableQueryResult[0].MESSAGE_ID || tableQueryResult[0].messageid || tableQueryResult[0].message_id;
                                }
                                if (currentTable.toLowerCase().includes('xsdg') && tableQueryResult.length > 0 && (tableQueryResult[0].MESSAGEID || tableQueryResult[0].MESSAGE_ID || tableQueryResult[0].messageid || tableQueryResult[0].message_id) && !xsdgMessageId) {
                                    xsdgMessageId = tableQueryResult[0].MESSAGEID || tableQueryResult[0].MESSAGE_ID || tableQueryResult[0].messageid || tableQueryResult[0].message_id;
                                }
                                tableData = JSON.parse(JSON.stringify(tableData).replaceAll(new RegExp(`\\\${ntm_messageid}`, 'g'), ntmMessageId).replaceAll(new RegExp(`\\\${xsdg_messageid}`, 'g'), xsdgMessageId));
                                //validate actual results with expected data - placeholder for actual validation logic
                                const normalizedTableQueryResult = await normalizeArrayDict(tableQueryResult, ignoreKeyFieldsDuringValidation, convertNullToBlankInNormalization);
                                const normalizedExpectedData = await normalizeArrayDict(tableData, ignoreKeyFieldsDuringValidation, convertNullToBlankInNormalization);
                                //Add allure step mentioning the table name being validated
                                await allure.step(`Validating data for table: ${currentTable}`, async () => {
                                    //Soft assertion to compare actual and expected data, so that even if validation fails for one table, it continues with other tables and logs all failures in the end
                                    expect.soft(normalizedTableQueryResult, `Data mismatch found in table: ${currentTable}`).toEqual(normalizedExpectedData);
                                    //attach actual and expected data in allure for better debugging in case of failure
                                    await allure.attachment(`Actual Data - ${currentTable}`, JSON.stringify(normalizedTableQueryResult, null, 2), 'application/json');
                                    await allure.attachment(`Expected Data - ${currentTable}`, JSON.stringify(normalizedExpectedData, null, 2), 'application/json');
                                });
                            });
                        }
                    });
                });
            }
        });
    }
});

//Write method to launch browser
async function postXsdgsAndNtmUsingInterfaceAppOrAPI(notocPage, throughInterfaceApp, request, xsdgs_generated, ntm_generated, testCaseId, currentExecutionSequence) {
    if (throughInterfaceApp) {
        //allure step to Hit XSDGs and NTMs through NOTOC Interface app
        await allure.step(`AutoNOTOC Interface Web Application | Post XSDGs and NTMs for Execution Sequence: ${currentExecutionSequence}`, async () => {
            if (notocPage === undefined) {
                notocPage = await BrowserHelpers.launchBrowser();
            }
            await allure.step(`Launch AutoNOTOC Legacy Interface App`, async () => {
                const loginPage = new LoginPage(notocPage);
                await loginPage.loginToNotocInterfaceApp(getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_USERNAME), getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_PASSWORD));

                //reload the page multiple times if "Post XSDG Message" link is not found
                const ntmXsdgMessagesPostingPage = new NtmXsdgMessagesPostingPage(notocPage);
                await ntmXsdgMessagesPostingPage.refreshPageUntilProperlyLoaded();
            });

            //post xsdg messages in reverse order as they are extracted
            await allure.step('Post the XSDG messages to Autonotoc Legacy Interface app', async () => {
                await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_XSDG_MESSAGE_HYPERLINK).click();
                for (let xsdgsIndex = xsdgs_generated.length - 1; xsdgsIndex >= 0; xsdgsIndex--) {
                    const xsdgMessage = xsdgs_generated[xsdgsIndex];
                    await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.XSDG_MESSAGE_TEXTAREA).fill(xsdgMessage, { timeout: TIMEOUTS.LONG });
                    await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_TO_MQ_BUTTON).click();
                    await notocPage.waitForTimeout(500);
                    await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_ONE_MORE_MESSAGE_BUTTON).click({ timeout: TIMEOUTS.LONG });
                }
            });

            //post ntm messages in reverse order as they are extracted
            await allure.step('Post the extracted NTM messages to Autonotoc Legacy Interface app', async () => {
                await notocPage.goto(getEnvVariable(ENV_CONFIG_KEYS.URL_AUTONOTOC_LEGACY_INTERFACEAPP_STAGE));
                await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_NTM_MESSAGE_HYPERLINK).click();
                const ntmMessage = ntm_generated;
                await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.NTM_MESSAGE_TEXTAREA).waitFor({ timeout: TIMEOUTS.LONG });
                await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.NTM_MESSAGE_TEXTAREA).fill(ntmMessage, { timeout: TIMEOUTS.LONG });
                await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_TO_MQ_BUTTON).click();
                await notocPage.waitForTimeout(500);
                await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_ONE_MORE_MESSAGE_BUTTON).waitFor({ state: 'visible', timeout: TIMEOUTS.LONG });
                await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_ONE_MORE_MESSAGE_BUTTON).click();
            });
        });
    }
    if (!throughInterfaceApp || getEnvVariable('ENV') != 'nonprod') {
        // Log request details for XSDG hits and log xsdg index for better traceability
        await allure.step(`Send POST request to Process Trigger API for XSDGs`, async () => {
            await allure.attachment('Request URL', `${apiBaseUrl}${apiProcessEndpoint}`, 'text/plain');
            await allure.attachment('Request Headers', JSON.stringify({ 'Content-Type': apiProcessContentType }, null, 2), 'application/json');
            //loop through each xsdg and hit the API to trigger the process and log to allure
            for (let i = 0; i < xsdgs_generated.length; i++) {
                let currentXSDG = xsdgs_generated[i];
                let response = await request.post(`${apiBaseUrl}${apiProcessEndpoint}`, {
                    headers: { 'Content-Type': apiProcessContentType },
                    data: currentXSDG
                });
                await allure.attachment('Request Body', currentXSDG, 'text/plain');
                const responseStatus = await response.status();
                const responseBody = await response.body();
                await allure.attachment(`Response for XSDG ${(i + 1)}`, `Status: ${responseStatus}\nBody: ${responseBody}`, 'text/plain');
            }
        });

        await allure.step(`Send POST request to Process Trigger API for NTM`, async () => {
            await allure.attachment('Request URL', `${apiBaseUrl}${apiProcessEndpoint}`, 'text/plain');
            await allure.attachment('Request Headers', JSON.stringify({ 'Content-Type': apiProcessContentType }, null, 2), 'application/json');
            let ntm = ntm_generated;
            //Hit NTM if NTM is not blank
            if (ntm && ntm.trim() != '') {
                // Hit NTM to trigger API
                let response = await request.post(`${apiBaseUrl}${apiProcessEndpoint}`, {
                    headers: { 'Content-Type': apiProcessContentType },
                    data: ntm
                });

                // Log request details for NTM hit
                await allure.step(`Send POST request to Process Trigger API for NTM`, async () => {
                    await allure.attachment('Request Body', ntm, 'text/plain');
                    await allure.attachment('Response', `Status: ${response.status()}\nBody: ${response.body()}`, 'text/plain');
                });
            } else {
                console.warn(`NTM is blank for execution sequence ${currentExecutionSequence}, skipping NTM hit and table validations`);
                await allure.step(`NTM is blank, skipping NTM hit and table validations for execution sequence ${currentExecutionSequence}`, async () => { });
            }
        });
    }
    return notocPage;
}
