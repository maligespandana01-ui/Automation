import { test, expect } from '@playwright/test';
import fs from 'fs';
import { executeQuery, executeOracleQuery } from '../../../utils/helpers/database.js';
import { FILE_PATHS, ENV_CONFIG_KEYS, TIMEOUTS, } from '../../../utils/constants/Constants.js';
import { getEnvVariable } from '../../../utils/config/EnvLoader.js';
import * as allure from 'allure-js-commons';
import { ICargoLoginPage } from '../../../pages/ui/icargo/ICargoLoginPage.js';
import { BrowserHelpers } from '../../../utils/helpers/BrowserHelpers.js';
import { ICargoSearchPage } from '../../../pages/ui/icargo/ICargoSearchPage.js';
import { MSG005ListMessagesPage, MSG005_LIST_MESSAGES_PAGE } from '../../../pages/ui/icargo/MSG005ListMessagesPage.js';
import { OPR352AwbEnquiryPage, OPR352_AWB_ENQUIRY_PAGE } from '../../../pages/ui/icargo/OPR352AwbEnquiryPage.js';
import { LoginPage } from '../../../pages/ui/notoc_legacy/LoginPage.js';
import { NtmXsdgMessagesPostingPage, NTM_XSDG_MESSAGES_POSTING_PAGE } from '../../../pages/ui/notoc_legacy/NtmXsdgMessagesPostingPage.js';
import path from 'path';
import { replaceDatePlaceholders } from '../../../utils/helpers/DateUtils.js';
import { normalizeArrayDict } from '../../../utils/helpers/JsonUtils.js';
import { diff } from 'deep-diff';


//
const ntmsCountToExtract = 10;
const skipNilNtmFlag = true; // Set to true to skip NTM messages containing 'NIL', false to include them in the extraction
const convertNullToBlankInNormalization = true;
const ignoreKeyFieldsDuringValidation = ['aioboxcount', 'displayedpackinggroup', 'opboxcount', 'notocdisplaysort', 'ID', 'CREATED_AT', 'UPDATED_AT', 'MESSAGE_ID', 'CORRELATION_ID', 'MESSAGEID', 'packinggroup']; // List of key fields to ignore during validation as they can have different values in each run

/* ==================== LOAD QUERIES FILE FOR THIS CURRENT TEST SCENARIOS ==================== */
const QUERIES = JSON.parse(fs.readFileSync(`${process.cwd()}/${FILE_PATHS.DB_QUERIES}`, 'utf-8'));

const dbQueriesFilePath = path.join(process.cwd(), FILE_PATHS.DB_QUERIES);
const dbQueries = JSON.parse(fs.readFileSync(dbQueriesFilePath, 'utf-8'));

//Test data
let flightsList = new Set(); // list of unique flights extracted from NTM messages in iCargo
let awbsList = new Set(); // list of unique AWBs extracted from NTM messages in iCargo
let ntmsList = []; // To store NTM messages extracted from iCargo for validation in the test
let xsdgList = []; // To store XSDG messages extracted from iCargo for validation in the test and posting to Autonotoc Legacy Interface app

//tables list
let tables = ["AUDIT_XSDG_MESSAGES", "AUDIT_NTM_MESSAGES", "AUDIT_NTM_MESSAGES_FNA_FMA_FLIGHT", "XSDG_SC", "XSDG_SI", "XSDG_SRN", "NTM_SFI", "NTM_UA", "SHIPPERCHECKLIST", "SHIPPERFLIGHTINFORMATION", "SHIPPERINFORMATION", "UNITASSIGN", "RL_NOTIFICATION_SENT", "EDIT_CHANGE_HISTORY"];

test.describe.serial('NOTOC NTM Processing validations', () => {
    test("iCargo Login - Capture XSDG's and NTM's", async () => {
        await allure.step('Launch the browser and login to iCargo to capture NTM and XSDG messages for the AWBs extracted from NTM messages', async () => {
        });

        const page = await BrowserHelpers.launchBrowser();

        //login page
        const iCargoLoginPage = new ICargoLoginPage(page);
        const iCargoPopupWindow = await iCargoLoginPage.loginToICargo(getEnvVariable(ENV_CONFIG_KEYS.ICARGO_USERNAME), getEnvVariable(ENV_CONFIG_KEYS.ICARGO_PASSWORD));

        //search
        const iCargoSearchPage = new ICargoSearchPage(iCargoPopupWindow);
        await iCargoSearchPage.searchAndNavigateToScreen('MSG005 - List Messages');

        //loop through all the messages and extract NTM messages
        await allure.step('Extract NTM messages and corresponding flight and AWB numbers from MSG005 screen', async () => {
            //msg005 screen apply NTM filter
            const listMessagesMSG005Page = new MSG005ListMessagesPage(iCargoPopupWindow);
            await listMessagesMSG005Page.typeTextIntoInputField(MSG005_LIST_MESSAGES_PAGE.MESSAGE_TYPE, 'NTM');
            await listMessagesMSG005Page.selectOptionFromDropdown(MSG005_LIST_MESSAGES_PAGE.INTERFACE_SYSTEM_DROPDOWN, 'AUTO NOTOC');
            await listMessagesMSG005Page.clickOnElement(MSG005_LIST_MESSAGES_PAGE.LIST_BUTTON);

            while (flightsList.size < ntmsCountToExtract) {
                //wait for messages list
                await new Promise(resolve => setTimeout(resolve, TIMEOUTS.V_SHORT));
                await listMessagesMSG005Page.waitForElementToBeVisible(MSG005_LIST_MESSAGES_PAGE.MESSAGES_LIST_ROWS);
                await listMessagesMSG005Page.clickOnElement(MSG005_LIST_MESSAGES_PAGE.SELECT_ALL_CHECKBOX);
                await listMessagesMSG005Page.clickOnElement(MSG005_LIST_MESSAGES_PAGE.VIEW_LIST_MESSAGES_BUTTON);
                //wait for popup to open
                await listMessagesMSG005Page.popupWaitForElementToBeVisible(MSG005_LIST_MESSAGES_PAGE.POPUP_CONTAINER_FRAME_TEXTAREA);
                //loop thorugh pagination in popup and extract ntm messages until required count is extracted
                while (await listMessagesMSG005Page.popupGetElementVisibilityStatus(MSG005_LIST_MESSAGES_PAGE.POPUP_CONTAINER_FRAME_NEXT_BUTTON)) {
                    //extract ntm messages from the opened popup
                    const ntmMessage = await listMessagesMSG005Page.popupGetTextAreaValue(MSG005_LIST_MESSAGES_PAGE.POPUP_CONTAINER_FRAME_TEXTAREA);

                    //skip nil ntm messages if flag is set
                    if (skipNilNtmFlag && ntmMessage.includes('NIL')) {
                        //add delay
                        await new Promise(resolve => setTimeout(resolve, 500));
                        //click on next button in the popup
                        if (await listMessagesMSG005Page.popupGetElementVisibilityStatus(MSG005_LIST_MESSAGES_PAGE.POPUP_CONTAINER_FRAME_NEXT_BUTTON))
                            await listMessagesMSG005Page.popupClickOnElement(MSG005_LIST_MESSAGES_PAGE.POPUP_CONTAINER_FRAME_NEXT_BUTTON);
                        continue;
                    }

                    //extract flight numbers from ntm message and store in the set
                    const flightNum = ntmMessage.split('AA')[1].substring(0, 4).trim();
                    flightsList.add(flightNum);

                    //extract awb numbers from ntm message and store in the set
                    const ntmLines = ntmMessage.split('\n');
                    ntmLines.forEach(line => {
                        if (line.startsWith('001')) {
                            const awbNum = line.split(' ')[0].split('-')[1].trim();
                            awbsList.add(awbNum.substring(0, 8)); // Extract the first 8 characters of the AWB number and store in the set
                        }
                    });

                    //add ntm to ntmsList
                    ntmsList.push(ntmMessage);

                    //add delay
                    await new Promise(resolve => setTimeout(resolve, 500));
                    //click on next button in the popup
                    if (await listMessagesMSG005Page.popupGetElementVisibilityStatus(MSG005_LIST_MESSAGES_PAGE.POPUP_CONTAINER_FRAME_NEXT_BUTTON))
                        await listMessagesMSG005Page.popupClickOnElement(MSG005_LIST_MESSAGES_PAGE.POPUP_CONTAINER_FRAME_NEXT_BUTTON);
                }

                //close the popup after extracting messages from all pages
                await listMessagesMSG005Page.popupClickOnElement(MSG005_LIST_MESSAGES_PAGE.POPUP_CONTAINER_FRAME_CLOSE_BUTTON);
                //click on next button
                await listMessagesMSG005Page.clickOnElement(MSG005_LIST_MESSAGES_PAGE.POPUP_CONTAINER_FRAME_NEXT_BUTTON);
            }

            if (awbsList.size === 0) {
                console.log('No AWB numbers found in the NTM messages. Ending the test.');
                return;
            }
        });

        //refresh page
        await allure.step('Refresh the page', async () => {
            await page.goto(page.url(), { waitUntil: 'domcontentloaded', timeout: 2000 });
            //hard delay for 2 seconds
            await new Promise(resolve => setTimeout(resolve, TIMEOUTS.V_SHORT));
            //wait for page to be loaded fully
            await page.waitForLoadState('networkidle', { timeout: TIMEOUTS.LONG });
        });

        await allure.step('Search for the extracted AWB numbers in OPR352 screen and extract XSDG messages', async () => {
            //navigate to opr352 screen and search for the AWB numbers extracted from NTM messages
            await iCargoSearchPage.searchAndNavigateToScreen('OPR352 - AWB Enquiry Screen');

            //loop through all awb numbers extracted from ntm messages and search in opr352 screen and extract xsdg message
            const opr352Page = new OPR352AwbEnquiryPage(iCargoPopupWindow);
            for (let awbIndex = 0; awbIndex < awbsList.size; awbIndex++) {
                const awbNum = Array.from(awbsList)[awbIndex];
                console.log(`Searching for AWB Number: ${awbNum} in OPR352 Screen`);

                //search awb in opr352 screen
                //hard delay for 2 seconds
                await new Promise(resolve => setTimeout(resolve, 500));
                await opr352Page.waitForElementToBeVisible(OPR352_AWB_ENQUIRY_PAGE.AWB_INPUT_FIELD);
                //add delay
                await opr352Page.typeTextIntoInputField(OPR352_AWB_ENQUIRY_PAGE.AWB_INPUT_FIELD, awbNum);
                await opr352Page.clickOnElement(OPR352_AWB_ENQUIRY_PAGE.LIST_AWB_BUTTON);
                //open messages list
                await opr352Page.clickOnElement(OPR352_AWB_ENQUIRY_PAGE.THREE_DOT_MESSAGES_BUTTON);

                //expand XSDG messages accordion
                const xsdgAccordions = await opr352Page.getElements(OPR352_AWB_ENQUIRY_PAGE.XSDG_MESSAGES_EXPANDER);
                //loop through messages accordion and expand XSDG messages accordion
                for (let xsdgAccordionIndex = 1; xsdgAccordionIndex <= await xsdgAccordions.count(); xsdgAccordionIndex++) {
                    const xsdgAccordionExpanderElement = xsdgAccordions.nth(xsdgAccordionIndex - 1);
                    //click on xsdg expander
                    await opr352Page.clickOnElement(xsdgAccordionExpanderElement);
                    //xsdgs messages elements under the expanded accordion
                    const xsdgMessagesElements = await xsdgAccordionExpanderElement.locator(OPR352_AWB_ENQUIRY_PAGE.XSDG_MESSAGES_FIELDS);
                    //loop through all messages under xsdg accordion and extract the message which contains xml in it
                    for (let xsdgMessageIndex = 1; xsdgMessageIndex <= await xsdgMessagesElements.count(); xsdgMessageIndex++) {
                        const xsdgMessageElement = xsdgMessagesElements.nth(xsdgMessageIndex - 1);
                        const xsdgMessageText = await xsdgMessageElement.innerText();
                        xsdgList.push(xsdgMessageText);
                    }
                }

                //close the xsdg messages popup if close button is visible
                if (await opr352Page.getElementVisibilityStatus(OPR352_AWB_ENQUIRY_PAGE.CLOSE_AWB_BUTTON)) {
                    await opr352Page.clickOnElement(OPR352_AWB_ENQUIRY_PAGE.CLOSE_AWB_BUTTON);
                }

                await opr352Page.clickOnElement(OPR352_AWB_ENQUIRY_PAGE.EDIT_AWB_BUTTON);
            }
        });

        await allure.step('Close the browser', async () => {
            console.log('Test completed successfully. Closing the browser.');
            //get browser object from page
            const browser = page.context().browser();
            await browser.close();
        });

        //attach flights, awbs, ntms, xsdgs to allure report
        await allure.step('Attach extracted flight numbers, AWB numbers, NTM messages and XSDG messages to Allure report', async () => {
            await allure.attachment('Extracted Flight Numbers', Array.from(flightsList).join('\n'), 'text/plain');
            await allure.attachment('Extracted AWB Numbers', Array.from(awbsList).join('\n'), 'text/plain');
            await allure.attachment('Extracted NTM Messages', ntmsList.join('\n\n---\n\n'), 'text/plain');
            await allure.attachment('Extracted XSDG Messages', xsdgList.join('\n\n---\n\n'), 'text/plain');
        });
    });

    test('NOTOC Interface App - Post XSDG and NTM messages', async () => {
        const notocPage = await BrowserHelpers.launchBrowser();

        const loginPage = new LoginPage(notocPage);
        await loginPage.loginToNotocInterfaceApp(getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_USERNAME), getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_PASSWORD));

        //reload the page multiple times if "Post XSDG Message" link is not found
        const ntmXsdgMessagesPostingPage = new NtmXsdgMessagesPostingPage(notocPage);
        await ntmXsdgMessagesPostingPage.refreshPageUntilProperlyLoaded();

        //post xsdg messages in reverse order as they are extracted
        await allure.step('Post the extracted XSDG messages to Autonotoc Legacy Interface app', async () => {
            await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_XSDG_MESSAGE_HYPERLINK).click();
            for (let xsdgsIndex = xsdgList.length - 1; xsdgsIndex >= 0; xsdgsIndex--) {
                const xsdgMessage = xsdgList[xsdgsIndex];
                await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.XSDG_MESSAGE_TEXTAREA).fill(xsdgMessage, { timeout: TIMEOUTS.LONG });
                await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_TO_MQ_BUTTON).click();
                await notocPage.waitForTimeout(500);
                await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_ONE_MORE_MESSAGE_BUTTON).click({ timeout: TIMEOUTS.LONG });
            }
        });

        //post ntm messages in reverse order as they are extracted
        await allure.step('Post the extracted NTM messages to Autonotoc Legacy Interface app', async () => {
            await notocPage.goto(getEnvVariable(ENV_CONFIG_KEYS.URL_AUTONOTOC_LEGACY_INTERFACEAPP_STAGE));
            await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_NTM_MESSAGE_HYPERLINK).click();
            for (let ntmsIndex = ntmsList.length - 1; ntmsIndex >= 0; ntmsIndex--) {
                const ntmMessage = ntmsList[ntmsIndex];
                await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.NTM_MESSAGE_TEXTAREA).waitFor({ timeout: TIMEOUTS.LONG });
                await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.NTM_MESSAGE_TEXTAREA).fill(ntmMessage, { timeout: TIMEOUTS.LONG });
                await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_TO_MQ_BUTTON).click();
                await notocPage.waitForTimeout(500);
                await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_ONE_MORE_MESSAGE_BUTTON).waitFor({ state: 'visible', timeout: TIMEOUTS.LONG });
                await notocPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_ONE_MORE_MESSAGE_BUTTON).click();
            }
        });

        await allure.step('Close the browser', async () => {
            const browser = notocPage.context().browser();
            await browser.close();
        });
    });

    test('DB Validation Tests for NTM and XSDG messages posted from iCargo to NOTOC Interface app', async () => {
        test.skip(awbsList.length === 0, 'No AWB numbers found from NTM messages');

        const failedAwbs = [];

        // await Promise.allSettled(Array.from(awbsList).map(async (awbNum) => {
        // try {
        let oracleNtmMessageId = ''; //reset ntmMessageId before validating tables for current execution sequence, so that messageid from previous execution sequence is not used in current execution sequence validations
        let postgresNtmMessageId = '';
        for (const currentTable of tables) {
            await allure.step(`${currentTable}`, async () => {
                //fetch tableQuery from dbConfig using currentTable keywhich 
                let tableQuery = dbQueries[currentTable];
                if (!tableQuery) {
                    throw new Error(`DB query details not found for table: ${currentTable} in DB_QUERIES.json. Please check the DB_QUERIES.json file and add the details for ${currentTable}`);
                }

                //replace ${awbs} in tableQuery with awbList in the format ('awb1','awb2','awb3')
                const awbsListForQuery = Array.from(awbsList).map(awb => `'${awb}'`).join(',');
                tableQuery = tableQuery.replace('${awbs}', `(${awbsListForQuery})`);

                //replace date placeholders in tableQuery with actual date
                tableQuery = replaceDatePlaceholders(tableQuery);

                //replace flight numbers placeholders in tableQuery with flight numbers extracted from ntm messages in iCargo
                const flightsListForQuery = Array.from(flightsList).map(flight => `'${flight}'`).join(',');
                tableQuery = tableQuery.replace('${flights}', `(${flightsListForQuery})`);

                let tableQueryOracle = tableQuery;
                let tableQueryPostgres = tableQuery;
                //if tableQuery contains ${ntm_messageid} placeholder, replace it with the actual ntm_messageid extracted from the query result of AUDIT_NTM_MESSAGES table, so that tables which have relation with ntm_messageid
                if (tableQuery.includes('${ntm_messageid}')) {
                    if (!oracleNtmMessageId || !postgresNtmMessageId) {
                        throw new Error(`ntm_messageid is required for validating table: ${currentTable} but it is not extracted from AUDIT_NTM_MESSAGES table. Please check if the query for AUDIT_NTM_MESSAGES table is correct and returns the messageid for the AWBs being validated`);
                    }
                    tableQueryOracle = tableQueryOracle.replace('${ntm_messageid}', `'${oracleNtmMessageId}'`);
                    tableQueryPostgres = tableQueryPostgres.replace('${ntm_messageid}', `'${postgresNtmMessageId}'`);
                }

                //execute DB query and get actual results - placeholder for actual DB call
                //handle exception if query execution fails and log the error in allure and continue with next tables, so that even if validation for one table fails, it continues with other tables and logs all failures in the end
                let postgresTableQueryResult;
                let oracleTableQueryResult;
                try {
                    postgresTableQueryResult = await executeQuery(tableQueryOracle, 3, TIMEOUTS.V_SHORT);
                    oracleTableQueryResult = await executeOracleQuery(tableQueryPostgres, {}, {}, 3, TIMEOUTS.V_SHORT);
                }
                catch (error) {
                    console.error(`Error executing query for table ${currentTable}: ${error.message}`);
                    await allure.step(`Error executing query for table ${currentTable}: ${error.message}`, async () => {
                        await allure.attachment('Oracle Query', tableQueryOracle, 'text/plain');
                        await allure.attachment('Postgres Query', tableQueryPostgres, 'text/plain');
                        await allure.attachment('Error Message', error.message, 'text/plain');
                    });
                    return; // Use return instead of continue to exit the allure.step callback
                }

                //extract ntm_messageid from the query result for AUDIT_NTM_MESSAGES
                if (currentTable === 'AUDIT_NTM_MESSAGES' && postgresTableQueryResult.length > 0) {
                    postgresNtmMessageId = postgresTableQueryResult[0].messageid;
                    oracleNtmMessageId = oracleTableQueryResult[0].MESSAGEID;
                    console.log(`Extracted Message ID for Oracle: ${oracleNtmMessageId}, Postgres: ${postgresNtmMessageId} from table: ${currentTable}`);
                }

                //validate actual results with expected data - placeholder for actual validation logic
                const postgresTableResultNormalized = await normalizeArrayDict(postgresTableQueryResult, ignoreKeyFieldsDuringValidation, convertNullToBlankInNormalization);
                const oracleTableResultNormalized = await normalizeArrayDict(oracleTableQueryResult, ignoreKeyFieldsDuringValidation, convertNullToBlankInNormalization);
                //Add allure step mentioning the table name being validated
                await allure.step(`Validating data for table: ${currentTable}`, async () => {
                    //attach sql queries of oracle and postgres
                    await allure.attachment('Oracle Query', tableQueryOracle, 'text/plain');
                    await allure.attachment('Postgres Query', tableQueryPostgres, 'text/plain');
                    //attach actual and expected data in allure for better debugging in case of failure                        
                    await allure.attachment(`Expected Data (Oracle) - ${currentTable}`, JSON.stringify(oracleTableResultNormalized, null, 2), 'application/json');
                    await allure.attachment(`Actual Data (Postgres) - ${currentTable}`, JSON.stringify(postgresTableResultNormalized, null, 2), 'application/json');
                    //Soft assertion to compare actual and expected data, so that even if validation fails for one table, it continues with other tables and logs all failures in the end
                    expect.soft(postgresTableResultNormalized, `Data mismatch found in table: ${currentTable}`).toEqual(oracleTableResultNormalized);
                    const differences = diff(oracleTableResultNormalized, postgresTableResultNormalized);
                    await allure.step(`Differences for table: ${currentTable}`, async () => {
                        if (differences !== undefined) {
                            await allure.attachment(`Differences - ${currentTable}`, JSON.stringify(differences, null, 2), 'application/json');
                        }
                        else {
                            await allure.attachment(`Differences - ${currentTable}`, 'No differences found', 'text/plain');
                        }
                    });
                });
            });
        }

        //attach xsdgsList and ntmsList to allure report
        await allure.step('Attach the list of XSDG and NTM messages posted from iCargo to NOTOC Interface app to Allure report', async () => {
            await allure.attachment('List of XSDG Messages Posted', xsdgList.join('\n\n---\n\n'), 'text/plain');
            await allure.attachment('List of NTM Messages Posted', ntmsList.join('\n\n---\n\n'), 'text/plain');
        });
    });
});
