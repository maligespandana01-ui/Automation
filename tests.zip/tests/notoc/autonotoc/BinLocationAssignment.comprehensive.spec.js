/**
 * @charset UTF-8
 * Bin Location Assignment - Comprehensive E2E Test Suite
 *
 * Covers:
 * 1. UI Validation - All 4 elements: Flight Date (text), Flight Number (dropdown),
 *    Origin (dropdown), Destination (editable text)
 * 2. XSDG → NTM → UI Binning Flow (end-to-end via Legacy Interface App)
 * 3. Backend DB Validation (UNITASSIGN, BINASSIGN, SHIPPERFLIGHTINFORMATION,
 *    AUDIT_NTM_MESSAGES, AUDIT_XSDG_MESSAGES)
 * 4. All-pieces and partial-pieces (split) binning scenarios
 *
 * Uses: BrowserHelpers manual launch for full control over Legacy + AutoNOTOC browser sessions
 */
import { test, expect } from '@playwright/test';
import fs from 'fs';
import path from 'path';
import * as allure from 'allure-js-commons';
import { BrowserHelpers } from '../../../utils/helpers/BrowserHelpers.js';
import { AutoNotocLoginPage } from '../../../pages/ui/autonotoc/AutoNotocLoginPage.js';
import { BinLocationAssignPage, BIN_LOCATION_PAGE } from '../../../pages/ui/autonotoc/BinLocationAssignPage.js';
import { LoginPage } from '../../../pages/ui/notoc_legacy/LoginPage.js';
import { NtmXsdgMessagesPostingPage, NTM_XSDG_MESSAGES_POSTING_PAGE } from '../../../pages/ui/notoc_legacy/NtmXsdgMessagesPostingPage.js';
import { ENV_CONFIG_KEYS, TIMEOUTS } from '../../../utils/constants/Constants.js';
import { getEnvVariable } from '../../../utils/config/EnvLoader.js';
import { executeQuery } from '../../../utils/helpers/database.js';
import { generateAwb } from '../../../utils/helpers/awbUtils.js';
import { replaceDatePlaceholders } from '../../../utils/helpers/DateUtils.js';
import { Logger } from '../../../utils/helpers/Logger.js';

/* ==================== LOAD TEST DATA ==================== */
const testDataPath = path.join(process.cwd(), 'data', 'test_data', 'autonotoc', 'bin_comprehensive_test_data.json');
const rawTestData = fs.readFileSync(testDataPath, 'utf-8');
const testData = JSON.parse(rawTestData);
const uiPositive = testData.ui_tests.positive;
const uiNegative = testData.ui_tests.negative;
const uiEdgeCases = testData.ui_tests.edge_cases;
const e2eTests = testData.e2e_tests;
const dbQueries = testData.db_queries;

/* ==================== TIMEZONE ==================== */
const timezone = getEnvVariable('DEFAULT_TIMEZONE') || 'America/Chicago';

/* ==================== HELPER: resolve date placeholders in a string ==================== */
function resolveDate(template) {
    if (!template || !template.includes('${date')) return template;
    return replaceDatePlaceholders(template, timezone);
}

/* ==================== HELPER: enter date and wait for dropdown response ==================== */
async function enterDateAndWait(binLocationPage, page, date) {
    await binLocationPage.setFlightDate(date);
    await page.keyboard.press('Tab');
    await page.waitForTimeout(TIMEOUTS.V_SHORT);
}

/* ==================== HELPER: clear date field ==================== */
async function clearDateField(page) {
    const input = page.locator(BIN_LOCATION_PAGE.FLIGHT_DATE_INPUT);
    await input.fill('');
    await page.keyboard.press('Tab');
    await page.waitForTimeout(1000);
}

/* ==================== HELPER: query flights from SHIPPERFLIGHTINFORMATION ==================== */
async function getFlightsFromDb(flightDate) {
    const query = dbQueries.flights_by_date.replace('${flightDate}', flightDate);
    try {
        return await executeQuery(query, 2, TIMEOUTS.V_SHORT);
    } catch (error) {
        Logger.warn('DB', `Could not query flights for date ${flightDate}: ${error.message}`);
        return [];
    }
}

/* ==================== HELPER: query origins from SHIPPERFLIGHTINFORMATION ==================== */
async function getOriginsFromDb(flightDate) {
    const query = dbQueries.origins_by_date.replace('${flightDate}', flightDate);
    try {
        return await executeQuery(query, 2, TIMEOUTS.V_SHORT);
    } catch (error) {
        Logger.warn('DB', `Could not query origins for date ${flightDate}: ${error.message}`);
        return [];
    }
}

/* ==================== HELPER: query destination for specific flight ==================== */
async function getDestinationFromDb(flightDate, flightNumber, origin) {
    const query = dbQueries.destination_for_flight
        .replace('${flightDate}', flightDate)
        .replace('${flightNumber}', flightNumber)
        .replace('${origin}', origin);
    try {
        return await executeQuery(query, 2, TIMEOUTS.V_SHORT);
    } catch (error) {
        Logger.warn('DB', `Could not query destination: ${error.message}`);
        return [];
    }
}

/* ==================== HELPER: query flights filtered by origin ==================== */
async function getFlightsByOriginFromDb(flightDate, origin) {
    const query = dbQueries.flights_by_origin
        .replace('${flightDate}', flightDate)
        .replace('${origin}', origin);
    try {
        return await executeQuery(query, 2, TIMEOUTS.V_SHORT);
    } catch (error) {
        Logger.warn('DB', `Could not query flights by origin: ${error.message}`);
        return [];
    }
}

/* ==================== HELPER: build XSDG XML from template ==================== */
function buildXsdgXml(template, awbNumber, flightNumber, origin, destination) {
    let xml = template;
    xml = xml.replaceAll('${awb1}', awbNumber);
    xml = xml.replaceAll('${flightNumber}', flightNumber);
    xml = xml.replaceAll('${origin}', origin);
    xml = xml.replaceAll('${destination}', destination);
    xml = replaceDatePlaceholders(xml, timezone);
    return xml;
}

/* ==================== HELPER: build NTM message from template ==================== */
function buildNtmMessage(template, awbNumber, flightNumber, origin, destination) {
    let ntm = template;
    ntm = ntm.replaceAll('${awb1}', awbNumber);
    ntm = ntm.replaceAll('${flightNumber}', flightNumber);
    ntm = ntm.replaceAll('${origin}', origin);
    ntm = ntm.replaceAll('${destination}', destination);
    ntm = replaceDatePlaceholders(ntm, timezone);
    return ntm;
}

/* ==================== HELPER: post XSDG + NTM via Legacy Interface App ==================== */
async function postXsdgAndNtmViaLegacyApp(xsdgXmls, ntmMessage) {
    const legacyPage = await BrowserHelpers.launchBrowser();
    try {
        // Login to Legacy Interface App
        const loginPage = new LoginPage(legacyPage);
        await loginPage.loginToNotocInterfaceApp(
            getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_USERNAME),
            getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_PASSWORD)
        );
        const ntmXsdgPage = new NtmXsdgMessagesPostingPage(legacyPage);
        await ntmXsdgPage.refreshPageUntilProperlyLoaded();

        // Post XSDGs (in reverse order matching existing pattern)
        await allure.step(`Post ${xsdgXmls.length} XSDG message(s) via Legacy Interface`, async () => {
            await legacyPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_XSDG_MESSAGE_HYPERLINK).click();
            for (let i = xsdgXmls.length - 1; i >= 0; i--) {
                await legacyPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.XSDG_MESSAGE_TEXTAREA).fill(xsdgXmls[i], { timeout: TIMEOUTS.LONG });
                await legacyPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_TO_MQ_BUTTON).click();
                await legacyPage.waitForTimeout(500);
                await legacyPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_ONE_MORE_MESSAGE_BUTTON).click({ timeout: TIMEOUTS.LONG });
            }
            await allure.attachment('XSDGs Posted', JSON.stringify(xsdgXmls, null, 2), 'application/json');
        });

        // Post NTM
        await allure.step('Post NTM message via Legacy Interface', async () => {
            await legacyPage.goto(getEnvVariable(ENV_CONFIG_KEYS.URL_AUTONOTOC_LEGACY_INTERFACEAPP_STAGE));
            await legacyPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_NTM_MESSAGE_HYPERLINK).click();
            await legacyPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.NTM_MESSAGE_TEXTAREA).waitFor({ timeout: TIMEOUTS.LONG });
            await legacyPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.NTM_MESSAGE_TEXTAREA).fill(ntmMessage, { timeout: TIMEOUTS.LONG });
            await legacyPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_TO_MQ_BUTTON).click();
            await legacyPage.waitForTimeout(500);
            await legacyPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_ONE_MORE_MESSAGE_BUTTON).waitFor({ state: 'visible', timeout: TIMEOUTS.LONG });
            await legacyPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_ONE_MORE_MESSAGE_BUTTON).click();
            await allure.attachment('NTM Posted', ntmMessage, 'text/plain');
        });

        // Wait for processing
        await new Promise(resolve => setTimeout(resolve, TIMEOUTS.MEDIUM));
    } finally {
        await legacyPage.context().browser().close();
    }
}

/* ==================== HELPER: select first available flight from dropdown ==================== */
async function selectFirstAvailableFlight(binLocationPage) {
    const options = await binLocationPage.getFlightNumberOptions();
    const validOptions = options.filter(o => o.value && o.value !== '');
    if (validOptions.length > 0) {
        await binLocationPage.selectFlightNumber(validOptions[0].text);
        return validOptions[0];
    }
    return null;
}

/* ==================== HELPER: select first available origin from dropdown ==================== */
async function selectFirstAvailableOrigin(binLocationPage) {
    const options = await binLocationPage.getOriginOptions();
    const validOptions = options.filter(o => o.value && o.value !== '');
    if (validOptions.length > 0) {
        await binLocationPage.selectOrigin(validOptions[0].text);
        return validOptions[0];
    }
    return null;
}

/* ==================== HELPER: format AWBs for SQL IN clause ==================== */
function formatAwbsForSql(awbMap) {
    return '(' + Object.values(awbMap).map(awb => `'${awb}'`).join(', ') + ')';
}

/* ============================================================================================
 *  SECTION 1: UI VALIDATION TESTS - All 4 elements: Flight Date, Flight Number, Origin, Dest
 * ============================================================================================ */

/* ==================== SHARED BROWSER SESSION FOR UI TESTS ==================== */
let uiPage;
let binLocationPage;

test.describe.serial('Bin Location Assignment - UI Validation (All 4 Elements)', () => {

    test.beforeAll(async () => {
        await allure.step('Launch browser and navigate to Bin Location Assignment', async () => {
            uiPage = await BrowserHelpers.launchBrowser();
            const loginPage = new AutoNotocLoginPage(uiPage);
            await loginPage.login(
                getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_USERNAME),
                getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_PASSWORD)
            );
            await loginPage.navigateToBinLocationAssignment();
            binLocationPage = new BinLocationAssignPage(uiPage);
        });
    });

    test.afterAll(async () => {
        if (uiPage) {
            await uiPage.context().browser().close();
        }
    });

    // ==================== POSITIVE TESTS ====================

    test.describe('Positive Tests', () => {

        test(`[TC_BIN_UI_P001] ${uiPositive.TC_BIN_UI_P001.title}`, { tag: ['@ui', '@positive', '@sanity'] }, async () => {
            const tc = uiPositive.TC_BIN_UI_P001;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('critical');
            await allure.description(tc.description);

            const heading = await binLocationPage.getPageHeading();
            expect(heading).toContain('Dangerous Goods Assign Bin Location');

            // Page pre-fills today's date and auto-populates dropdowns
            const dateInput = uiPage.locator(BIN_LOCATION_PAGE.FLIGHT_DATE_INPUT);
            const dateValue = await dateInput.inputValue();
            expect(dateValue).toMatch(/^\d{2}\/\d{2}\/\d{4}$/);

            // With date pre-filled, dropdowns should be enabled and populated
            expect(await binLocationPage.isFlightNumberDropdownDisabled()).toBe(false);
            expect(await binLocationPage.isOriginDropdownDisabled()).toBe(false);

            const flightCount = await binLocationPage.getFlightNumberCount();
            expect(flightCount).toBeGreaterThan(0);

            await allure.attachment('Pre-filled Date', dateValue, 'text/plain');
            await allure.attachment('Flight Count on Load', String(flightCount), 'text/plain');
        });

        test(`[TC_BIN_UI_P002] ${uiPositive.TC_BIN_UI_P002.title}`, { tag: ['@ui', '@positive', '@sanity'] }, async () => {
            const tc = uiPositive.TC_BIN_UI_P002;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('critical');

            const flightDate = resolveDate(tc.flightDate);
            await enterDateAndWait(binLocationPage, uiPage, flightDate);

            const flightCount = await binLocationPage.getFlightNumberCount();
            expect(flightCount).toBeGreaterThanOrEqual(tc.expectedMinFlightCount);
            expect(await binLocationPage.isFlightNumberDropdownDisabled()).toBe(false);

            await allure.attachment('Flight Date Used', flightDate, 'text/plain');
            await allure.attachment('Flight Count', String(flightCount), 'text/plain');
            await clearDateField(uiPage);
        });

        test(`[TC_BIN_UI_P005] ${uiPositive.TC_BIN_UI_P005.title}`, { tag: ['@ui', '@positive', '@regression'] }, async () => {
            const tc = uiPositive.TC_BIN_UI_P005;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('critical');

            const flightDate = resolveDate(tc.flightDate);
            const dbDate = resolveDate(tc.dbDateFormat);
            await enterDateAndWait(binLocationPage, uiPage, flightDate);

            // Get UI flight options
            const uiOptions = await binLocationPage.getFlightNumberOptions();
            const uiFlightNumbers = uiOptions
                .filter(o => o.value && o.value !== '')
                .map(o => {
                    const match = o.text.match(/Flight\s+(\d+)/);
                    return match ? match[1] : null;
                })
                .filter(Boolean);

            // Get DB flight numbers
            const dbFlights = await getFlightsFromDb(dbDate);
            const dbFlightNumbers = dbFlights.map(r => String(r.legfltnum || r.LEGFLTNUM).replace(/^0+/, ''));

            await allure.step('Cross-validate UI flight numbers vs DB', async () => {
                await allure.attachment('UI Flight Numbers', JSON.stringify(uiFlightNumbers), 'application/json');
                await allure.attachment('DB Flight Numbers', JSON.stringify(dbFlightNumbers), 'application/json');
                for (const dbFlt of dbFlightNumbers) {
                    expect.soft(uiFlightNumbers, `Flight ${dbFlt} from DB should appear in UI dropdown`).toContain(dbFlt);
                }
            });
            await clearDateField(uiPage);
        });

        test(`[TC_BIN_UI_P006] ${uiPositive.TC_BIN_UI_P006.title}`, { tag: ['@ui', '@positive', '@sanity'] }, async () => {
            const tc = uiPositive.TC_BIN_UI_P006;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('critical');

            const flightDate = resolveDate(tc.flightDate);
            await enterDateAndWait(binLocationPage, uiPage, flightDate);

            const selectedFlight = await selectFirstAvailableFlight(binLocationPage);
            expect(selectedFlight).not.toBeNull();

            await uiPage.waitForTimeout(1000);
            const destination = await binLocationPage.getDestination();

            await allure.step(`Destination auto-populated: ${destination}`, async () => {
                expect(destination.length).toBeGreaterThan(0);
            });

            await allure.attachment('Selected Flight', JSON.stringify(selectedFlight), 'application/json');
            await allure.attachment('Destination Value', destination, 'text/plain');
            await clearDateField(uiPage);
        });

        test(`[TC_BIN_UI_P007] ${uiPositive.TC_BIN_UI_P007.title}`, { tag: ['@ui', '@positive', '@regression'] }, async () => {
            const tc = uiPositive.TC_BIN_UI_P007;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('normal');

            const flightDate = resolveDate(tc.flightDate);
            await enterDateAndWait(binLocationPage, uiPage, flightDate);

            const options = await binLocationPage.getFlightNumberOptions();
            const validOptions = options.filter(o => o.value && o.value !== '');
            if (validOptions.length >= 2) {
                // Select first flight
                await binLocationPage.selectFlightNumber(validOptions[0].text);
                await uiPage.waitForTimeout(1000);
                const dest1 = await binLocationPage.getDestination();

                // Change to second flight
                await binLocationPage.selectFlightNumber(validOptions[1].text);
                await uiPage.waitForTimeout(1000);
                const dest2 = await binLocationPage.getDestination();

                await allure.step('Destination should update on flight change', async () => {
                    await allure.attachment('Destination for Flight 1', dest1, 'text/plain');
                    await allure.attachment('Destination for Flight 2', dest2, 'text/plain');
                    // Destination should be populated (may be same or different airport)
                    expect(dest2.length).toBeGreaterThan(0);
                });
            } else {
                test.skip(true, 'Need at least 2 flights to test flight change');
            }
            await clearDateField(uiPage);
        });

        test(`[TC_BIN_UI_P008] ${uiPositive.TC_BIN_UI_P008.title}`, { tag: ['@ui', '@positive', '@regression'] }, async () => {
            const tc = uiPositive.TC_BIN_UI_P008;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('critical');

            const flightDate = resolveDate(tc.flightDate);
            const dbDate = resolveDate(tc.dbDateFormat);
            await enterDateAndWait(binLocationPage, uiPage, flightDate);

            // Get UI origins
            const uiOriginOptions = await binLocationPage.getOriginOptions();
            const uiOriginCodes = uiOriginOptions
                .filter(o => o.value && o.value !== '')
                .map(o => {
                    const match = o.text.match(/\(([A-Z]{3})\)/);
                    return match ? match[1] : o.value;
                });

            // Get DB origins
            const dbOrigins = await getOriginsFromDb(dbDate);
            const dbOriginCodes = dbOrigins.map(r => String(r.legorigin || r.LEGORIGIN));

            await allure.step('Cross-validate UI origins vs DB', async () => {
                await allure.attachment('UI Origin Codes', JSON.stringify(uiOriginCodes), 'application/json');
                await allure.attachment('DB Origin Codes', JSON.stringify(dbOriginCodes), 'application/json');
                for (const dbOrig of dbOriginCodes) {
                    expect.soft(uiOriginCodes, `Origin ${dbOrig} from DB should appear in UI dropdown`).toContain(dbOrig);
                }
            });
            await clearDateField(uiPage);
        });

        test(`[TC_BIN_UI_P009] ${uiPositive.TC_BIN_UI_P009.title}`, { tag: ['@ui', '@positive', '@regression'] }, async () => {
            const tc = uiPositive.TC_BIN_UI_P009;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('critical');

            const flightDate = resolveDate(tc.flightDate);
            const dbDate = resolveDate(tc.dbDateFormat);
            await enterDateAndWait(binLocationPage, uiPage, flightDate);

            // Get all origins and select one
            const originOptions = await binLocationPage.getOriginOptions();
            const validOrigins = originOptions.filter(o => o.value && o.value !== '');
            if (validOrigins.length > 0) {
                const selectedOrigin = validOrigins[0];
                const originCode = selectedOrigin.value || selectedOrigin.text.match(/\(([A-Z]{3})\)/)?.[1];
                await binLocationPage.selectOrigin(selectedOrigin.text);
                await uiPage.waitForTimeout(1000);

                // Get filtered flight options after origin selection
                const filteredFlights = await binLocationPage.getFlightNumberOptions();
                const filteredFlightTexts = filteredFlights.filter(o => o.value && o.value !== '');

                // Verify flights are populated after origin selection
                await allure.step(`Verify flights available after selecting origin ${originCode}`, async () => {
                    expect(filteredFlightTexts.length).toBeGreaterThan(0);
                    // Check if any flight originates from selected origin
                    const matchingFlights = filteredFlightTexts.filter(flt => flt.text.includes(`(${originCode}`));
                    await allure.attachment('All Flights After Origin Selection', JSON.stringify(filteredFlightTexts.map(f => f.text)), 'application/json');
                    await allure.attachment('Flights Matching Selected Origin', JSON.stringify(matchingFlights.map(f => f.text)), 'application/json');
                    Logger.info('UI', `Origin ${originCode} selected: ${filteredFlightTexts.length} total flights, ${matchingFlights.length} matching origin`);
                });

                // Cross-validate with DB - verify flights from selected origin exist in DB
                if (originCode) {
                    const dbFlights = await getFlightsByOriginFromDb(dbDate, originCode);
                    const dbFlightNums = dbFlights.map(r => String(r.legfltnum || r.LEGFLTNUM).replace(/^0+/, ''));
                    await allure.attachment('DB Flights from Origin', JSON.stringify(dbFlights), 'application/json');
                    // Verify DB flights from this origin appear somewhere in the UI dropdown
                    for (const dbFlt of dbFlightNums) {
                        const found = filteredFlightTexts.some(flt => flt.text.includes(dbFlt));
                        expect.soft(found, `DB flight ${dbFlt} from origin ${originCode} should appear in UI dropdown`).toBeTruthy();
                    }
                }
            }
            await clearDateField(uiPage);
        });

        test(`[TC_BIN_UI_P010] ${uiPositive.TC_BIN_UI_P010.title}`, { tag: ['@ui', '@positive', '@regression'] }, async () => {
            const tc = uiPositive.TC_BIN_UI_P010;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('normal');

            const flightDate = resolveDate(tc.flightDate);
            await enterDateAndWait(binLocationPage, uiPage, flightDate);

            const originOptions = await binLocationPage.getOriginOptions();
            const validOrigins = originOptions.filter(o => o.value && o.value !== '');
            if (validOrigins.length >= 2) {
                // Select first origin
                await binLocationPage.selectOrigin(validOrigins[0].text);
                await uiPage.waitForTimeout(1000);
                const flights1 = await binLocationPage.getFlightNumberOptions();
                const count1 = flights1.filter(o => o.value && o.value !== '').length;

                // Select flight and observe destination
                await selectFirstAvailableFlight(binLocationPage);
                await uiPage.waitForTimeout(500);

                // Change to second origin
                await binLocationPage.selectOrigin(validOrigins[1].text);
                await uiPage.waitForTimeout(1000);
                const flights2 = await binLocationPage.getFlightNumberOptions();
                const count2 = flights2.filter(o => o.value && o.value !== '').length;

                await allure.step('Flight list should change when origin changes', async () => {
                    await allure.attachment('Flights count origin 1', String(count1), 'text/plain');
                    await allure.attachment('Flights count origin 2', String(count2), 'text/plain');
                });
            } else {
                test.skip(true, 'Need at least 2 origins to test origin change');
            }
            await clearDateField(uiPage);
        });

        test(`[TC_BIN_UI_P011] ${uiPositive.TC_BIN_UI_P011.title}`, { tag: ['@ui', '@positive', '@regression'] }, async () => {
            const tc = uiPositive.TC_BIN_UI_P011;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('normal');

            const flightDate = resolveDate(tc.flightDate);
            await enterDateAndWait(binLocationPage, uiPage, flightDate);
            await selectFirstAvailableFlight(binLocationPage);
            await uiPage.waitForTimeout(1000);

            // Get auto-populated destination
            const autoDest = await binLocationPage.getDestination();

            // Clear and type a new destination
            const destInput = uiPage.locator(BIN_LOCATION_PAGE.DESTINATION_INPUT);
            await destInput.fill('');
            await destInput.fill(tc.manualDestination);

            const newDest = await binLocationPage.getDestination();
            expect(newDest).toBe(tc.manualDestination);

            await allure.attachment('Auto-populated Destination', autoDest, 'text/plain');
            await allure.attachment('Manual Override Destination', newDest, 'text/plain');
            await clearDateField(uiPage);
        });

        test(`[TC_BIN_UI_P012] ${uiPositive.TC_BIN_UI_P012.title}`, { tag: ['@ui', '@positive', '@sanity'] }, async () => {
            const tc = uiPositive.TC_BIN_UI_P012;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('critical');

            const flightDate = resolveDate(tc.flightDate);
            const dbDate = resolveDate(tc.dbDateFormat);
            await enterDateAndWait(binLocationPage, uiPage, flightDate);

            // Select origin first, then flight
            const selectedOrigin = await selectFirstAvailableOrigin(binLocationPage);
            await uiPage.waitForTimeout(500);
            const selectedFlight = await selectFirstAvailableFlight(binLocationPage);
            await uiPage.waitForTimeout(1000);

            if (selectedFlight && selectedOrigin) {
                const uiDest = await binLocationPage.getDestination();
                const flightMatch = selectedFlight.text.match(/Flight\s+(\d+)/);
                const originCode = selectedOrigin.value || selectedOrigin.text.match(/\(([A-Z]{3})\)/)?.[1];

                if (flightMatch && originCode) {
                    const dbResult = await getDestinationFromDb(dbDate, flightMatch[1], originCode);
                    if (dbResult.length > 0) {
                        const dbDest = String(dbResult[0].legdestination || dbResult[0].LEGDESTINATION);
                        expect.soft(uiDest).toBe(dbDest);
                        await allure.attachment('UI Destination', uiDest, 'text/plain');
                        await allure.attachment('DB Destination', dbDest, 'text/plain');
                    }
                }
            }
            await clearDateField(uiPage);
        });

        test(`[TC_BIN_UI_P013] ${uiPositive.TC_BIN_UI_P013.title}`, { tag: ['@ui', '@positive', '@sanity'] }, async () => {
            const tc = uiPositive.TC_BIN_UI_P013;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('critical');

            const flightDate = resolveDate(tc.flightDate);
            await enterDateAndWait(binLocationPage, uiPage, flightDate);
            await selectFirstAvailableOrigin(binLocationPage);
            await uiPage.waitForTimeout(500);
            await selectFirstAvailableFlight(binLocationPage);
            await uiPage.waitForTimeout(500);

            const isDisabled = await binLocationPage.isSubmitButtonDisabled();
            expect(isDisabled).toBe(false);
            await clearDateField(uiPage);
        });

        test(`[TC_BIN_UI_P014] ${uiPositive.TC_BIN_UI_P014.title}`, { tag: ['@ui', '@positive', '@sanity'] }, async () => {
            const tc = uiPositive.TC_BIN_UI_P014;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('critical');

            const flightDate = resolveDate(tc.flightDate);
            await enterDateAndWait(binLocationPage, uiPage, flightDate);
            await selectFirstAvailableOrigin(binLocationPage);
            await uiPage.waitForTimeout(500);
            await selectFirstAvailableFlight(binLocationPage);
            await uiPage.waitForTimeout(500);

            await binLocationPage.clickSubmit();
            await uiPage.waitForTimeout(TIMEOUTS.SHORT);

            // Handle lockdown dialog if it appears
            if (await binLocationPage.isLockdownDialogVisible()) {
                await binLocationPage.unlockFlight();
                await uiPage.waitForTimeout(TIMEOUTS.SHORT);
            }

            const tableVisible = await binLocationPage.isAssignmentTableVisible();
            expect(tableVisible).toBe(true);

            // Verify table header shows flight info
            const headerFlight = uiPage.locator(BIN_LOCATION_PAGE.HEADER_FLIGHT);
            await expect(headerFlight).toBeVisible();
            const headerDate = uiPage.locator(BIN_LOCATION_PAGE.HEADER_DATE);
            await expect(headerDate).toBeVisible();

            // Navigate back for next tests
            await binLocationPage.clickExit();
            await uiPage.waitForTimeout(TIMEOUTS.SHORT);
        });
    });

    // ==================== NEGATIVE TESTS ====================

    test.describe('Negative Tests', () => {

        test(`[TC_BIN_UI_N001] ${uiNegative.TC_BIN_UI_N001.title}`, { tag: ['@ui', '@negative'] }, async () => {
            const tc = uiNegative.TC_BIN_UI_N001;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('critical');

            await clearDateField(uiPage);
            await uiPage.waitForTimeout(TIMEOUTS.V_SHORT);

            // Verify date field is empty
            const dateValue = await uiPage.locator(BIN_LOCATION_PAGE.FLIGHT_DATE_INPUT).inputValue();
            expect(dateValue).toBe('');

            // After clearing date, either dropdowns are disabled/empty or submit is prevented
            const flightDisabled = await binLocationPage.isFlightNumberDropdownDisabled();
            const noFlights = await binLocationPage.isNoFlightsFoundVisible();
            const flightCount = await binLocationPage.getFlightNumberCount();
            const submitDisabled = await binLocationPage.isSubmitButtonDisabled();

            await allure.step('Validate UI state with empty date field', async () => {
                await allure.attachment('UI State', JSON.stringify({
                    dateValue,
                    flightDropdownDisabled: flightDisabled,
                    noFlightsVisible: noFlights,
                    flightCount,
                    submitDisabled
                }), 'application/json');
                // At least one guard is active: dropdowns disabled, no flights, or submit disabled
                expect(flightDisabled || noFlights || flightCount === 0 || submitDisabled).toBe(true);
            });
        });

        test(`[TC_BIN_UI_N002] ${uiNegative.TC_BIN_UI_N002.title}`, { tag: ['@ui', '@negative'] }, async () => {
            const tc = uiNegative.TC_BIN_UI_N002;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('critical');

            await clearDateField(uiPage);
            await enterDateAndWait(binLocationPage, uiPage, tc.flightDate);
            // DD/MM/YYYY format should cause validation error or no valid flights
            const flightDisabled = await binLocationPage.isFlightNumberDropdownDisabled();
            const noFlights = await binLocationPage.isNoFlightsFoundVisible();
            const flightCount = await binLocationPage.getFlightNumberCount();
            expect(flightDisabled || noFlights || flightCount === 0).toBe(true);
            await clearDateField(uiPage);
        });

        test(`[TC_BIN_UI_N003] ${uiNegative.TC_BIN_UI_N003.title}`, { tag: ['@ui', '@negative'] }, async () => {
            const tc = uiNegative.TC_BIN_UI_N003;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('critical');

            await clearDateField(uiPage);
            await enterDateAndWait(binLocationPage, uiPage, tc.flightDate);
            const flightDisabled = await binLocationPage.isFlightNumberDropdownDisabled();
            const noFlights = await binLocationPage.isNoFlightsFoundVisible();
            const flightCount = await binLocationPage.getFlightNumberCount();
            expect(flightDisabled || noFlights || flightCount === 0).toBe(true);
            await clearDateField(uiPage);
        });

        test(`[TC_BIN_UI_N004] ${uiNegative.TC_BIN_UI_N004.title}`, { tag: ['@ui', '@negative'] }, async () => {
            const tc = uiNegative.TC_BIN_UI_N004;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('critical');

            await clearDateField(uiPage);
            await enterDateAndWait(binLocationPage, uiPage, tc.flightDate);
            const flightDisabled = await binLocationPage.isFlightNumberDropdownDisabled();
            const noFlights = await binLocationPage.isNoFlightsFoundVisible();
            const flightCount = await binLocationPage.getFlightNumberCount();
            expect(flightDisabled || noFlights || flightCount === 0).toBe(true);
            await clearDateField(uiPage);
        });

        test(`[TC_BIN_UI_N005] ${uiNegative.TC_BIN_UI_N005.title}`, { tag: ['@ui', '@negative'] }, async () => {
            const tc = uiNegative.TC_BIN_UI_N005;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('normal');

            await clearDateField(uiPage);
            await enterDateAndWait(binLocationPage, uiPage, tc.flightDate);
            const noFlights = await binLocationPage.isNoFlightsFoundVisible();
            const flightDisabled = await binLocationPage.isFlightNumberDropdownDisabled();
            const flightCount = await binLocationPage.getFlightNumberCount();
            expect(noFlights || flightDisabled || flightCount === 0).toBe(true);
            await clearDateField(uiPage);
        });

        test(`[TC_BIN_UI_N006] ${uiNegative.TC_BIN_UI_N006.title}`, { tag: ['@ui', '@negative'] }, async () => {
            const tc = uiNegative.TC_BIN_UI_N006;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('normal');

            await clearDateField(uiPage);
            await enterDateAndWait(binLocationPage, uiPage, tc.flightDate);
            const flightDisabled = await binLocationPage.isFlightNumberDropdownDisabled();
            const noFlights = await binLocationPage.isNoFlightsFoundVisible();
            const flightCount = await binLocationPage.getFlightNumberCount();
            expect(flightDisabled || noFlights || flightCount === 0).toBe(true);
            await clearDateField(uiPage);
        });

        test(`[TC_BIN_UI_N007] ${uiNegative.TC_BIN_UI_N007.title}`, { tag: ['@ui', '@negative'] }, async () => {
            const tc = uiNegative.TC_BIN_UI_N007;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('normal');

            await clearDateField(uiPage);
            await enterDateAndWait(binLocationPage, uiPage, tc.flightDate);
            const flightDisabled = await binLocationPage.isFlightNumberDropdownDisabled();
            const noFlights = await binLocationPage.isNoFlightsFoundVisible();
            const flightCount = await binLocationPage.getFlightNumberCount();
            expect(flightDisabled || noFlights || flightCount === 0).toBe(true);
            await clearDateField(uiPage);
        });

        test(`[TC_BIN_UI_N008] ${uiNegative.TC_BIN_UI_N008.title}`, { tag: ['@ui', '@negative'] }, async () => {
            const tc = uiNegative.TC_BIN_UI_N008;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('critical');

            const flightDate = resolveDate(tc.flightDate);
            await clearDateField(uiPage);
            await enterDateAndWait(binLocationPage, uiPage, flightDate);
            // Page may auto-select first flight; reset flight dropdown to placeholder
            const flightDropdown = uiPage.locator(BIN_LOCATION_PAGE.FLIGHT_NUMBER_DROPDOWN);
            const options = await flightDropdown.locator('option').all();
            if (options.length > 0) {
                const firstOptValue = await options[0].getAttribute('value');
                await flightDropdown.selectOption({ index: 0 });
                await uiPage.waitForTimeout(500);
            }
            const submitState = await binLocationPage.isSubmitButtonDisabled();
            await allure.attachment('Submit disabled without flight selection', String(submitState), 'text/plain');
            await clearDateField(uiPage);
        });

        test(`[TC_BIN_UI_N009] ${uiNegative.TC_BIN_UI_N009.title}`, { tag: ['@ui', '@negative'] }, async () => {
            const tc = uiNegative.TC_BIN_UI_N009;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('critical');

            const flightDate = resolveDate(tc.flightDate);
            await enterDateAndWait(binLocationPage, uiPage, flightDate);
            await selectFirstAvailableFlight(binLocationPage);
            // Do NOT select origin
            expect(await binLocationPage.isSubmitButtonDisabled()).toBe(true);
            await clearDateField(uiPage);
        });

        test(`[TC_BIN_UI_N010] ${uiNegative.TC_BIN_UI_N010.title}`, { tag: ['@ui', '@negative'] }, async () => {
            const tc = uiNegative.TC_BIN_UI_N010;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('normal');

            const flightDate = resolveDate(tc.flightDate);
            await enterDateAndWait(binLocationPage, uiPage, flightDate);
            await selectFirstAvailableOrigin(binLocationPage);
            await uiPage.waitForTimeout(500);
            await selectFirstAvailableFlight(binLocationPage);
            await uiPage.waitForTimeout(1000);

            // Clear destination
            const destInput = uiPage.locator(BIN_LOCATION_PAGE.DESTINATION_INPUT);
            await destInput.fill('');

            const destValue = await binLocationPage.getDestination();
            expect(destValue).toBe('');

            // Try to submit with empty destination
            const submitDisabled = await binLocationPage.isSubmitButtonDisabled();
            // System should either disable submit or show validation on click
            await allure.attachment('Submit disabled with empty dest', String(submitDisabled), 'text/plain');
            await clearDateField(uiPage);
        });

        test(`[TC_BIN_UI_N011] ${uiNegative.TC_BIN_UI_N011.title}`, { tag: ['@ui', '@negative'] }, async () => {
            const tc = uiNegative.TC_BIN_UI_N011;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('normal');

            const flightDate = resolveDate(tc.flightDate);
            await enterDateAndWait(binLocationPage, uiPage, flightDate);
            await selectFirstAvailableOrigin(binLocationPage);
            await uiPage.waitForTimeout(500);
            await selectFirstAvailableFlight(binLocationPage);
            await uiPage.waitForTimeout(1000);

            // Override destination with invalid code
            const destInput = uiPage.locator(BIN_LOCATION_PAGE.DESTINATION_INPUT);
            await destInput.fill('');
            await destInput.fill(tc.invalidDestination);
            const newDest = await binLocationPage.getDestination();
            expect(newDest).toBe(tc.invalidDestination);
            await clearDateField(uiPage);
        });
    });

    // ==================== EDGE CASE TESTS ====================

    test.describe('Edge Cases', () => {

        test(`[TC_BIN_UI_E001] ${uiEdgeCases.TC_BIN_UI_E001.title}`, { tag: ['@ui', '@edge'] }, async () => {
            const tc = uiEdgeCases.TC_BIN_UI_E001;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('normal');

            await clearDateField(uiPage);
            await enterDateAndWait(binLocationPage, uiPage, tc.flightDate);
            // Leap year date should be accepted as valid
            const flightDisabled = await binLocationPage.isFlightNumberDropdownDisabled();
            const noFlights = await binLocationPage.isNoFlightsFoundVisible();
            // Either flights populate or "No Flights Found" appears - both valid for leap year
            await allure.attachment('Flight dropdown disabled', String(flightDisabled), 'text/plain');
            await allure.attachment('No flights banner visible', String(noFlights), 'text/plain');
            await clearDateField(uiPage);
        });

        test(`[TC_BIN_UI_E002] ${uiEdgeCases.TC_BIN_UI_E002.title}`, { tag: ['@ui', '@edge'] }, async () => {
            const tc = uiEdgeCases.TC_BIN_UI_E002;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('normal');

            await clearDateField(uiPage);
            await enterDateAndWait(binLocationPage, uiPage, tc.flightDate);
            // Non-leap year Feb 29 should be rejected
            const flightDisabled = await binLocationPage.isFlightNumberDropdownDisabled();
            const noFlights = await binLocationPage.isNoFlightsFoundVisible();
            const flightCount = await binLocationPage.getFlightNumberCount();
            expect(flightDisabled || noFlights || flightCount === 0).toBe(true);
            await clearDateField(uiPage);
        });

        test(`[TC_BIN_UI_E007] ${uiEdgeCases.TC_BIN_UI_E007.title}`, { tag: ['@ui', '@edge'] }, async () => {
            const tc = uiEdgeCases.TC_BIN_UI_E007;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('minor');

            const flightDate = resolveDate(tc.flightDate);
            await enterDateAndWait(binLocationPage, uiPage, flightDate);
            await selectFirstAvailableOrigin(binLocationPage);
            await uiPage.waitForTimeout(500);
            await selectFirstAvailableFlight(binLocationPage);
            await uiPage.waitForTimeout(1000);

            const destInput = uiPage.locator(BIN_LOCATION_PAGE.DESTINATION_INPUT);
            await destInput.fill('');
            await destInput.fill(tc.longDestination);

            const value = await binLocationPage.getDestination();
            await allure.attachment('Long Destination Value', value, 'text/plain');
            await allure.attachment('Input Length', String(value.length), 'text/plain');
            await clearDateField(uiPage);
        });

        test(`[TC_BIN_UI_E008] ${uiEdgeCases.TC_BIN_UI_E008.title}`, { tag: ['@ui', '@edge'] }, async () => {
            const tc = uiEdgeCases.TC_BIN_UI_E008;
            await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
            await allure.severity('normal');

            const flightDate = resolveDate(tc.flightDate);
            const newDate = resolveDate(tc.newFlightDate);

            // Enter first date and make selections
            await enterDateAndWait(binLocationPage, uiPage, flightDate);
            await selectFirstAvailableOrigin(binLocationPage);
            await uiPage.waitForTimeout(500);
            await selectFirstAvailableFlight(binLocationPage);
            await uiPage.waitForTimeout(500);

            // Now change date
            await enterDateAndWait(binLocationPage, uiPage, newDate);
            await uiPage.waitForTimeout(TIMEOUTS.V_SHORT);

            // Verify dropdowns reset
            const dest = await binLocationPage.getDestination();
            await allure.step('All fields should reset on date change', async () => {
                await allure.attachment('Destination after date change', dest, 'text/plain');
            });
            await clearDateField(uiPage);
        });
    });
});


/* ============================================================================================
 *  SECTION 2: END-TO-END TESTS - XSDG → NTM → UI → DB (Full Binning Flow)
 * ============================================================================================ */

test.describe.serial('Bin Location Assignment - E2E (XSDG → NTM → UI → DB)', () => {

    /* ==================== SHARED STATE FOR E2E TESTS ==================== */
    let e2ePage;
    let e2eBinLocationPage;
    let generatedAwbs = {};
    let xsdgXmls = [];
    let ntmMessage = '';

    test.beforeAll(async () => {
        await allure.step('Generate AWBs and prepare XSDG/NTM messages', async () => {
            // Generate unique AWB for this test run
            const awb1 = generateAwb();
            generatedAwbs['${awb1}'] = awb1;

            const tc = e2eTests.TC_BIN_E2E_001;

            // Build XSDG XML
            const xsdgXml = buildXsdgXml(
                e2eTests.xsdg_xml_template,
                awb1,
                tc.flightNumber,
                tc.origin,
                tc.destination
            );
            xsdgXmls.push(xsdgXml);

            // Build NTM message
            ntmMessage = buildNtmMessage(
                e2eTests.ntm_template,
                awb1,
                tc.flightNumber,
                tc.origin,
                tc.destination
            );

            await allure.attachment('Generated AWBs', JSON.stringify(generatedAwbs, null, 2), 'application/json');
            await allure.attachment('XSDG XML', xsdgXml, 'text/xml');
            await allure.attachment('NTM Message', ntmMessage, 'text/plain');
        });
    });

    test.afterAll(async () => {
        if (e2ePage) {
            await e2ePage.context().browser().close();
        }
    });

    test(`[TC_BIN_E2E_001] ${e2eTests.TC_BIN_E2E_001.title}`, { tag: ['@e2e', '@sanity', '@critical'] }, async () => {
        const tc = e2eTests.TC_BIN_E2E_001;
        await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
        await allure.severity('critical');
        await allure.description(tc.description);

        // Step 1: Post XSDG and NTM via Legacy Interface App
        await allure.step('Step 1: Post XSDG and NTM via Legacy Interface App', async () => {
            await postXsdgAndNtmViaLegacyApp(xsdgXmls, ntmMessage);
        });

        // Step 2: Navigate to AutoNOTOC and search for the flight
        await allure.step('Step 2: Navigate to AutoNOTOC Bin Location Assignment', async () => {
            e2ePage = await BrowserHelpers.launchBrowser();
            const loginPage = new AutoNotocLoginPage(e2ePage);
            await loginPage.login(
                getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_USERNAME),
                getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_PASSWORD)
            );
            await loginPage.navigateToBinLocationAssignment();
            e2eBinLocationPage = new BinLocationAssignPage(e2ePage);
        });

        // Step 3: Enter flight details from NTM data
        await allure.step('Step 3: Enter flight details and verify dropdown population', async () => {
            const flightDate = resolveDate('${date|MM/DD/YYYY|+0}');
            await enterDateAndWait(e2eBinLocationPage, e2ePage, flightDate);

            // Verify flight appears in dropdown
            const flightOptions = await e2eBinLocationPage.getFlightNumberOptions();
            const matchingFlight = flightOptions.find(o => o.text.includes(tc.flightNumber));
            expect(matchingFlight, `Flight ${tc.flightNumber} should appear in dropdown after NTM processing`).toBeTruthy();

            // Select the flight
            if (matchingFlight) {
                await e2eBinLocationPage.selectFlightNumber(matchingFlight.text);
            }

            // Verify origin
            const originOptions = await e2eBinLocationPage.getOriginOptions();
            const matchingOrigin = originOptions.find(o => o.text.includes(tc.origin));
            expect(matchingOrigin, `Origin ${tc.origin} should appear in dropdown`).toBeTruthy();
            if (matchingOrigin) {
                await e2eBinLocationPage.selectOrigin(matchingOrigin.text);
            }

            await e2ePage.waitForTimeout(1000);

            // Verify destination auto-populates
            const destination = await e2eBinLocationPage.getDestination();
            expect(destination).toBe(tc.destination);

            await allure.attachment('Flight Date', flightDate, 'text/plain');
            await allure.attachment('Selected Flight', matchingFlight?.text || 'NOT FOUND', 'text/plain');
            await allure.attachment('Selected Origin', matchingOrigin?.text || 'NOT FOUND', 'text/plain');
            await allure.attachment('Destination', destination, 'text/plain');
        });
    });

    test(`[TC_BIN_E2E_002] ${e2eTests.TC_BIN_E2E_002.title}`, { tag: ['@e2e', '@sanity'] }, async () => {
        const tc = e2eTests.TC_BIN_E2E_002;
        await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
        await allure.severity('critical');

        // Submit and load assignment table
        await allure.step('Submit flight search and verify assignment table', async () => {
            await e2eBinLocationPage.clickSubmit();
            await e2ePage.waitForTimeout(TIMEOUTS.SHORT);

            // Handle lockdown dialog if it appears
            if (await e2eBinLocationPage.isLockdownDialogVisible()) {
                await e2eBinLocationPage.unlockFlight();
                await e2ePage.waitForTimeout(TIMEOUTS.SHORT);
            }

            const tableVisible = await e2eBinLocationPage.isAssignmentTableVisible();
            expect(tableVisible, 'Assignment table should be visible after Submit').toBe(true);

            // Verify flight info in table header
            const flightHeader = e2ePage.locator(BIN_LOCATION_PAGE.HEADER_FLIGHT);
            const headerText = await flightHeader.innerText();
            expect(headerText).toContain(tc.flightNumber);

            // Verify units in table
            const rowCount = await e2eBinLocationPage.getAssignmentRowCount();
            expect(rowCount).toBeGreaterThan(0);

            const tableData = await e2eBinLocationPage.getAssignmentTableData();
            await allure.attachment('Assignment Table Data', JSON.stringify(tableData, null, 2), 'application/json');
            await allure.attachment('Row Count', String(rowCount), 'text/plain');
        });
    });

    test(`[TC_BIN_E2E_003] ${e2eTests.TC_BIN_E2E_003.title}`, { tag: ['@e2e', '@regression'] }, async () => {
        const tc = e2eTests.TC_BIN_E2E_003;
        await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
        await allure.severity('critical');

        await allure.step('Cross-validate UI assignment table vs UNITASSIGN DB table', async () => {
            // Get UI table data
            const uiTableData = await e2eBinLocationPage.getAssignmentTableData();

            // Query UNITASSIGN DB table
            const awbsSql = formatAwbsForSql(generatedAwbs);
            const unitQuery = dbQueries.unitassign_by_awbs.replace('${awbs}', awbsSql);
            const dbUnitData = await executeQuery(unitQuery, 3, TIMEOUTS.V_SHORT);

            await allure.attachment('UI Table Data', JSON.stringify(uiTableData, null, 2), 'application/json');
            await allure.attachment('DB UNITASSIGN Data', JSON.stringify(dbUnitData, null, 2), 'application/json');

            // Cross-validate
            expect(dbUnitData.length).toBeGreaterThan(0);
            for (const dbRow of dbUnitData) {
                const unitAssigned = String(dbRow.unitassigned || dbRow.UNITASSIGNED);
                const totalPcs = String(dbRow.totalpcs || dbRow.TOTALPCS);
                const totalWt = String(dbRow.totalweight || dbRow.TOTALWEIGHT);
                const classDiv = String(dbRow.displayedclassdiv || dbRow.DISPLAYEDCLASSDIV);

                await allure.step(`Validate unit: ${unitAssigned}`, async () => {
                    await allure.attachment('DB Unit Row', JSON.stringify(dbRow, null, 2), 'application/json');
                });
            }

            // Also validate SHIPPERFLIGHTINFORMATION
            const sfiQuery = dbQueries.sfi_by_awbs.replace('${awbs}', awbsSql);
            const dbSfiData = await executeQuery(sfiQuery, 3, TIMEOUTS.V_SHORT);
            expect(dbSfiData.length).toBeGreaterThan(0);
            await allure.attachment('DB SHIPPERFLIGHTINFORMATION', JSON.stringify(dbSfiData, null, 2), 'application/json');
        });
    });

    test('[TC_BIN_E2E_006] AUDIT_NTM_MESSAGES logged correctly', { tag: ['@e2e', '@regression'] }, async () => {
        await allure.displayName('TC_BIN_E2E_006 - Verify NTM audit trail');
        await allure.severity('critical');

        const awbsSql = formatAwbsForSql(generatedAwbs);
        const query = dbQueries.audit_ntm_by_awbs.replace('${awbs}', awbsSql);
        const auditData = await executeQuery(query, 3, TIMEOUTS.V_SHORT);

        await allure.attachment('AUDIT_NTM_MESSAGES', JSON.stringify(auditData, null, 2), 'application/json');
        expect(auditData.length, 'NTM audit record should exist').toBeGreaterThan(0);
    });

    test('[TC_BIN_E2E_007] AUDIT_XSDG_MESSAGES logged correctly', { tag: ['@e2e', '@regression'] }, async () => {
        await allure.displayName('TC_BIN_E2E_007 - Verify XSDG audit trail');
        await allure.severity('critical');

        const awbsSql = formatAwbsForSql(generatedAwbs);
        const query = dbQueries.audit_xsdg_by_awbs.replace('${awbs}', awbsSql);
        const auditData = await executeQuery(query, 3, TIMEOUTS.V_SHORT);

        await allure.attachment('AUDIT_XSDG_MESSAGES', JSON.stringify(auditData, null, 2), 'application/json');
        expect(auditData.length, 'XSDG audit record should exist').toBeGreaterThan(0);
    });

    test(`[TC_BIN_E2E_008] ${e2eTests.TC_BIN_E2E_008.title}`, { tag: ['@e2e', '@sanity', '@binning'] }, async () => {
        const tc = e2eTests.TC_BIN_E2E_008;
        await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
        await allure.severity('critical');

        await allure.step('Select ALL radio for first unit and add to bin', async () => {
            // Get unit data from the table
            const tableData = await e2eBinLocationPage.getAssignmentTableData();
            expect(tableData.length).toBeGreaterThan(0);

            const firstUnit = tableData[0];
            Logger.info('E2E-Binning', `Binning all pieces for unit: ${firstUnit.unitId}`);

            // Click ALL radio for first unit
            await e2eBinLocationPage.selectAllForUnit(firstUnit.unitId);
            await e2ePage.waitForTimeout(500);

            // Click Add New Bin
            await e2eBinLocationPage.clickAddNewBin();
            await e2ePage.waitForTimeout(TIMEOUTS.SHORT);

            // Fill bin dialog
            const binInput = e2ePage.locator(BIN_LOCATION_PAGE.BIN_LOCATION_INPUT);
            if (await binInput.isVisible()) {
                await binInput.fill(tc.binLocation);

                // Select compartment
                const compartmentOption = e2ePage.locator(`option:has-text("${tc.compartment}")`);
                if (await compartmentOption.isVisible()) {
                    await compartmentOption.click();
                }

                // Submit bin dialog
                await e2ePage.locator(BIN_LOCATION_PAGE.BIN_DIALOG_SUBMIT_BUTTON).click();
                await e2ePage.waitForTimeout(TIMEOUTS.SHORT);
            }

            await allure.attachment('Binned Unit', JSON.stringify(firstUnit, null, 2), 'application/json');
            await allure.attachment('Bin Location', tc.binLocation, 'text/plain');
        });

        // Validate BINASSIGN table
        await allure.step('Validate BINASSIGN table in DB', async () => {
            const awbsSql = formatAwbsForSql(generatedAwbs);
            const binQuery = dbQueries.binassign_by_awbs.replace('${awbs}', awbsSql);
            const binData = await executeQuery(binQuery, 3, TIMEOUTS.V_SHORT);

            await allure.attachment('BINASSIGN DB Data', JSON.stringify(binData, null, 2), 'application/json');
            expect(binData.length, 'BINASSIGN record should exist after binning').toBeGreaterThan(0);

            // Validate specific fields
            const binRecord = binData[0];
            const binLocation = String(binRecord.binlocation || binRecord.BINLOCATION);
            const splitFlag = String(binRecord.isunitsplitflag || binRecord.ISUNITSPLITFLAG);

            expect.soft(binLocation).toBe(tc.binLocation);
            expect.soft(splitFlag).toBe(tc.expectedSplitFlag);
        });
    });

    test(`[TC_BIN_E2E_010] ${e2eTests.TC_BIN_E2E_010.title}`, { tag: ['@e2e', '@binning', '@split'] }, async () => {
        const tc = e2eTests.TC_BIN_E2E_010;
        await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
        await allure.severity('critical');

        // This test needs a fresh flight with unbinned units
        // Navigate back to search and re-enter flight
        await allure.step('Navigate back and search for flight with splittable units', async () => {
            // Check if we're on assignment page, if so exit
            const exitBtn = e2ePage.locator(BIN_LOCATION_PAGE.EXIT_BUTTON);
            if (await exitBtn.isVisible()) {
                await e2eBinLocationPage.clickExit();
                await e2ePage.waitForTimeout(TIMEOUTS.SHORT);
            }

            const flightDate = resolveDate('${date|MM/DD/YYYY|+0}');
            await enterDateAndWait(e2eBinLocationPage, e2ePage, flightDate);

            const flightOptions = await e2eBinLocationPage.getFlightNumberOptions();
            const matchingFlight = flightOptions.find(o => o.text.includes(tc.flightNumber));
            if (matchingFlight) {
                await e2eBinLocationPage.selectFlightNumber(matchingFlight.text);
            }

            const originOptions = await e2eBinLocationPage.getOriginOptions();
            const matchingOrigin = originOptions.find(o => o.text.includes(tc.origin));
            if (matchingOrigin) {
                await e2eBinLocationPage.selectOrigin(matchingOrigin.text);
            }

            await e2eBinLocationPage.clickSubmit();
            await e2ePage.waitForTimeout(TIMEOUTS.SHORT);

            if (await e2eBinLocationPage.isLockdownDialogVisible()) {
                await e2eBinLocationPage.unlockFlight();
                await e2ePage.waitForTimeout(TIMEOUTS.SHORT);
            }
        });

        await allure.step('Select SPLIT radio and assign partial pieces', async () => {
            const tableData = await e2eBinLocationPage.getAssignmentTableData();
            if (tableData.length === 0) {
                test.skip(true, 'No units available for split binning');
                return;
            }

            // Find a unit with enough pieces to split
            const splittableUnit = tableData.find(u => parseInt(u.totalPcs) >= tc.partialPieces);
            if (!splittableUnit) {
                test.skip(true, 'No unit with enough pieces for split');
                return;
            }

            // Click SPLIT radio
            await e2eBinLocationPage.selectSplitForUnit(splittableUnit.unitId);
            await e2ePage.waitForTimeout(500);

            // Click Add New Bin
            await e2eBinLocationPage.clickAddNewBin();
            await e2ePage.waitForTimeout(TIMEOUTS.SHORT);

            // Fill bin dialog
            const binInput = e2ePage.locator(BIN_LOCATION_PAGE.BIN_LOCATION_INPUT);
            if (await binInput.isVisible()) {
                await binInput.fill(tc.binLocation);

                const compartmentOption = e2ePage.locator(`option:has-text("${tc.compartment}")`);
                if (await compartmentOption.isVisible()) {
                    await compartmentOption.click();
                }

                await e2ePage.locator(BIN_LOCATION_PAGE.BIN_DIALOG_SUBMIT_BUTTON).click();
                await e2ePage.waitForTimeout(TIMEOUTS.SHORT);
            }

            await allure.attachment('Split Unit', JSON.stringify(splittableUnit, null, 2), 'application/json');
            await allure.attachment('Partial Pieces', String(tc.partialPieces), 'text/plain');
        });

        // Validate BINASSIGN for split
        await allure.step('Validate BINASSIGN for split bin entry', async () => {
            const awbsSql = formatAwbsForSql(generatedAwbs);
            const binQuery = dbQueries.binassign_by_awbs.replace('${awbs}', awbsSql);
            const binData = await executeQuery(binQuery, 3, TIMEOUTS.V_SHORT);

            await allure.attachment('BINASSIGN DB Data (Split)', JSON.stringify(binData, null, 2), 'application/json');

            // Find the split record
            const splitRecord = binData.find(r => {
                const loc = String(r.binlocation || r.BINLOCATION);
                return loc === tc.binLocation;
            });

            if (splitRecord) {
                const splitFlag = String(splitRecord.isunitsplitflag || splitRecord.ISUNITSPLITFLAG);
                expect.soft(splitFlag).toBe(tc.expectedSplitFlag);
            }
        });
    });
});


/* ============================================================================================
 *  SECTION 3: MULTI-XSDG E2E TEST
 * ============================================================================================ */

test.describe('Bin Location Assignment - Multi-XSDG E2E', () => {

    test(`[TC_BIN_E2E_015] ${e2eTests.TC_BIN_E2E_015.title}`, { tag: ['@e2e', '@multi-xsdg'] }, async () => {
        const tc = e2eTests.TC_BIN_E2E_015;
        await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
        await allure.severity('critical');
        await allure.description(tc.description);

        // Generate 2 AWBs
        const awb1 = generateAwb();
        const awb2 = generateAwb();
        const multiAwbs = { '${awb1}': awb1, '${awb2}': awb2 };

        // Build 2 XSDG XMLs
        const xsdg1 = buildXsdgXml(e2eTests.xsdg_xml_template, awb1, tc.flightNumber, tc.origin, tc.destination);
        const xsdg2 = buildXsdgXml(e2eTests.multi_xsdg_xml_template_2, awb2, tc.flightNumber, tc.origin, tc.destination);

        // Build multi-AWB NTM
        let multiNtm = e2eTests.multi_ntm_template;
        multiNtm = multiNtm.replaceAll('${awb1}', awb1);
        multiNtm = multiNtm.replaceAll('${awb2}', awb2);
        multiNtm = multiNtm.replaceAll('${flightNumber}', tc.flightNumber);
        multiNtm = multiNtm.replaceAll('${origin}', tc.origin);
        multiNtm = multiNtm.replaceAll('${destination}', tc.destination);
        multiNtm = replaceDatePlaceholders(multiNtm, timezone);

        await allure.attachment('Multi-AWBs', JSON.stringify(multiAwbs, null, 2), 'application/json');
        await allure.attachment('XSDG 1', xsdg1, 'text/xml');
        await allure.attachment('XSDG 2', xsdg2, 'text/xml');
        await allure.attachment('Multi NTM', multiNtm, 'text/plain');

        // Post via Legacy Interface
        await allure.step('Post 2 XSDGs + NTM via Legacy Interface', async () => {
            await postXsdgAndNtmViaLegacyApp([xsdg1, xsdg2], multiNtm);
        });

        // Navigate to AutoNOTOC and verify
        let multiPage;
        try {
            await allure.step('Verify all units appear in UI', async () => {
                multiPage = await BrowserHelpers.launchBrowser();
                const loginPage = new AutoNotocLoginPage(multiPage);
                await loginPage.login(
                    getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_USERNAME),
                    getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_PASSWORD)
                );
                await loginPage.navigateToBinLocationAssignment();
                const multiBinPage = new BinLocationAssignPage(multiPage);

                const flightDate = resolveDate('${date|MM/DD/YYYY|+0}');
                await enterDateAndWait(multiBinPage, multiPage, flightDate);

                const flightOptions = await multiBinPage.getFlightNumberOptions();
                const matchingFlight = flightOptions.find(o => o.text.includes(tc.flightNumber));
                expect(matchingFlight).toBeTruthy();

                if (matchingFlight) {
                    await multiBinPage.selectFlightNumber(matchingFlight.text);
                }

                const originOptions = await multiBinPage.getOriginOptions();
                const matchingOrigin = originOptions.find(o => o.text.includes(tc.origin));
                if (matchingOrigin) {
                    await multiBinPage.selectOrigin(matchingOrigin.text);
                }

                await multiBinPage.clickSubmit();
                await multiPage.waitForTimeout(TIMEOUTS.SHORT);

                if (await multiBinPage.isLockdownDialogVisible()) {
                    await multiBinPage.unlockFlight();
                    await multiPage.waitForTimeout(TIMEOUTS.SHORT);
                }

                // Verify multiple units appear
                const rowCount = await multiBinPage.getAssignmentRowCount();
                expect(rowCount).toBeGreaterThanOrEqual(tc.xsdgCount);

                const tableData = await multiBinPage.getAssignmentTableData();
                await allure.attachment('Multi-XSDG Assignment Table', JSON.stringify(tableData, null, 2), 'application/json');
            });

            // Validate DB
            await allure.step('Validate UNITASSIGN has records for both AWBs', async () => {
                const awbsSql = formatAwbsForSql(multiAwbs);
                const unitQuery = dbQueries.unitassign_by_awbs.replace('${awbs}', awbsSql);
                const dbData = await executeQuery(unitQuery, 3, TIMEOUTS.V_SHORT);

                await allure.attachment('UNITASSIGN Multi-AWB', JSON.stringify(dbData, null, 2), 'application/json');
                expect(dbData.length).toBeGreaterThanOrEqual(tc.xsdgCount);
            });
        } finally {
            if (multiPage) {
                await multiPage.context().browser().close();
            }
        }
    });
});
