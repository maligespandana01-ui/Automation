/**
 * @charset UTF-8
 * Binning E2E Test Suite — Full/Split/Delete/Change Bin + Departed Flight Scenarios
 *
 * Flow per test case:
 * 1. Read flight data from CSV (flight date, number, origin, destination)
 * 2. Generate unique AWB + UNID (origin prefix + random digits)
 * 3. Replace placeholders in XSDG and NTM templates
 * 4. Post XSDG + NTM via Legacy Interface App
 * 5. Login to AutoNOTOC UI → Navigate to Bin Location Assignment
 * 6. Fill flight details (auto-populate cross-verification)
 * 7. Click Submit → Handle popup (Condition 1 or 2)
 * 8. Perform binning operation (ALL / SPLIT / DELETE / CHANGE BIN)
 * 9. Validate UI info vs DB shipper tables (UNITASSIGN, BINASSIGN, SFI)
 * 10. Assert expected behaviors
 */
import { test, expect } from '@playwright/test';
import fs from 'fs';
import path from 'path';
import * as allure from 'allure-js-commons';
import { BrowserHelpers } from '../../../utils/helpers/BrowserHelpers.js';
import { AutoNotocLoginPage } from '../../../pages/ui/autonotoc/AutoNotocLoginPage.js';
import { BinLocationAssignPage, BIN_LOCATION_PAGE } from '../../../pages/ui/autonotoc/BinLocationAssignPage.js';
import { LoginPage } from '../../../pages/ui/notoc_legacy/LoginPage.js';
import { NtmXsdgMessagesPostingPage, NTM_XSDG_MESSAGES_POSTING_PAGE } from '../../../pages/ui/notoc_legacy/NtmXsdgMessagesPostingPage.js';
import { ENV_CONFIG_KEYS, TIMEOUTS } from '../../../utils/constants/Constants.js';
import { getEnvVariable } from '../../../utils/config/EnvLoader.js';
import { executeQuery } from '../../../utils/helpers/database.js';
import { generateAwb } from '../../../utils/helpers/awbUtils.js';
import { replaceDatePlaceholders } from '../../../utils/helpers/DateUtils.js';
import { Logger } from '../../../utils/helpers/Logger.js';
import {
    generateUnid,
    getRandomBinLocation,
    getDifferentBinLocation,
    resolveXsdgTemplate,
    resolveNtmTemplate,
    readFlightDataCsv,
    fetchFlightDetailsFromTestData,
} from '../../../utils/helpers/BinningHelpers.js';
import {
    formatAwbsForSql,
    getUnitAssignData,
    getBinAssignData,
    getShipperFlightInfo,
    getAuditData,
    validateUnitAssign,
    validateBinAssign,
    validateBinDeletion,
    validateShipperFlightInfo,
    crossValidateUiVsDb,
    runFullDbValidation,
} from '../../../utils/helpers/BinningDbValidator.js';

/* ==================== LOAD TEST DATA ==================== */
const testDataPath = path.join(process.cwd(), 'data', 'test_data', 'autonotoc', 'binning_e2e_test_data.json');
const testData = JSON.parse(fs.readFileSync(testDataPath, 'utf-8'));
const testCases = testData.test_cases;
const expectedBehaviors = testData.expected_behaviors;
const dbQueries = testData.db_queries;
const xsdgTemplate = testData.xsdg_xml_template;
const ntmTemplate = testData.ntm_template;

/* ==================== FLIGHT DATA CSV ==================== */
const csvPath = path.join(process.cwd(), 'data', 'test_data', 'autonotoc', 'binning_flights.csv');

/* ==================== TIMEZONE ==================== */
const timezone = getEnvVariable('DEFAULT_TIMEZONE') || 'America/Chicago';

/* ==================== HELPER: resolve date placeholders ==================== */
function resolveDate(template) {
    if (!template || !template.includes('${date')) return template;
    return replaceDatePlaceholders(template, timezone);
}

/* ==================== HELPER: post XSDG + NTM via Legacy Interface ==================== */
async function postXsdgAndNtmViaLegacyApp(xsdgXml, ntmMessage) {
    const legacyPage = await BrowserHelpers.launchBrowser();
    try {
        const loginPage = new LoginPage(legacyPage);
        await loginPage.loginToNotocInterfaceApp(
            getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_USERNAME),
            getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_PASSWORD)
        );
        const ntmXsdgPage = new NtmXsdgMessagesPostingPage(legacyPage);
        await ntmXsdgPage.refreshPageUntilProperlyLoaded();

        // Post XSDG
        await allure.step('Post XSDG message via Legacy Interface', async () => {
            await legacyPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_XSDG_MESSAGE_HYPERLINK).click();
            await legacyPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.XSDG_MESSAGE_TEXTAREA).fill(xsdgXml, { timeout: TIMEOUTS.LONG });
            await legacyPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_TO_MQ_BUTTON).click();
            await legacyPage.waitForTimeout(500);
            await legacyPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_ONE_MORE_MESSAGE_BUTTON).click({ timeout: TIMEOUTS.LONG });
            await allure.attachment('XSDG Posted', xsdgXml, 'text/xml');
        });

        // Post NTM
        await allure.step('Post NTM message via Legacy Interface', async () => {
            await legacyPage.goto(getEnvVariable(ENV_CONFIG_KEYS.URL_AUTONOTOC_LEGACY_INTERFACEAPP_STAGE));
            await legacyPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_NTM_MESSAGE_HYPERLINK).click();
            await legacyPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.NTM_MESSAGE_TEXTAREA).waitFor({ timeout: TIMEOUTS.LONG });
            await legacyPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.NTM_MESSAGE_TEXTAREA).fill(ntmMessage, { timeout: TIMEOUTS.LONG });
            await legacyPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_TO_MQ_BUTTON).click();
            await legacyPage.waitForTimeout(500);
            await legacyPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_ONE_MORE_MESSAGE_BUTTON).waitFor({ state: 'visible', timeout: TIMEOUTS.LONG });
            await legacyPage.locator(NTM_XSDG_MESSAGES_POSTING_PAGE.POST_ONE_MORE_MESSAGE_BUTTON).click();
            await allure.attachment('NTM Posted', ntmMessage, 'text/plain');
        });

        // Wait for message processing
        await new Promise(resolve => setTimeout(resolve, testData.test_config.xsdg_posting_wait_ms));
    } finally {
        await legacyPage.context().browser().close();
    }
}

/* ==================== HELPER: login and navigate to binning screen ==================== */
async function loginAndNavigateToBinning() {
    const page = await BrowserHelpers.launchBrowser();
    const loginPage = new AutoNotocLoginPage(page);
    await loginPage.login(
        getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_USERNAME),
        getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_PASSWORD)
    );
    await loginPage.navigateToBinLocationAssignment();
    const binPage = new BinLocationAssignPage(page);
    return { page, binPage };
}

/* ==================== HELPER: fill flight details and cross-verify ==================== */
async function fillFlightDetailsAndVerify(binPage, page, flightDetails) {
    await allure.step('Fill flight details on UI and cross-verify auto-population', async () => {
        const { flightDate, flightNumber, origin, destination } = flightDetails;

        // Enter flight date
        const dateInput = page.locator(BIN_LOCATION_PAGE.FLIGHT_DATE_INPUT);
        await dateInput.fill('');
        await dateInput.fill(flightDate);
        await page.keyboard.press('Tab');
        await page.waitForTimeout(TIMEOUTS.V_SHORT);

        // Verify flight appears in dropdown and select it
        const flightOptions = await binPage.getFlightNumberOptions();
        const matchingFlight = flightOptions.find(o => o.text.includes(flightNumber));
        expect(matchingFlight, `Flight ${flightNumber} should appear in dropdown`).toBeTruthy();
        if (matchingFlight) {
            await binPage.selectFlightNumber(matchingFlight.text);
            await allure.attachment('Selected Flight', matchingFlight.text, 'text/plain');
        }

        // Verify origin in dropdown and select it
        const originOptions = await binPage.getOriginOptions();
        const matchingOrigin = originOptions.find(o => o.text.includes(origin));
        expect(matchingOrigin, `Origin ${origin} should appear in dropdown`).toBeTruthy();
        if (matchingOrigin) {
            await binPage.selectOrigin(matchingOrigin.text);
            await allure.attachment('Selected Origin', matchingOrigin.text, 'text/plain');
        }
        await page.waitForTimeout(1000);

        // Cross-verify destination auto-population
        const destValue = await binPage.getDestination();
        await allure.step(`Destination auto-populated: ${destValue} (expected: ${destination})`, async () => {
            expect.soft(destValue).toBe(destination);
            await allure.attachment('Destination Value', destValue, 'text/plain');
        });

        await allure.attachment('Flight Details', JSON.stringify(flightDetails), 'application/json');
    });
}

/* ==================== HELPER: submit and handle popup ==================== */
async function submitAndHandlePopup(binPage, page, desiredAction = 'unlock') {
    return await allure.step(`Submit and handle popup (desired action: ${desiredAction})`, async () => {
        await binPage.clickSubmit();
        await page.waitForTimeout(TIMEOUTS.SHORT);

        const condition = await binPage.detectLockdownCondition();
        await allure.attachment('Popup Condition', condition, 'text/plain');

        if (condition !== 'none') {
            Logger.info('Binning', `Lockdown popup detected: ${condition}`);
            const message = await binPage.getLockdownDialogMessage();
            await allure.attachment('Popup Message', message, 'text/plain');

            await binPage.handleLockdownPopup(desiredAction);
            await page.waitForTimeout(TIMEOUTS.SHORT);
        } else {
            Logger.info('Binning', 'No lockdown popup — proceeding directly to bin screen');
        }

        return condition;
    });
}

/* ==================== HELPER: validate UI table vs DB ==================== */
async function validateUiVsDb(binPage, awb, dbQueries) {
    return await allure.step('Validate UI assignment table vs DB shipper tables', async () => {
        // Get UI data
        const uiTableData = await binPage.getAssignmentTableData();
        await allure.attachment('UI Assignment Table', JSON.stringify(uiTableData, null, 2), 'application/json');

        // Get DB data
        const awbsSql = formatAwbsForSql([awb]);
        const unitAssign = await getUnitAssignData(awbsSql, dbQueries);
        const binAssign = await getBinAssignData(awbsSql, dbQueries);
        const sfi = await getShipperFlightInfo(awbsSql, dbQueries);

        await allure.attachment('DB UNITASSIGN', JSON.stringify(unitAssign, null, 2), 'application/json');
        await allure.attachment('DB BINASSIGN', JSON.stringify(binAssign, null, 2), 'application/json');
        await allure.attachment('DB SFI', JSON.stringify(sfi, null, 2), 'application/json');

        // Cross-validate UI vs DB
        const crossResults = crossValidateUiVsDb(uiTableData, unitAssign);
        await allure.attachment('Cross-Validation Results', JSON.stringify(crossResults, null, 2), 'application/json');

        for (const r of crossResults) {
            expect.soft(r.match, `${r.field}: UI=${r.uiValue}, DB=${r.dbValue}`).toBe(true);
        }

        return { uiTableData, unitAssign, binAssign, sfi };
    });
}


/* ============================================================================================
 *  TEST SUITE: Binning E2E — 6 Test Cases
 * ============================================================================================ */

test.describe('Binning E2E — Full/Split/Delete/ChangeBin/Departed', () => {

    /* ==================== TC_BIN_01: Full Binning (All Pieces) ==================== */
    test('[TC_BIN_01] Full Binning - All pieces to single bin', {
        tag: ['@e2e', '@binning', '@full'],
    }, async () => {
        const tc = testCases.TC_BIN_01;
        await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
        await allure.severity(tc.severity);
        await allure.description(tc.description);

        // Step 1: Generate AWB and UNID
        const awb = generateAwb();
        const unid = generateUnid(tc.origin);
        await allure.attachment('Generated AWB', awb, 'text/plain');
        await allure.attachment('Generated UNID', unid, 'text/plain');

        // Step 2: Build XSDG and NTM from templates with flight data
        const flightDetails = fetchFlightDetailsFromTestData(tc, timezone);
        const xsdgXml = resolveXsdgTemplate(xsdgTemplate, {
            awb, flightNumber: tc.flightNumber, origin: tc.origin, destination: tc.destination,
        }, timezone);
        const ntmMessage = resolveNtmTemplate(ntmTemplate, {
            awb, flightNumber: tc.flightNumber, origin: tc.origin, destination: tc.destination,
        }, timezone);

        await allure.attachment('XSDG XML', xsdgXml, 'text/xml');
        await allure.attachment('NTM Message', ntmMessage, 'text/plain');

        // Step 3: Post XSDG + NTM via Legacy Interface
        await postXsdgAndNtmViaLegacyApp(xsdgXml, ntmMessage);

        // Step 4: Login to AutoNOTOC and navigate to binning
        const { page, binPage } = await loginAndNavigateToBinning();

        try {
            // Step 5: Fill flight details and cross-verify auto-population
            await fillFlightDetailsAndVerify(binPage, page, flightDetails);

            // Step 6: Click Submit and handle popup
            const condition = await submitAndHandlePopup(binPage, page, 'unlock');
            if (condition === 'condition1') {
                Logger.info('TC_BIN_01', 'Condition 1: Flight info not from OpsHub — unlocked');
            }

            // Step 7: Perform ALL pieces binning with random bin location
            const { binLocation, compartment } = getRandomBinLocation();
            const tableData = await binPage.getAssignmentTableData();
            expect(tableData.length, 'Assignment table should have units').toBeGreaterThan(0);
            const firstUnit = tableData[0];

            const binResult = await binPage.performFullBinning(firstUnit.unitId, binLocation, compartment);
            await allure.attachment('Binning Result', JSON.stringify(binResult, null, 2), 'application/json');

            // Step 8: Validate UI vs DB
            const { unitAssign, binAssign, sfi } = await validateUiVsDb(binPage, awb, dbQueries);

            // Step 9: Assert expected behavior
            await allure.step('Assert expected behavior: ALL pieces binning', async () => {
                const baResults = validateBinAssign(binAssign, {
                    awb, binLocation, splitFlag: tc.expectedSplitFlag,
                });
                await allure.attachment('BINASSIGN Validation', JSON.stringify(baResults, null, 2), 'application/json');
                for (const r of baResults) {
                    expect.soft(r.match, `BINASSIGN ${r.field}: expected=${r.expected}, actual=${r.actual}`).toBe(true);
                }

                const sfiResults = validateShipperFlightInfo(sfi, {
                    awb, flightNumber: tc.flightNumber, origin: tc.origin, destination: tc.destination,
                });
                await allure.attachment('SFI Validation', JSON.stringify(sfiResults, null, 2), 'application/json');
                for (const r of sfiResults) {
                    expect.soft(r.match, `SFI ${r.field}: expected=${r.expected}, actual=${r.actual}`).toBe(true);
                }
            });

        } finally {
            await page.context().browser().close();
        }
    });


    /* ==================== TC_BIN_02: Split Binning (Partial Pieces) ==================== */
    test('[TC_BIN_02] Split Binning - Partial pieces to bin', {
        tag: ['@e2e', '@binning', '@split'],
    }, async () => {
        const tc = testCases.TC_BIN_02;
        await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
        await allure.severity(tc.severity);
        await allure.description(tc.description);

        const awb = generateAwb();
        const unid = generateUnid(tc.origin);
        await allure.attachment('Generated AWB', awb, 'text/plain');
        await allure.attachment('Generated UNID', unid, 'text/plain');

        const flightDetails = fetchFlightDetailsFromTestData(tc, timezone);
        const xsdgXml = resolveXsdgTemplate(xsdgTemplate, {
            awb, flightNumber: tc.flightNumber, origin: tc.origin, destination: tc.destination,
        }, timezone);
        const ntmMessage = resolveNtmTemplate(ntmTemplate, {
            awb, flightNumber: tc.flightNumber, origin: tc.origin, destination: tc.destination,
        }, timezone);

        await postXsdgAndNtmViaLegacyApp(xsdgXml, ntmMessage);

        const { page, binPage } = await loginAndNavigateToBinning();

        try {
            await fillFlightDetailsAndVerify(binPage, page, flightDetails);

            const condition = await submitAndHandlePopup(binPage, page, 'unlock');
            if (condition === 'condition1') {
                Logger.info('TC_BIN_02', 'Condition 1: Flight info not from OpsHub — unlocked');
            }

            // Perform SPLIT binning
            const { binLocation, compartment } = getRandomBinLocation();
            const tableData = await binPage.getAssignmentTableData();
            expect(tableData.length, 'Assignment table should have units').toBeGreaterThan(0);

            const splittableUnit = tableData.find(u => parseInt(u.totalPcs) >= tc.partialPieces);
            expect(splittableUnit, `Unit with >= ${tc.partialPieces} pieces needed for split`).toBeTruthy();

            const binResult = await binPage.performSplitBinning(splittableUnit.unitId, binLocation, compartment);
            await allure.attachment('Split Binning Result', JSON.stringify(binResult, null, 2), 'application/json');

            // Validate UI vs DB
            const { binAssign, sfi } = await validateUiVsDb(binPage, awb, dbQueries);

            // Assert expected behavior
            await allure.step('Assert expected behavior: SPLIT pieces binning', async () => {
                const baResults = validateBinAssign(binAssign, {
                    awb, binLocation, splitFlag: tc.expectedSplitFlag,
                });
                await allure.attachment('BINASSIGN Validation', JSON.stringify(baResults, null, 2), 'application/json');
                for (const r of baResults) {
                    expect.soft(r.match, `BINASSIGN ${r.field}: expected=${r.expected}, actual=${r.actual}`).toBe(true);
                }

                const sfiResults = validateShipperFlightInfo(sfi, {
                    awb, flightNumber: tc.flightNumber, origin: tc.origin, destination: tc.destination,
                });
                for (const r of sfiResults) {
                    expect.soft(r.match, `SFI ${r.field}: expected=${r.expected}, actual=${r.actual}`).toBe(true);
                }
            });

        } finally {
            await page.context().browser().close();
        }
    });


    /* ==================== TC_BIN_03: Delete Binning ==================== */
    test('[TC_BIN_03] Delete Binning - Bin all then delete', {
        tag: ['@e2e', '@binning', '@delete'],
    }, async () => {
        const tc = testCases.TC_BIN_03;
        await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
        await allure.severity(tc.severity);
        await allure.description(tc.description);

        const awb = generateAwb();
        const unid = generateUnid(tc.origin);
        await allure.attachment('Generated AWB', awb, 'text/plain');
        await allure.attachment('Generated UNID', unid, 'text/plain');

        const flightDetails = fetchFlightDetailsFromTestData(tc, timezone);
        const xsdgXml = resolveXsdgTemplate(xsdgTemplate, {
            awb, flightNumber: tc.flightNumber, origin: tc.origin, destination: tc.destination,
        }, timezone);
        const ntmMessage = resolveNtmTemplate(ntmTemplate, {
            awb, flightNumber: tc.flightNumber, origin: tc.origin, destination: tc.destination,
        }, timezone);

        await postXsdgAndNtmViaLegacyApp(xsdgXml, ntmMessage);

        const { page, binPage } = await loginAndNavigateToBinning();

        try {
            await fillFlightDetailsAndVerify(binPage, page, flightDetails);
            await submitAndHandlePopup(binPage, page, 'unlock');

            // Step 5: First perform ALL pieces binning
            const { binLocation, compartment } = getRandomBinLocation();
            const tableData = await binPage.getAssignmentTableData();
            expect(tableData.length).toBeGreaterThan(0);
            const firstUnit = tableData[0];

            await binPage.performFullBinning(firstUnit.unitId, binLocation, compartment);

            // Step 6: Validate after initial binning
            await allure.step('Validate after initial full binning', async () => {
                const awbsSql = formatAwbsForSql([awb]);
                const binAssignBefore = await getBinAssignData(awbsSql, dbQueries);
                expect(binAssignBefore.length, 'BINASSIGN should exist after binning').toBeGreaterThan(0);
                await allure.attachment('BINASSIGN Before Delete', JSON.stringify(binAssignBefore, null, 2), 'application/json');
            });

            // Step 7: Delete binning
            await binPage.performDeleteBinning(firstUnit.unitId);

            // Step 8: Validate after deletion
            await allure.step('Validate after delete binning', async () => {
                const awbsSql = formatAwbsForSql([awb]);
                const binAssignAfter = await getBinAssignData(awbsSql, dbQueries);
                await allure.attachment('BINASSIGN After Delete', JSON.stringify(binAssignAfter, null, 2), 'application/json');

                const deleteResults = validateBinDeletion(binAssignAfter, awb, binLocation);
                await allure.attachment('Deletion Validation', JSON.stringify(deleteResults, null, 2), 'application/json');
                for (const r of deleteResults) {
                    expect.soft(r.match, `DELETE ${r.field}: expected=${r.expected}, actual=${r.actual}`).toBe(true);
                }
            });

        } finally {
            await page.context().browser().close();
        }
    });


    /* ==================== TC_BIN_04: Change Bin Location ==================== */
    test('[TC_BIN_04] Change Bin Location - Reassign to different bin', {
        tag: ['@e2e', '@binning', '@change'],
    }, async () => {
        const tc = testCases.TC_BIN_04;
        await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
        await allure.severity(tc.severity);
        await allure.description(tc.description);

        const awb = generateAwb();
        const unid = generateUnid(tc.origin);
        await allure.attachment('Generated AWB', awb, 'text/plain');
        await allure.attachment('Generated UNID', unid, 'text/plain');

        const flightDetails = fetchFlightDetailsFromTestData(tc, timezone);
        const xsdgXml = resolveXsdgTemplate(xsdgTemplate, {
            awb, flightNumber: tc.flightNumber, origin: tc.origin, destination: tc.destination,
        }, timezone);
        const ntmMessage = resolveNtmTemplate(ntmTemplate, {
            awb, flightNumber: tc.flightNumber, origin: tc.origin, destination: tc.destination,
        }, timezone);

        await postXsdgAndNtmViaLegacyApp(xsdgXml, ntmMessage);

        const { page, binPage } = await loginAndNavigateToBinning();

        try {
            await fillFlightDetailsAndVerify(binPage, page, flightDetails);
            await submitAndHandlePopup(binPage, page, 'unlock');

            // Step 5: First perform ALL pieces binning
            const initialBin = getRandomBinLocation();
            const tableData = await binPage.getAssignmentTableData();
            expect(tableData.length).toBeGreaterThan(0);
            const firstUnit = tableData[0];

            await binPage.performFullBinning(firstUnit.unitId, initialBin.binLocation, initialBin.compartment);

            // Step 6: Validate initial binning
            await allure.step('Validate initial binning', async () => {
                const awbsSql = formatAwbsForSql([awb]);
                const binAssignBefore = await getBinAssignData(awbsSql, dbQueries);
                expect(binAssignBefore.length).toBeGreaterThan(0);
                await allure.attachment('BINASSIGN Before Change', JSON.stringify(binAssignBefore, null, 2), 'application/json');
                await allure.attachment('Initial Bin Location', initialBin.binLocation, 'text/plain');
            });

            // Step 7: Change bin location to a different one
            const newBin = getDifferentBinLocation(initialBin.binLocation);
            await allure.attachment('New Bin Location', newBin.binLocation, 'text/plain');

            const changeResult = await binPage.performChangeBinLocation(firstUnit.unitId, newBin.binLocation, newBin.compartment);
            await allure.attachment('Change Result', JSON.stringify(changeResult, null, 2), 'application/json');

            // Step 8: Validate after change
            await allure.step('Validate after bin location change', async () => {
                const awbsSql = formatAwbsForSql([awb]);
                const binAssignAfter = await getBinAssignData(awbsSql, dbQueries);
                await allure.attachment('BINASSIGN After Change', JSON.stringify(binAssignAfter, null, 2), 'application/json');

                const baResults = validateBinAssign(binAssignAfter, {
                    awb, binLocation: newBin.binLocation, splitFlag: tc.expectedSplitFlag,
                });
                await allure.attachment('Change Validation', JSON.stringify(baResults, null, 2), 'application/json');
                for (const r of baResults) {
                    expect.soft(r.match, `CHANGE ${r.field}: expected=${r.expected}, actual=${r.actual}`).toBe(true);
                }
            });

        } finally {
            await page.context().browser().close();
        }
    });


    /* ==================== TC_BIN_05: Departed Flight — Cancel ==================== */
    test('[TC_BIN_05] Departed Flight - Cancel and change flight info', {
        tag: ['@e2e', '@binning', '@departed'],
    }, async () => {
        const tc = testCases.TC_BIN_05;
        await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
        await allure.severity(tc.severity);
        await allure.description(tc.description);

        const awb = generateAwb();
        const unid = generateUnid(tc.origin);
        await allure.attachment('Generated AWB', awb, 'text/plain');

        const flightDetails = fetchFlightDetailsFromTestData(tc, timezone);
        const xsdgXml = resolveXsdgTemplate(xsdgTemplate, {
            awb, flightNumber: tc.flightNumber, origin: tc.origin, destination: tc.destination,
        }, timezone);
        const ntmMessage = resolveNtmTemplate(ntmTemplate, {
            awb, flightNumber: tc.flightNumber, origin: tc.origin, destination: tc.destination,
        }, timezone);

        await postXsdgAndNtmViaLegacyApp(xsdgXml, ntmMessage);

        const { page, binPage } = await loginAndNavigateToBinning();

        try {
            await fillFlightDetailsAndVerify(binPage, page, flightDetails);

            // Click Submit
            await binPage.clickSubmit();
            await page.waitForTimeout(TIMEOUTS.SHORT);

            // Step 4: Detect popup condition
            const condition = await binPage.detectLockdownCondition();
            await allure.attachment('Popup Condition Detected', condition, 'text/plain');

            if (condition === 'condition2') {
                // Departed flight — select Cancel and change flight information
                await allure.step('Condition 2: Departed — selecting Cancel', async () => {
                    const message = await binPage.getLockdownDialogMessage();
                    await allure.attachment('Departed Flight Message', message, 'text/plain');
                    await binPage.cancelLockdownDialog();
                    await page.waitForTimeout(TIMEOUTS.SHORT);
                });
            } else if (condition === 'condition1') {
                // Not departed but no OpsHub info — also cancel for this test
                await allure.step('Condition 1: No OpsHub info — selecting Cancel', async () => {
                    await binPage.cancelLockdownDialog();
                    await page.waitForTimeout(TIMEOUTS.SHORT);
                });
            }
            // If no popup, test still continues

            // Step 5: Validate we are redirected to default binning search screen
            await allure.step('Validate redirect to default binning screen', async () => {
                const isOnSearch = await binPage.isOnSearchScreen();
                expect(isOnSearch, 'Should be redirected to default binning search screen').toBe(true);

                // Verify flight date input is visible
                const dateInput = page.locator(BIN_LOCATION_PAGE.FLIGHT_DATE_INPUT);
                await expect(dateInput).toBeVisible();

                await allure.attachment('On Search Screen', String(isOnSearch), 'text/plain');
            });

        } finally {
            await page.context().browser().close();
        }
    });


    /* ==================== TC_BIN_06: Departed Flight — View Bin Info ==================== */
    test('[TC_BIN_06] Departed Flight - View bin information', {
        tag: ['@e2e', '@binning', '@departed'],
    }, async () => {
        const tc = testCases.TC_BIN_06;
        await allure.displayName(`${tc.testCaseId} - ${tc.title}`);
        await allure.severity(tc.severity);
        await allure.description(tc.description);

        const awb = generateAwb();
        const unid = generateUnid(tc.origin);
        await allure.attachment('Generated AWB', awb, 'text/plain');

        const flightDetails = fetchFlightDetailsFromTestData(tc, timezone);
        const xsdgXml = resolveXsdgTemplate(xsdgTemplate, {
            awb, flightNumber: tc.flightNumber, origin: tc.origin, destination: tc.destination,
        }, timezone);
        const ntmMessage = resolveNtmTemplate(ntmTemplate, {
            awb, flightNumber: tc.flightNumber, origin: tc.origin, destination: tc.destination,
        }, timezone);

        await postXsdgAndNtmViaLegacyApp(xsdgXml, ntmMessage);

        const { page, binPage } = await loginAndNavigateToBinning();

        try {
            await fillFlightDetailsAndVerify(binPage, page, flightDetails);

            // Click Submit
            await binPage.clickSubmit();
            await page.waitForTimeout(TIMEOUTS.SHORT);

            // Step 4: Detect popup condition
            const condition = await binPage.detectLockdownCondition();
            await allure.attachment('Popup Condition Detected', condition, 'text/plain');

            if (condition === 'condition2') {
                // Departed flight — select View Bin Information
                await allure.step('Condition 2: Departed — selecting View Bin Info', async () => {
                    const message = await binPage.getLockdownDialogMessage();
                    await allure.attachment('Departed Flight Message', message, 'text/plain');
                    await binPage.viewBinInformation();
                    await page.waitForTimeout(TIMEOUTS.SHORT);
                });
            } else if (condition === 'condition1') {
                // Unlock and proceed
                await allure.step('Condition 1: No OpsHub info — unlocking to view bin info', async () => {
                    await binPage.unlockFlight();
                    await page.waitForTimeout(TIMEOUTS.SHORT);
                });
            }
            // If no popup, proceed to validate

            // Step 5: Validate bin information is displayed with correct data
            await allure.step('Validate bin information on screen matches DB', async () => {
                const tableVisible = await binPage.isAssignmentTableVisible();
                if (tableVisible) {
                    const { uiTableData, unitAssign, binAssign, sfi } = await validateUiVsDb(binPage, awb, dbQueries);

                    // SFI validation
                    const sfiResults = validateShipperFlightInfo(sfi, {
                        awb, flightNumber: tc.flightNumber, origin: tc.origin, destination: tc.destination,
                    });
                    await allure.attachment('SFI Validation', JSON.stringify(sfiResults, null, 2), 'application/json');
                    for (const r of sfiResults) {
                        expect.soft(r.match, `SFI ${r.field}: expected=${r.expected}, actual=${r.actual}`).toBe(true);
                    }
                } else {
                    // If table not visible, the flight might not have bin data yet
                    Logger.warn('TC_BIN_06', 'Assignment table not visible — flight may not have bin data');
                    await allure.attachment('Table Visible', 'false', 'text/plain');
                }
            });

        } finally {
            await page.context().browser().close();
        }
    });

});
