/**
 * @charset UTF-8
 * AI Validation Framework — EMERGENCY RESPONSE REPORT (ERR) RUNNER
 *
 * Validates the AutoNOTOC Emergency Response Report screen against the REAL
 * customer NTM (expected data) + XSDG (schema) using the GenAI framework.
 *
 * Reusable, NTM-driven search (Option B): the framework extracts the flight
 * search criteria (flight number, date, origin, destination) from the NTM and
 * passes them to the `navigate` hook below. The SAME hook works for ANY flight
 * / any screen that opens by flight — only the NTM/XSDG files change.
 *
 * ONE scenario file (emergency_response_report.yaml) covers MANY related test
 * cases via its `datasets:` list — each dataset runs as its own test below.
 * Override the scenario via the SCENARIO env var if needed:
 *   SCENARIO=ai-framework/configs/scenarios/emergency_response_report.yaml \
 *     npx playwright test tests/ai/err-validation.ai.spec.js
 *
 * Set LLM_API_URL / LLM_API_KEY / LLM_MODEL to use an LLM for semantic mapping;
 * otherwise rules + similarity are used.
 */
import { test, expect } from '@playwright/test';
import path from 'path';
import { BrowserHelpers } from '../../utils/helpers/BrowserHelpers.js';
import { AutoNotocLoginPage } from '../../pages/ui/autonotoc/AutoNotocLoginPage.js';
import { EmergencyResponseReportPage } from '../../pages/ui/autonotoc/EmergencyResponseReportPage.js';
import { getEnvVariable } from '../../utils/config/EnvLoader.js';
import { ENV_CONFIG_KEYS } from '../../utils/constants/Constants.js';
import { FrameworkRunner } from '../../ai-framework/engine/FrameworkRunner.js';
import { ScenarioLoader } from '../../ai-framework/engine/ScenarioLoader.js';

const DEFAULT_SCENARIO = 'ai-framework/configs/scenarios/emergency_response_report.yaml';
const SCENARIO_PATH = path.resolve(process.cwd(), process.env.SCENARIO || DEFAULT_SCENARIO);

// Each dataset (test case) declared in the scenario becomes its own test.
const DATASETS = ScenarioLoader.getDatasets(ScenarioLoader.load(SCENARIO_PATH));

/**
 * Flattens the rich ERR report object into a single { fieldName: value } map so
 * the AI mapping engine can match each value against the NTM/XSDG canonical
 * fields. Arrays (e.g. multiple hazmat rows / AWB groups) are indexed; the first
 * element is ALSO exposed under its plain leaf name for clean 1:1 mapping.
 * @param {Object} obj
 * @param {string} [prefix]
 * @param {Object} [out]
 * @returns {Object}
 */
function flattenReport(obj, prefix = '', out = {}) {
    if (obj == null) return out;
    if (Array.isArray(obj)) {
        obj.forEach((item, i) => {
            // First element also gets the plain (un-indexed) key for easy mapping.
            if (i === 0) flattenReport(item, prefix, out);
            flattenReport(item, prefix ? `${prefix}_${i + 1}` : String(i + 1), out);
        });
        return out;
    }
    if (typeof obj === 'object') {
        for (const [k, v] of Object.entries(obj)) {
            flattenReport(v, prefix ? `${prefix}.${k}` : k, out);
        }
        return out;
    }
    // Leaf value: store under the full dotted path AND its short leaf name.
    const leaf = prefix.includes('.') ? prefix.split('.').pop() : prefix;
    if (prefix) out[prefix] = obj;
    if (leaf && out[leaf] === undefined) out[leaf] = obj;
    return out;
}

/**
 * Builds one DG row per UN/ID for section-aware validation. Each hazmat row is
 * enriched with the box context it belongs to (ULD unit number + AWB), so each
 * UN/ID can be matched to its NTM/XSDG item and rendered as its own section.
 * Falls back to the flat hazmatRows list when no per-ULD boxes were detected.
 * @param {Object} report - Output of extractFullReportData().
 * @returns {Array<Object>}
 */
function buildDgRows(report) {
    const rows = [];
    const boxes = Array.isArray(report.boxes) ? report.boxes : [];
    for (const box of boxes) {
        for (const hz of box.hazmatRows || []) {
            rows.push({ ...hz, unitNum: box.unitNum || report.unitNumber || '', awbNumber: box.awbNumber || '' });
        }
    }
    if (!rows.length && Array.isArray(report.hazmatRows)) {
        for (const hz of report.hazmatRows) {
            rows.push({ ...hz, unitNum: report.unitNumber || '', awbNumber: '' });
        }
    }
    return rows;
}

test.describe('AI Validation Framework — Emergency Response Report', () => {
    DATASETS.forEach((dataset, index) => {
        test(`[AI_ERR_${String(index + 1).padStart(2, '0')}] Validate ERR UI against NTM + XSDG: ${dataset.name}`, {
            tag: ['@ai', '@validation', '@err'],
        }, async () => {
            let page;
            try {
                page = await BrowserHelpers.launchBrowser();

                // --- Login hook (AutoNOTOC) -------------------------------------
                const login = async (p) => {
                    const loginPage = new AutoNotocLoginPage(p);
                    await loginPage.login(
                        getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_USERNAME),
                        getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_PASSWORD)
                    );
                };

                // --- Navigate hook: REUSABLE NTM-driven flight search -----------
                // ctx.criteria = { flightNumber, flightDate, origin, destination }
                // is derived from the NTM by the framework — no hardcoded values.
                // Order: set date -> wait for flights to load -> flight -> origin.
                const navigate = async (p, ctx) => {
                    await login(p);
                    const errPage = new EmergencyResponseReportPage(p);
                    await errPage.navigateToEmergencyResponseReport();
                    await errPage.searchAndSubmit({
                        flightDate: ctx.criteria.flightDate,
                        flightNumber: ctx.criteria.flightNumber,
                        origin: ctx.criteria.origin,
                    });
                    await errPage.isReportVisible();
                };

                // --- Extract hook: rich ERR report -> flat map + DG rows --------
                // `rows` is one entry per UN/ID (hazmat row), enriched with its
                // box context (ULD + AWB), so the framework can validate the
                // report section-by-section (one section per UN/ID). `header`
                // carries the flight-info row for the header comparison.
                const extract = async (p) => {
                    const errPage = new EmergencyResponseReportPage(p);
                    const report = await errPage.extractFullReportData();
                    const flat = flattenReport(report);
                    const rows = buildDgRows(report);
                    return { fields: flat, flat, tables: report.hazmatRows || [], rows, header: report.flightInfo || {} };
                };

                const runner = new FrameworkRunner(SCENARIO_PATH, { page, login, navigate, extract, dataset });
                const { allPassed, summary } = await runner.run();

                expect(summary.total, 'at least one field should be validated').toBeGreaterThan(0);
                expect(allPassed, `Validation failures: ${summary.failed}/${summary.total}`).toBeTruthy();
            } finally {
                if (page) await page.context().browser()?.close().catch(() => {});
            }
        });
    });
});
