/**
 * @charset UTF-8
 * AI Validation Framework — GENERIC SCENARIO RUNNER
 *
 * Runs ANY scenario against the REAL application with ZERO code changes — you only
 * provide the scenario YAML (+ its NTM/XSDG files). Select the scenario via the
 * SCENARIO environment variable:
 *
 *   SCENARIO=ai-framework/configs/scenarios/emergency_response_report.yaml \
 *     npx playwright test tests/ai/ai-validation.ai.spec.js
 *
 * A `login` hook is supplied for AutoNOTOC; the generic Navigator drives the rest
 * of the navigation_steps declared in the scenario. To use an LLM for mapping,
 * set LLM_API_URL / LLM_API_KEY / LLM_MODEL (otherwise rules + similarity are used).
 */
import { test, expect } from '@playwright/test';
import path from 'path';
import { BrowserHelpers } from '../../utils/helpers/BrowserHelpers.js';
import { AutoNotocLoginPage } from '../../pages/ui/autonotoc/AutoNotocLoginPage.js';
import { getEnvVariable } from '../../utils/config/EnvLoader.js';
import { ENV_CONFIG_KEYS } from '../../utils/constants/Constants.js';
import { FrameworkRunner } from '../../ai-framework/engine/FrameworkRunner.js';

const DEFAULT_SCENARIO = 'ai-framework/configs/scenarios/emergency_response_report.yaml';
const SCENARIO_PATH = path.resolve(process.cwd(), process.env.SCENARIO || DEFAULT_SCENARIO);

test.describe('AI Validation Framework — Generic Scenario Runner', () => {
    test(`[AI_RUN_01] Validate UI against NTM + XSDG for scenario: ${path.basename(SCENARIO_PATH)}`, {
        tag: ['@ai', '@validation', '@generic'],
    }, async () => {
        let page;
        try {
            page = await BrowserHelpers.launchBrowser();

            // Login hook used when the scenario declares a `login` navigation step.
            const login = async (p) => {
                const loginPage = new AutoNotocLoginPage(p);
                await loginPage.login(
                    getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_USERNAME),
                    getEnvVariable(ENV_CONFIG_KEYS.AUTONOTOC_LEGACY_STAGE_PASSWORD)
                );
            };

            const runner = new FrameworkRunner(SCENARIO_PATH, { page, login });
            const { allPassed, summary } = await runner.run();

            expect(summary.total, 'at least one field should be validated').toBeGreaterThan(0);
            expect(allPassed, `Validation failures: ${summary.failed}/${summary.total}`).toBeTruthy();
        } finally {
            if (page) await page.context().browser()?.close().catch(() => {});
        }
    });
});
