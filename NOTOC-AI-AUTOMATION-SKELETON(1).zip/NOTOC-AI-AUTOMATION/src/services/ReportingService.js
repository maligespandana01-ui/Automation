// TODO: ReportingService
class ReportingService {}
module.exports=ReportingService;
