// TODO: NTMValidator
class NTMValidator {}
module.exports=NTMValidator;
