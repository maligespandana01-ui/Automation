// TODO: XMLValidator
class XMLValidator {}
module.exports=XMLValidator;
