// TODO: UIValidator
class UIValidator {}
module.exports=UIValidator;
