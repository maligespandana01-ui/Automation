// TODO: RewriteDBValidator
class RewriteDBValidator {}
module.exports=RewriteDBValidator;
