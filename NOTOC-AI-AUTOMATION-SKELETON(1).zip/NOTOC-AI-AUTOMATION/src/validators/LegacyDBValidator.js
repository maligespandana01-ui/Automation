// TODO: LegacyDBValidator
class LegacyDBValidator {}
module.exports=LegacyDBValidator;
