// TODO: PollingService
class PollingService {}
module.exports=PollingService;
