// TODO: LegacyRepository
class LegacyRepository {}
module.exports=LegacyRepository;
