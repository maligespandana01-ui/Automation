// TODO: RewriteRepository
class RewriteRepository {}
module.exports=RewriteRepository;
