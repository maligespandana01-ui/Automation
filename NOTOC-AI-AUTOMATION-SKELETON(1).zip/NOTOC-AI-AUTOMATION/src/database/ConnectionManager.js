// TODO: ConnectionManager
class ConnectionManager {}
module.exports=ConnectionManager;
