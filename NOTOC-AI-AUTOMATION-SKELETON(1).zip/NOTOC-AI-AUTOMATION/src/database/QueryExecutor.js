// TODO: QueryExecutor
class QueryExecutor {}
module.exports=QueryExecutor;
