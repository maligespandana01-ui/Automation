// TODO: FlightPage
class FlightPage {}
module.exports=FlightPage;
