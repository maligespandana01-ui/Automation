// TODO: BasePage
class BasePage {}
module.exports=BasePage;
