// TODO: LoginPage
class LoginPage {}
module.exports=LoginPage;
