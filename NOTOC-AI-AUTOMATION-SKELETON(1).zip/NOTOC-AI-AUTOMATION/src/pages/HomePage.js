// TODO: HomePage
class HomePage {}
module.exports=HomePage;
