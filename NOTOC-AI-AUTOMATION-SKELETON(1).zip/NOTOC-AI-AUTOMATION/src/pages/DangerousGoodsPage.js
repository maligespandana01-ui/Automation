// TODO: DangerousGoodsPage
class DangerousGoodsPage {}
module.exports=DangerousGoodsPage;
