// TODO: CanonicalJsonBuilder
class CanonicalJsonBuilder {}
module.exports=CanonicalJsonBuilder;
