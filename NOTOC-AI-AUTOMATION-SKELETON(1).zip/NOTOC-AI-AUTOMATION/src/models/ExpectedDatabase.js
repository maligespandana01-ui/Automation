const BaseModel=require('./BaseModel');
class ExpectedDatabase extends BaseModel{constructor(d={}){super();Object.assign(this,{unitAssign:{},binAssign:{},shipperInformation:{},shipperChecklist:{},shipperFlightInformation:{},rlNotificationSent:{},flightCache:{},flightStatus:{},shipperRadioNuclide:[],xsdgSrn:[]},d);}}
module.exports=ExpectedDatabase;
