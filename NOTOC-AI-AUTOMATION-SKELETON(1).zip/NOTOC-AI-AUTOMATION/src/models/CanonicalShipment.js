const BaseModel=require('./BaseModel');
class CanonicalShipment extends BaseModel{constructor(d={}){super();Object.assign(this,{testCaseId:'',flight:null,shipments:[],metadata:{},statistics:{}},d);} addShipment(s){this.shipments.push(s);}}
module.exports=CanonicalShipment;
