module.exports={
  Flight: require('./Flight'),
  Shipper: require('./Shipper'),
  Consignee: require('./Consignee'),
  DangerousGoods: require('./DangerousGoods'),
  Package: require('./Package'),
  RadioNuclide: require('./RadioNuclide'),
  OSI: require('./OSI'),
  NTMSection: require('./NTMSection'),
  Shipment: require('./Shipment'),
  CanonicalShipment: require('./CanonicalShipment'),
  ExpectedDatabase: require('./ExpectedDatabase'),
  TestCase: require('./TestCase'),
  BaseModel: require('./BaseModel')
};
