const BaseModel=require('./BaseModel');
class RadioNuclide extends BaseModel{constructor(d={}){super();Object.assign(this,{symbol:'',activityLevel:'',unit:''},d);}}
module.exports=RadioNuclide;
