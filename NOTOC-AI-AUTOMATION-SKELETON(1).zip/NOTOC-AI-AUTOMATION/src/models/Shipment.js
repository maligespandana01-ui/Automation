const BaseModel=require('./BaseModel');
class Shipment extends BaseModel{constructor(d={}){super();Object.assign(this,{awbNumber:'',airlineCode:'',flight:null,shipper:null,consignee:null,dangerousGoods:[],packages:[],ntmSection:null},d);}}
module.exports=Shipment;
