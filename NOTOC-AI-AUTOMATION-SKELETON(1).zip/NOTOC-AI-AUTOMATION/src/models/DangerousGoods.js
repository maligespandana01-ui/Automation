const BaseModel=require('./BaseModel');
class DangerousGoods extends BaseModel{constructor(d={}){super();Object.assign(this,{sequence:'',unNumber:'',hazardClass:'',properShippingName:'',radioNuclides:[]},d);} addRadioNuclide(r){this.radioNuclides.push(r);}}
module.exports=DangerousGoods;
