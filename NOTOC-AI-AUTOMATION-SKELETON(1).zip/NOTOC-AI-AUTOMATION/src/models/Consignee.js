const BaseModel=require('./BaseModel');
class Consignee extends BaseModel{constructor(d={}){super();this.name=d.name||'';this.address=d.address||{};}}
module.exports=Consignee;
