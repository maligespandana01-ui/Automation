const BaseModel=require('./BaseModel');
class NTMSection extends BaseModel{constructor(d={}){super();Object.assign(this,{dngLine:{},awbLine:{},properShippingName:'',osi:null},d);}}
module.exports=NTMSection;
