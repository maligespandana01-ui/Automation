const BaseModel=require('./BaseModel');
class Flight extends BaseModel{constructor(d={}){super();this.carrierCode=d.carrierCode||'';this.flightNumber=d.flightNumber||'';this.origin=d.origin||'';this.destination=d.destination||'';}}
module.exports=Flight;
