const BaseModel=require('./BaseModel');
class OSI extends BaseModel{constructor(d={}){super();Object.assign(this,{overPackGroup:'',barrowIndicator:'',sequence:'',cargoServiceType:'',commodityCode:''},d);}}
module.exports=OSI;
