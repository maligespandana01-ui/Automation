const BaseModel=require('./BaseModel');
class Package extends BaseModel{constructor(d={}){super();Object.assign(this,{sequence:'',quantity:'',packageType:'',levelCode:''},d);}}
module.exports=Package;
