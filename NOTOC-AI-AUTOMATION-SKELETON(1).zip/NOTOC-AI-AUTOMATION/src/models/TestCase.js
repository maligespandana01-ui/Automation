const BaseModel=require('./BaseModel');
class TestCase extends BaseModel{constructor(d={}){super();Object.assign(this,{id:'',xmlFiles:[],ntmFile:'',canonicalShipment:null},d);}}
module.exports=TestCase;
