class BaseModel {
  constructor(data={}){Object.assign(this,data);}
  validate(){return {valid:true,errors:[]};}
  toJSON(){return JSON.parse(JSON.stringify(this));}
}
module.exports=BaseModel;
