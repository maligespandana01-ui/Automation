const BaseModel=require('./BaseModel');
class Shipper extends BaseModel{constructor(d={}){super();this.name=d.name||'';this.address=d.address||{};}}
module.exports=Shipper;
