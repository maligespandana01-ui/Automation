// TODO: CanonicalMapper
class CanonicalMapper {}
module.exports=CanonicalMapper;
