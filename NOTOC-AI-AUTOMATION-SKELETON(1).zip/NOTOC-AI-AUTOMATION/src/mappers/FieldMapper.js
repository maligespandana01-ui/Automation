// TODO: FieldMapper
class FieldMapper {}
module.exports=FieldMapper;
