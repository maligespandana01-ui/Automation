// TODO: ValidationMapper
class ValidationMapper {}
module.exports=ValidationMapper;
