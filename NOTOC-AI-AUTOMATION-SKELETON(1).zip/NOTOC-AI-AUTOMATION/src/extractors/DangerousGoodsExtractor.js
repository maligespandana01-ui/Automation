// TODO: DangerousGoodsExtractor
class DangerousGoodsExtractor {}
module.exports=DangerousGoodsExtractor;
