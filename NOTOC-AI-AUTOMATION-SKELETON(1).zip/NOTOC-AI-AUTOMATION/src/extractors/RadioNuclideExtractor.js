// TODO: RadioNuclideExtractor
class RadioNuclideExtractor {}
module.exports=RadioNuclideExtractor;
