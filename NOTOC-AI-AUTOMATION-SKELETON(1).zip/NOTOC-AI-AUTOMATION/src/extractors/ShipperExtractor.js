// TODO: ShipperExtractor
class ShipperExtractor {}
module.exports=ShipperExtractor;
