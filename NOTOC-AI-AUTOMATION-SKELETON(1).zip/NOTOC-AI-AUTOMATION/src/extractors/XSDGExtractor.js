// TODO: XSDGExtractor
class XSDGExtractor {}
module.exports=XSDGExtractor;
