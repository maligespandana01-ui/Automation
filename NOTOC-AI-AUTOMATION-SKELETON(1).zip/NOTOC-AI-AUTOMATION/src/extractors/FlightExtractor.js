// TODO: FlightExtractor
class FlightExtractor {}
module.exports=FlightExtractor;
