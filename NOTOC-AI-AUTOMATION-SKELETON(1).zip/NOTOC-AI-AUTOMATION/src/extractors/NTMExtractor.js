// TODO: NTMExtractor
class NTMExtractor {}
module.exports=NTMExtractor;
