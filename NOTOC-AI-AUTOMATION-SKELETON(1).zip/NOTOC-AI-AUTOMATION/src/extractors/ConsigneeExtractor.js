// TODO: ConsigneeExtractor
class ConsigneeExtractor {}
module.exports=ConsigneeExtractor;
