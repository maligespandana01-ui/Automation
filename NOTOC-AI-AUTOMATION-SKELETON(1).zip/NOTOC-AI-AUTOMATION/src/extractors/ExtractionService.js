// TODO: ExtractionService
class ExtractionService {}
module.exports=ExtractionService;
