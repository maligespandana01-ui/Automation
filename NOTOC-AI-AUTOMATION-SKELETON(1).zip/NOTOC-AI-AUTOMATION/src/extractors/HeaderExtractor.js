// TODO: HeaderExtractor
class HeaderExtractor {}
module.exports=HeaderExtractor;
