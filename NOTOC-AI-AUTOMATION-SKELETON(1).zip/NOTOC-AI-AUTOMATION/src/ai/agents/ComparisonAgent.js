// TODO: ComparisonAgent
class ComparisonAgent {}
module.exports=ComparisonAgent;
