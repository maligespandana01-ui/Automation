// TODO: ReportAgent
class ReportAgent {}
module.exports=ReportAgent;
