// TODO: ExtractionAgent
class ExtractionAgent {}
module.exports=ExtractionAgent;
