// TODO: Implement XMLReader
class XMLReader{}
module.exports=XMLReader;
