// TODO
class XMLCache{}
module.exports=XMLCache;
