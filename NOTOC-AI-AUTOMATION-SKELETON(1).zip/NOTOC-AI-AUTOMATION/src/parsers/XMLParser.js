// TODO: Implement XMLParser
class XMLParser{}
module.exports=XMLParser;
