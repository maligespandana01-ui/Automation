// TODO
class NamespaceResolver{}
module.exports=NamespaceResolver;
