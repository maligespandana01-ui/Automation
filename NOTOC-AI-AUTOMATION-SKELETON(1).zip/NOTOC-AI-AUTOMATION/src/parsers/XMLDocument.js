// TODO: Implement XMLDocument
class XMLDocument{}
module.exports=XMLDocument;
