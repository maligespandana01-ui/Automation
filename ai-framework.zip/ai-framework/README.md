# AI-Driven UI Validation Framework

A reusable, **config-driven, GenAI-powered** automation framework that validates any
UI screen against structured backend data sources (**NTM** = data, **XSDG** = schema).

You add a **new scenario YAML + NTM + XSDG** — and it runs. **Zero code changes.**
No hardcoded locators, no hardcoded field names, no hardcoded mappings.

---

## What it does

```
Launch app → Navigate → Extract ALL UI fields → Load NTM + XSDG →
Merge schemas → AI-map fields → Strict validation → Business-friendly Allure report
```

- Extracts every visible field (forms, label/value pairs, key/value tables, data tables, nested panels).
- Loads **multiple NTM** and **multiple XSDG** files and merges them into one unified schema.
- Maps UI labels to source fields with a **3-level strategy** (exact → alias → AI semantic) and **confidence scores**.
- Validates with exact matching plus type/date awareness, and detects missing/extra fields.
- Produces an **Allure report for non-technical users** (plain language, PASS/FAIL badges, comparison tables, failure screenshots).
- **Learns** via mapping memory and **never breaks** when the LLM is offline (deterministic similarity fallback).

---

## Folder structure

```
ai-framework/
├── configs/
│   ├── scenarios/                 # one YAML per scenario (the ONLY thing you change)
│   │   ├── customer_demo.yaml         # offline, self-contained demo
│   │   ├── customer_validation.yaml   # illustrative template
│   │   └── emergency_response_report.yaml  # real-data wiring
│   └── mappings/
│       └── global_aliases.json    # reusable alias dictionary
├── data/
│   ├── NTM/<domain>/              # NTM data files (.json or telex .txt)
│   ├── XSDG/<domain>/             # XSDG schema files (.xml)
│   └── fixtures/                  # local demo screens (offline runs)
├── engine/
│   ├── ScenarioLoader.js          # YAML/JSON loader + ${ENV} expansion + validation
│   ├── DataSourceLoader.js        # loads/normalises NTM + XSDG (reuses NtmParser/XsdgParser)
│   ├── SchemaMerger.js            # unifies N XSDG, binds N NTM → expected rows
│   ├── Navigator.js               # generic, locator-free navigation
│   ├── UiExtractor.js             # generic DOM extraction → structured JSON
│   ├── McpClient.js               # LLM/MCP client (OpenAI-compatible) + fallback
│   ├── prompts/mappingPrompt.js   # AI mapping prompt templates
│   ├── MappingMemory.js           # persisted learned mappings
│   ├── AiMappingEngine.js         # 3-level mapping + confidence scoring
│   ├── ValidationEngine.js        # strict/type/date/missing/extra validation
│   ├── AllureReporter.js          # business-friendly report rendering
│   └── FrameworkRunner.js         # orchestrator (single entry point)
└── reports/                       # (Allure output lands in repo-root allure-results)

tests/ai/
├── ai-demo.ai.spec.js             # offline end-to-end demo (no app, no LLM)
└── ai-validation.ai.spec.js       # generic runner for real scenarios (SCENARIO=...)
```

---

## Quick start (offline demo — proves the whole engine)

```powershell
# from repo root
npx playwright test tests/ai/ai-demo.ai.spec.js
```

This runs against a local HTML fixture and intentionally surfaces **one mismatch**
(Account Balance 4999.00 vs expected 5000.00) so you can see PASS and FAIL rows.

Then open the report:

```powershell
node node_modules\allure-commandline\bin\allure generate allure-results --clean -o allure-report
node node_modules\allure-commandline\bin\allure open allure-report
```

---

## Run a real scenario (against the live app)

```powershell
$env:SCENARIO="ai-framework/configs/scenarios/emergency_response_report.yaml"
npx playwright test tests/ai/ai-validation.ai.spec.js
```

The spec supplies an AutoNOTOC `login` hook; the generic `Navigator` executes the
scenario's `navigation_steps`.

---

## Scenario configuration

```yaml
scenario_name: Customer Validation

application:
  url: "https://your-app.example.com"
  navigation_steps:
    - login
    - click: "Customer"
    - click: "Details"
    - waitFor: "Customer ID"

data_sources:
  ntm_files:  ["ai-framework/data/NTM/customer/ntm1.json"]
  xsdg_files: ["ai-framework/data/XSDG/customer/xsdg1.xml",
               "ai-framework/data/XSDG/customer/xsdg2.xml"]

mapping_strategy:
  type: "ai_semantic"          # ai_semantic | rules_only
  confidence_threshold: 0.85
  use_memory: true

validation:
  strict: true
  validate_types: true
  validate_dates: true
  detect_missing: true
  detect_extra: false
  ignore_fields: []

report:
  type: "allure"
  screenshots_on_failure: true

field_overrides:               # optional, win over global aliases
  "Member Since": "customerSince"
```

### Navigation steps supported
`login` · `{ goto }` · `{ click }` · `{ fill: { label, value } }` ·
`{ select: { label, value } }` · `{ press }` · `{ waitFor }` · `{ waitMs }`

---

## Multiple NTM / multiple XSDG

The engine handles all three relationships automatically:

| Case | NTM | XSDG | Behaviour |
|------|-----|------|-----------|
| 1 | 1 | 1 | Direct map + validate |
| 2 | 1 | N | XSDG schemas **unioned**; conflicts resolved (first non-empty wins, conflict recorded) |
| 3 | N | N | Every NTM record → an **expected row**; schemas unified; hierarchy preserved |

---

## AI mapping (3 levels + confidence)

1. **Exact** — normalised label equals canonical name (confidence 1.0)
2. **Alias** — `global_aliases.json` + scenario `field_overrides` (0.97)
3. **AI semantic** — LLM via MCP; **deterministic similarity fallback** if LLM is
   unavailable or below threshold.

Each mapping is scored:

```json
{ "ui_field": "Cust ID", "mapped_field": "Customer ID", "confidence": 0.91, "origin": "ai" }
```

Accepted mappings are remembered in `engine/.mapping-memory.json` and reused on
later runs (skips the LLM for known fields).

---

## Enabling the LLM / MCP

Set these environment variables (e.g. in `.env.nonprod`). See `.env.ai.example`.

```
LLM_API_URL=https://your-gateway/v1/chat/completions
LLM_API_KEY=sk-...
LLM_MODEL=gpt-4o-mini
HTTPS_PROXY=http://proxy:8080   # optional corporate proxy
```

Without these, the framework still runs fully using rules + similarity mapping.

---

## Why it is reusable & enterprise-grade

- **No code changes** to add a screen — only YAML + NTM + XSDG.
- **No hardcoded locators** — navigation & extraction are generic/accessibility-based.
- **No hardcoded mappings** — alias dictionary + AI + learned memory.
- **Resilient** — every external dependency (LLM, XSDG variant) has a fallback.
- **Reuses** the project's existing `NtmParser`, `XsdgParser`, `Logger`, and Allure setup.
