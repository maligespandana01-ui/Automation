/**
 * @charset UTF-8
 * ScenarioLoader - Loads and validates a YAML (or JSON) scenario configuration
 * that fully describes a UI-vs-data validation run.
 *
 * The scenario file is the ONLY thing a user must change to validate a brand-new
 * screen: it declares the application URL, navigation steps, the NTM data files,
 * the XSDG schema files, the mapping strategy, validation rules and report type.
 *
 * No locators, field names or mappings are hardcoded anywhere — everything that
 * is scenario-specific lives in the YAML.
 */
import fs from 'fs';
import path from 'path';
import yaml from 'js-yaml';
import { Logger } from '../../utils/helpers/Logger.js';

const COMPONENT = 'ScenarioLoader';

/**
 * @typedef {Object} ScenarioConfig
 * @property {string} scenario_name
 * @property {{ url: string, navigation_steps: Array<Object|string> }} application
 * @property {{ ntm_files: string[], xsdg_files: string[] }} data_sources
 * @property {{ type: string, confidence_threshold: number, use_memory?: boolean }} mapping_strategy
 * @property {{ strict: boolean, validate_types?: boolean, validate_dates?: boolean,
 *              detect_missing?: boolean, detect_extra?: boolean,
 *              ignore_fields?: string[], date_formats?: string[] }} validation
 * @property {{ type: string, screenshots_on_failure?: boolean }} report
 * @property {Object<string,string>} [field_overrides]
 */

export class ScenarioLoader {
    /**
     * Loads a scenario file (.yaml/.yml/.json), validates required sections and
     * resolves all relative data-source paths to absolute paths.
     * @param {string} scenarioPath - Absolute or workspace-relative path to scenario file.
     * @returns {ScenarioConfig}
     */
    static load(scenarioPath) {
        const abs = path.isAbsolute(scenarioPath)
            ? scenarioPath
            : path.resolve(process.cwd(), scenarioPath);

        if (!fs.existsSync(abs)) {
            throw new Error(`Scenario file not found: ${abs}`);
        }

        const raw = fs.readFileSync(abs, 'utf8');
        const ext = path.extname(abs).toLowerCase();
        /** @type {ScenarioConfig} */
        const cfg = ext === '.json' ? JSON.parse(raw) : yaml.load(raw);

        this._expandEnv(cfg);
        this._validate(cfg, abs);
        this._applyDefaults(cfg);
        this._resolvePaths(cfg);

        Logger.info(COMPONENT, `Loaded scenario "${cfg.scenario_name}"`, {
            datasets: this.getDatasets(cfg).length,
            strategy: cfg.mapping_strategy.type,
        });
        return cfg;
    }

    /**
     * Returns the list of datasets (test cases) declared by the scenario.
     * A single scenario file can cover MANY related cases via a `datasets:` list,
     * so you don't need one YAML per case. If only the legacy single-case
     * `data_sources` block is present, it is returned as a one-element list.
     * @param {ScenarioConfig} cfg
     * @returns {Array<{ name: string, ntm_files: string[], xsdg_files: string[] }>}
     */
    static getDatasets(cfg) {
        if (Array.isArray(cfg.datasets) && cfg.datasets.length) {
            return cfg.datasets.map((d, i) => ({
                name: d.name || `Case ${i + 1}`,
                ntm_files: d.ntm_files || [],
                xsdg_files: d.xsdg_files || [],
            }));
        }
        return [{
            name: cfg.scenario_name,
            ntm_files: cfg.data_sources?.ntm_files || [],
            xsdg_files: cfg.data_sources?.xsdg_files || [],
        }];
    }

    /**
     * Recursively expands ${ENV_VAR} placeholders in all string values using
     * process.env, so scenarios can reference environment-specific URLs/creds.
     * @param {any} node
     * @private
     */
    static _expandEnv(node) {
        if (node == null) return;
        if (Array.isArray(node)) {
            node.forEach((v, i) => {
                if (typeof v === 'string') node[i] = this._sub(v);
                else this._expandEnv(v);
            });
            return;
        }
        if (typeof node === 'object') {
            for (const [k, v] of Object.entries(node)) {
                if (typeof v === 'string') node[k] = this._sub(v);
                else this._expandEnv(v);
            }
        }
    }

    /** Substitutes ${VAR} tokens from process.env (leaves unknown vars untouched). @private */
    static _sub(str) {
        return str.replace(/\$\{([A-Z0-9_]+)\}/gi, (m, name) =>
            process.env[name] != null ? process.env[name] : m
        );
    }

    /**
     * Validates that mandatory sections and fields are present.
     * @param {ScenarioConfig} cfg
     * @param {string} src
     * @private
     */
    static _validate(cfg, src) {
        const missing = [];
        if (!cfg || typeof cfg !== 'object') throw new Error(`Empty/invalid scenario file: ${src}`);
        if (!cfg.scenario_name) missing.push('scenario_name');
        if (!cfg.application?.url) missing.push('application.url');
        // navigation_steps is optional: a screen-adapter navigate hook may own
        // navigation. If present, it must be an array.
        if (cfg.application?.navigation_steps != null && !Array.isArray(cfg.application.navigation_steps)) {
            missing.push('application.navigation_steps (must be a list)');
        }

        // Data sources can be declared EITHER as a single `data_sources` block
        // (one case) OR as a `datasets` list (many related cases in one file).
        const hasDatasets = Array.isArray(cfg.datasets) && cfg.datasets.length > 0;
        if (hasDatasets) {
            cfg.datasets.forEach((d, i) => {
                const tag = `datasets[${i}]${d?.name ? ` ("${d.name}")` : ''}`;
                if (!Array.isArray(d?.ntm_files) || d.ntm_files.length === 0) {
                    missing.push(`${tag}.ntm_files (at least one)`);
                }
                if (!Array.isArray(d?.xsdg_files) || d.xsdg_files.length === 0) {
                    missing.push(`${tag}.xsdg_files (at least one)`);
                }
            });
        } else {
            if (!Array.isArray(cfg.data_sources?.ntm_files) || cfg.data_sources.ntm_files.length === 0) {
                missing.push('data_sources.ntm_files (at least one) — or declare a datasets: list');
            }
            if (!Array.isArray(cfg.data_sources?.xsdg_files) || cfg.data_sources.xsdg_files.length === 0) {
                missing.push('data_sources.xsdg_files (at least one) — or declare a datasets: list');
            }
        }
        if (missing.length) {
            throw new Error(`Scenario "${src}" is missing required fields: ${missing.join(', ')}`);
        }
    }

    /**
     * Fills in sensible defaults so a minimal scenario file still runs.
     * @param {ScenarioConfig} cfg
     * @private
     */
    static _applyDefaults(cfg) {
        cfg.application.navigation_steps = cfg.application.navigation_steps || [];
        cfg.mapping_strategy = cfg.mapping_strategy || {};
        cfg.mapping_strategy.type = cfg.mapping_strategy.type || 'ai_semantic';
        cfg.mapping_strategy.confidence_threshold =
            cfg.mapping_strategy.confidence_threshold ?? 0.85;
        cfg.mapping_strategy.use_memory = cfg.mapping_strategy.use_memory ?? true;

        cfg.validation = cfg.validation || {};
        cfg.validation.strict = cfg.validation.strict ?? true;
        cfg.validation.validate_types = cfg.validation.validate_types ?? true;
        cfg.validation.validate_dates = cfg.validation.validate_dates ?? true;
        cfg.validation.detect_missing = cfg.validation.detect_missing ?? true;
        cfg.validation.detect_extra = cfg.validation.detect_extra ?? false;
        cfg.validation.ignore_fields = cfg.validation.ignore_fields || [];

        cfg.report = cfg.report || {};
        cfg.report.type = cfg.report.type || 'allure';
        cfg.report.screenshots_on_failure = cfg.report.screenshots_on_failure ?? true;

        cfg.field_overrides = cfg.field_overrides || {};
    }

    /**
     * Resolves NTM/XSDG relative paths to absolute paths against the workspace root.
     * @param {ScenarioConfig} cfg
     * @private
     */
    static _resolvePaths(cfg) {
        const toAbs = (p) => (path.isAbsolute(p) ? p : path.resolve(process.cwd(), p));
        const allFiles = [];

        if (cfg.data_sources) {
            cfg.data_sources.ntm_files = (cfg.data_sources.ntm_files || []).map(toAbs);
            cfg.data_sources.xsdg_files = (cfg.data_sources.xsdg_files || []).map(toAbs);
            allFiles.push(...cfg.data_sources.ntm_files, ...cfg.data_sources.xsdg_files);
        }
        if (Array.isArray(cfg.datasets)) {
            for (const d of cfg.datasets) {
                d.ntm_files = (d.ntm_files || []).map(toAbs);
                d.xsdg_files = (d.xsdg_files || []).map(toAbs);
                allFiles.push(...d.ntm_files, ...d.xsdg_files);
            }
        }

        const missingFiles = allFiles.filter((p) => !fs.existsSync(p));
        if (missingFiles.length) {
            Logger.warn(COMPONENT, 'Some declared data-source files do not exist', { missingFiles });
        }
    }
}
