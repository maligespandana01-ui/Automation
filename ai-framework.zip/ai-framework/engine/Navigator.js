/**
 * @charset UTF-8
 * Navigator - Executes the scenario's declarative navigation_steps generically,
 * with NO hardcoded locators. Steps are resolved by accessible text/role/label so
 * the same engine drives any application.
 *
 * Supported step forms (YAML):
 *   - "login"                         -> uses env credentials via the provided login hook
 *   - { goto: "https://..." }         -> navigate to URL
 *   - { click: "Customer" }           -> click element by visible text / role / label
 *   - { fill: { label: "User", value: "x" } }
 *   - { select: { label: "Type", value: "Gold" } }
 *   - { press: "Enter" }
 *   - { waitFor: "Details" }          -> wait for text to be visible
 *   - { waitMs: 1500 }
 */
import { Logger } from '../../utils/helpers/Logger.js';

const COMPONENT = 'Navigator';

export class Navigator {
    /**
     * @param {import('@playwright/test').Page} page
     * @param {{ login?: (page:any)=>Promise<void>, context?: Object }} [hooks]
     */
    constructor(page, hooks = {}) {
        this.page = page;
        this.hooks = hooks;
        // Flat context map used to resolve ${...} placeholders in step values
        // (e.g. ${ntm.flightNumber} from the parsed NTM search criteria).
        this.context = hooks.context || {};
    }

    /**
     * Runs every navigation step in order.
     * @param {Array<Object|string>} steps
     */
    async run(steps) {
        for (const step of steps) {
            await this._runStep(step);
        }
    }

    /** @private */
    async _runStep(step) {
        if (typeof step === 'string') {
            if (step === 'login') return this._login();
            return this._click(this._sub(step)); // bare string => click by text
        }
        const [action, rawArg] = Object.entries(step)[0];
        const arg = this._sub(rawArg);
        switch (action) {
            case 'login': return this._login();
            case 'goto': return this.page.goto(arg, { waitUntil: 'domcontentloaded' });
            case 'click': return this._click(arg);
            case 'fill': return this._fill(arg.label, arg.value);
            case 'select': return this._select(arg.label, arg.value);
            case 'press': return this.page.keyboard.press(arg);
            case 'waitFor': return this.page.getByText(arg, { exact: false }).first().waitFor({ state: 'visible' });
            case 'waitMs': return this.page.waitForTimeout(Number(arg));
            default:
                Logger.warn(COMPONENT, `Unknown navigation step "${action}" — skipped`);
        }
    }

    /**
     * Recursively substitutes ${path.to.value} placeholders from the context.
     * Supports dotted lookups, e.g. ${ntm.flightNumber}.
     * @param {any} value
     * @returns {any}
     * @private
     */
    _sub(value) {
        if (typeof value === 'string') {
            return value.replace(/\$\{([\w.]+)\}/g, (m, key) => {
                const resolved = this.context[key] ?? this._deepGet(this.context, key);
                return resolved != null ? String(resolved) : m;
            });
        }
        if (Array.isArray(value)) return value.map((v) => this._sub(v));
        if (value && typeof value === 'object') {
            const out = {};
            for (const [k, v] of Object.entries(value)) out[k] = this._sub(v);
            return out;
        }
        return value;
    }

    /** Resolves a dotted path against an object. @private */
    _deepGet(obj, dottedKey) {
        return dottedKey.split('.').reduce((acc, k) => (acc == null ? acc : acc[k]), obj);
    }

    /** @private */
    async _login() {
        if (!this.hooks.login) {
            Logger.warn(COMPONENT, 'login step requested but no login hook provided — skipping');
            return;
        }
        Logger.info(COMPONENT, 'Executing login hook');
        await this.hooks.login(this.page);
    }

    /**
     * Clicks an element resolved by role/label/text in priority order.
     * @param {string} target
     * @private
     */
    async _click(target) {
        Logger.info(COMPONENT, `Click "${target}"`);
        const candidates = [
            this.page.getByRole('link', { name: target, exact: false }),
            this.page.getByRole('button', { name: target, exact: false }),
            this.page.getByRole('menuitem', { name: target, exact: false }),
            this.page.getByRole('tab', { name: target, exact: false }),
            this.page.getByText(target, { exact: false }),
        ];
        for (const loc of candidates) {
            if (await loc.first().count().catch(() => 0)) {
                await loc.first().click();
                return;
            }
        }
        throw new Error(`Navigation: clickable element "${target}" not found`);
    }

    /** @private */
    async _fill(label, value) {
        Logger.info(COMPONENT, `Fill "${label}" = "${value}"`);
        const byLabel = this.page.getByLabel(label, { exact: false });
        if (await byLabel.first().count().catch(() => 0)) {
            await byLabel.first().fill(String(value));
            return;
        }
        const byPlaceholder = this.page.getByPlaceholder(label, { exact: false });
        if (await byPlaceholder.first().count().catch(() => 0)) {
            await byPlaceholder.first().fill(String(value));
            return;
        }
        throw new Error(`Navigation: input "${label}" not found`);
    }

    /** @private */
    async _select(label, value) {
        Logger.info(COMPONENT, `Select "${label}" = "${value}"`);
        const sel = this.page.getByLabel(label, { exact: false });
        await sel.first().selectOption({ label: String(value) }).catch(async () => {
            await sel.first().selectOption(String(value));
        });
    }
}
