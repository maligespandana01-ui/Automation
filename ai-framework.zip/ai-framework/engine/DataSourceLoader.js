/**
 * @charset UTF-8
 * DataSourceLoader - Loads one or many NTM (data) files and one or many XSDG
 * (schema) files declared in a scenario, then normalises them into a common
 * shape the rest of the engine can reason about.
 *
 * Supported relationships (handled transparently):
 *   - 1 NTM  -> 1 XSDG
 *   - 1 NTM  -> N XSDG   (schemas merged by SchemaMerger)
 *   - N NTM  -> N XSDG   (each NTM record kept, schemas unified)
 *
 * NTM files may be:
 *   - the project's telex-style NTM text wrapped in JSON test-data, OR
 *   - a flat JSON object/array of expected field/value pairs.
 * Both are reduced to a list of "records" (flat key/value maps).
 */
import fs from 'fs';
import path from 'path';
import { XMLParser } from 'fast-xml-parser';
import { Logger } from '../../utils/helpers/Logger.js';
import { NtmParser } from '../../utils/helpers/NtmParser.js';
import { XsdgParser } from '../../utils/helpers/XsdgParser.js';

const COMPONENT = 'DataSourceLoader';

/**
 * @typedef {Object} LoadedData
 * @property {Array<Object>} ntmRecords   - Flattened expected-value records from all NTM files.
 * @property {Array<Object>} xsdgSchemas  - Parsed XSDG schema objects (one per file).
 * @property {Object} rawNtm              - Raw parsed NTM payloads keyed by file.
 * @property {Object} rawXsdg             - Raw parsed XSDG payloads keyed by file.
 */

export class DataSourceLoader {
    /**
     * Loads every NTM and XSDG file referenced by the scenario.
     * @param {import('./ScenarioLoader.js').ScenarioConfig} scenario
     * @returns {LoadedData}
     */
    static load(scenario) {
        const ntmRecords = [];
        const rawNtm = {};
        for (const file of scenario.data_sources.ntm_files) {
            const { records, raw } = this._loadNtm(file);
            rawNtm[path.basename(file)] = raw;
            ntmRecords.push(...records);
        }

        const xsdgSchemas = [];
        const rawXsdg = {};
        for (const file of scenario.data_sources.xsdg_files) {
            try {
                const xml = this._sanitizeXml(fs.readFileSync(file, 'utf8'));
                const parsed = XsdgParser.parseXml(xml);
                rawXsdg[path.basename(file)] = parsed;
                xsdgSchemas.push(this._toSchema(parsed, file));
            } catch (err) {
                Logger.warn(COMPONENT, `XSDG parse failed, attempting generic XML load: ${file}`, { err: String(err) });
                const generic = this._loadGenericXsdg(file);
                rawXsdg[path.basename(file)] = generic;
                xsdgSchemas.push(this._toSchema(generic, file));
            }
        }

        Logger.info(COMPONENT, 'Data sources loaded', {
            ntmRecords: ntmRecords.length,
            xsdgSchemas: xsdgSchemas.length,
        });
        return { ntmRecords, xsdgSchemas, rawNtm, rawXsdg };
    }

    /**
     * Extracts the reusable flight search criteria from the parsed NTM data.
     * Every screen that opens by flight uses these four values, so this is the
     * single, generic source of search criteria across ALL scenarios.
     * @param {LoadedData} data
     * @returns {{ flightNumber: string, flightDate: string, origin: string, destination: string, unitNumber: string }}
     */
    static extractSearchCriteria(data) {
        const firstParsed = Object.values(data.rawNtm || {}).find(
            (v) => v && typeof v === 'object' && v.flightInfo
        );
        const fi = firstParsed?.flightInfo || {};
        return {
            flightNumber: fi.flightNumber || '',
            flightDate: fi.flightDate || '',
            origin: fi.origin || '',
            destination: fi.destination || '',
            unitNumber: fi.unitNumber || '',
        };
    }

    /**
     * Loads a single NTM file and returns flattened expected-value records.
     * @param {string} file
     * @returns {{ records: Array<Object>, raw: any }}
     * @private
     */
    static _loadNtm(file) {
        if (!fs.existsSync(file)) {
            Logger.warn(COMPONENT, `NTM file not found: ${file}`);
            return { records: [], raw: null };
        }
        const content = fs.readFileSync(file, 'utf8');

        // Detect a telex-style NTM message in the RAW content first. This works
        // regardless of file extension (.txt, .json, or none) and tolerates
        // export wrappers like surrounding braces or a leading "NTM" line —
        // NtmParser ignores non-matching lines such as "{", "NTM", "}".
        if (this._looksLikeTelex(content)) {
            const parsed = NtmParser.parse(content);
            return { records: this._ntmToRecords(parsed), raw: parsed };
        }

        // Otherwise treat as JSON: either (a) a test-data wrapper holding NTM
        // telex text, or (b) a flat object / array of expected field values.
        let json;
        try {
            json = JSON.parse(content);
        } catch {
            Logger.warn(COMPONENT, `NTM file is neither telex nor valid JSON, skipping: ${file}`);
            return { records: [], raw: content };
        }
        const telex = this._findNtmTelex(json);
        if (telex) {
            const parsed = NtmParser.parse(telex);
            return { records: this._ntmToRecords(parsed), raw: parsed };
        }

        const records = Array.isArray(json) ? json.map((r) => this._flatten(r)) : [this._flatten(json)];
        return { records, raw: json };
    }

    /**
     * Heuristic: does this raw text contain an NTM telex message?
     * @param {string} text
     * @returns {boolean}
     * @private
     */
    static _looksLikeTelex(text) {
        return /^\s*AA\d+\/\d{1,2}[A-Z]{3}/m.test(text) || /\bDNG[A-Z]{3}/.test(text);
    }

    /**
     * Strips common export-wrapper artifacts so XML can be parsed:
     *  - a single pair of outer curly braces wrapping the document
     *  - any junk before the XML declaration / first element
     * @param {string} content
     * @returns {string}
     * @private
     */
    static _sanitizeXml(content) {
        let xml = content.trim();
        // Remove a single wrapping { ... } pair (export artifact).
        if (xml.startsWith('{') && xml.endsWith('}')) {
            xml = xml.slice(1, -1).trim();
        }
        // Drop anything before the XML declaration or first XML element.
        const declIdx = xml.indexOf('<?xml');
        if (declIdx > 0) {
            xml = xml.slice(declIdx);
        } else {
            const elemIdx = xml.indexOf('<');
            if (elemIdx > 0) xml = xml.slice(elemIdx);
        }
        return xml;
    }

    /**
     * Recursively searches a JSON structure for an embedded NTM telex string.
     * @param {any} node
     * @returns {string|null}
     * @private
     */
    static _findNtmTelex(node) {
        if (node == null) return null;
        if (typeof node === 'string') {
            return /^AA\d+\/\d{1,2}[A-Z]{3}/m.test(node) || /\bDNG[A-Z]{3}/.test(node) ? node : null;
        }
        if (Array.isArray(node)) {
            for (const item of node) {
                const found = this._findNtmTelex(item);
                if (found) return found;
            }
            return null;
        }
        if (typeof node === 'object') {
            if (typeof node.NTM === 'string' && node.NTM.trim()) return node.NTM;
            for (const v of Object.values(node)) {
                const found = this._findNtmTelex(v);
                if (found) return found;
            }
        }
        return null;
    }

    /**
     * Converts a parsed NTM object (flightInfo + dgItems) into flat records,
     * one per DG item, each carrying the flight-level context too.
     * @param {import('../../utils/helpers/NtmParser.js').NtmData} parsed
     * @returns {Array<Object>}
     * @private
     */
    static _ntmToRecords(parsed) {
        const flight = parsed?.flightInfo || {};
        const items = parsed?.dgItems || [];
        if (!items.length) return [this._flatten(flight)];
        return items.map((item) => this._flatten({ ...flight, ...item }));
    }

    /**
     * Builds a normalised schema descriptor from a parsed XSDG payload.
     * @param {Object} parsed
     * @param {string} file
     * @returns {{ source: string, fields: Object, dgItems: Array<Object> }}
     * @private
     */
    static _toSchema(parsed, file) {
        const dgItems = Array.isArray(parsed?.dgItems) ? parsed.dgItems : [];
        const { dgItems: _omit, ...header } = parsed || {};
        return {
            source: path.basename(file),
            fields: this._flatten(header),
            dgItems: dgItems.map((it) => this._flatten(it)),
        };
    }

    /**
     * Last-resort generic XML loader for non-standard XSDG files. Strips the XML
     * declaration node and unwraps a single root element so field keys are clean
     * (e.g. "Account.AccountBalance" instead of "CustomerRecord.Account...").
     * @param {string} file
     * @returns {Object}
     * @private
     */
    static _loadGenericXsdg(file) {
        const parser = new XMLParser({ ignoreAttributes: true, removeNSPrefix: true, parseTagValue: false });
        const parsed = parser.parse(this._sanitizeXml(fs.readFileSync(file, 'utf8')));
        return this._unwrapXmlRoot(parsed);
    }

    /**
     * Removes the "?xml" declaration node and unwraps a lone root element.
     * @param {Object} parsed
     * @returns {Object}
     * @private
     */
    static _unwrapXmlRoot(parsed) {
        if (!parsed || typeof parsed !== 'object') return parsed || {};
        const entries = Object.entries(parsed).filter(([k]) => k !== '?xml');
        if (entries.length === 1 && entries[0][1] && typeof entries[0][1] === 'object') {
            return entries[0][1];
        }
        return Object.fromEntries(entries);
    }

    /**
     * Flattens a nested object into dot-notation keys (arrays indexed).
     * Used so UI / NTM / XSDG can all be compared on a single flat key space.
     * @param {Object} obj
     * @param {string} [prefix]
     * @param {Object} [out]
     * @returns {Object}
     * @private
     */
    static _flatten(obj, prefix = '', out = {}) {
        if (obj == null || typeof obj !== 'object') {
            if (prefix) out[prefix] = obj;
            return out;
        }
        for (const [k, v] of Object.entries(obj)) {
            const key = prefix ? `${prefix}.${k}` : k;
            if (v != null && typeof v === 'object') {
                this._flatten(v, key, out);
            } else {
                out[key] = v;
            }
        }
        return out;
    }
}
