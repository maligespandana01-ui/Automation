/**
 * @charset UTF-8
 * UiExtractor - Generic, locator-free UI extraction engine.
 *
 * Reads ANY rendered screen and produces a structured JSON object of the visible
 * fields without requiring screen-specific selectors. It uses a set of generic
 * DOM heuristics that cover the common enterprise UI patterns:
 *   - Label/value pairs (<label>+input, <dt>/<dd>, "Label: value" text, adjacent cells)
 *   - Form controls (input/select/textarea with associated labels)
 *   - Two-column key/value tables
 *   - Data tables (header row => column keys, body rows => records)
 *   - Nested panels / fieldsets / sections (kept as nested objects)
 *
 * The output is intentionally generic so the AiMappingEngine can map it onto the
 * NTM/XSDG field space for any new scenario with zero code changes.
 */
import { Logger } from '../../utils/helpers/Logger.js';

const COMPONENT = 'UiExtractor';

export class UiExtractor {
    /**
     * Extracts a structured representation of the current page.
     * @param {import('@playwright/test').Page} page
     * @param {{ rootSelector?: string, maxDepth?: number }} [options]
     * @returns {Promise<{ fields: Object, tables: Array<Object>, flat: Object }>}
     */
    static async extract(page, options = {}) {
        const rootSelector = options.rootSelector || 'body';
        const maxDepth = options.maxDepth ?? 12;

        // Ensure dynamic/lazy content is rendered before we read the DOM.
        await this._scrollFullPage(page);

        const result = await page.evaluate(
            ({ rootSelector, maxDepth }) => {
                // ---- helpers run inside the browser context ----
                const clean = (s) => (s == null ? '' : String(s).replace(/\s+/g, ' ').trim());
                const isVisible = (el) => {
                    if (!el) return false;
                    const st = window.getComputedStyle(el);
                    if (st.display === 'none' || st.visibility === 'hidden' || st.opacity === '0') return false;
                    const r = el.getBoundingClientRect();
                    return r.width > 0 && r.height > 0;
                };
                const controlValue = (el) => {
                    const tag = el.tagName.toLowerCase();
                    if (tag === 'select') {
                        const opt = el.options[el.selectedIndex];
                        return clean(opt ? opt.textContent : el.value);
                    }
                    if (tag === 'input') {
                        if (el.type === 'checkbox' || el.type === 'radio') return el.checked ? 'true' : 'false';
                        return clean(el.value);
                    }
                    if (tag === 'textarea') return clean(el.value);
                    return clean(el.textContent);
                };

                const fields = {};
                const tables = [];

                // 1) Explicit label/control associations.
                document.querySelectorAll('label').forEach((label) => {
                    if (!isVisible(label)) return;
                    let control = null;
                    const forId = label.getAttribute('for');
                    if (forId) control = document.getElementById(forId);
                    if (!control) control = label.querySelector('input,select,textarea');
                    const key = clean(label.textContent).replace(/[:*]\s*$/, '');
                    if (key && control) {
                        const val = controlValue(control);
                        if (val !== '') fields[key] = val;
                    }
                });

                // 2) Definition lists (<dt>/<dd>).
                document.querySelectorAll('dl').forEach((dl) => {
                    const dts = dl.querySelectorAll('dt');
                    dts.forEach((dt) => {
                        const dd = dt.nextElementSibling;
                        if (dd && dd.tagName.toLowerCase() === 'dd') {
                            const key = clean(dt.textContent).replace(/[:*]\s*$/, '');
                            const val = clean(dd.textContent);
                            if (key && val) fields[key] = val;
                        }
                    });
                });

                // 3) Tables: classify as key/value (2 cols, no header) vs data table.
                document.querySelectorAll('table').forEach((table) => {
                    if (!isVisible(table)) return;
                    const rows = Array.from(table.rows);
                    if (!rows.length) return;

                    const headerCells = rows[0].querySelectorAll('th');
                    const isDataTable = headerCells.length >= 2;

                    if (isDataTable) {
                        const headers = Array.from(headerCells).map((c, i) => clean(c.textContent) || `col_${i}`);
                        const records = [];
                        for (let r = 1; r < rows.length; r++) {
                            const cells = Array.from(rows[r].cells);
                            if (!cells.length) continue;
                            const rec = {};
                            cells.forEach((c, i) => { rec[headers[i] || `col_${i}`] = clean(c.textContent); });
                            if (Object.values(rec).some((v) => v !== '')) records.push(rec);
                        }
                        if (records.length) tables.push({ headers, records });
                    } else {
                        // Treat 2-column rows as key/value pairs.
                        rows.forEach((row) => {
                            const cells = Array.from(row.cells);
                            if (cells.length === 2) {
                                const key = clean(cells[0].textContent).replace(/[:*]\s*$/, '');
                                const val = clean(cells[1].textContent);
                                if (key && val && key.length < 60) fields[key] = val;
                            }
                        });
                    }
                });

                // 4) Inline "Label: value" text nodes inside leaf containers.
                const labelValueRegex = /^([A-Za-z][\w .\/#()-]{1,48}?)\s*[:#]\s*(.+)$/;
                const root = document.querySelector(rootSelector) || document.body;
                const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
                let node = walker.currentNode;
                let guard = 0;
                while (node && guard < 20000) {
                    guard++;
                    if (isVisible(node) && node.children.length === 0) {
                        const text = clean(node.textContent);
                        const m = text.match(labelValueRegex);
                        if (m) {
                            const key = clean(m[1]);
                            const val = clean(m[2]);
                            if (key && val && !(key in fields)) fields[key] = val;
                        }
                    }
                    node = walker.nextNode();
                }

                return { fields, tables };
            },
            { rootSelector, maxDepth }
        );

        const flat = this._flatten(result.fields);
        // Fold first data-table record set into flat space for single-record screens.
        result.tables.forEach((t, ti) => {
            t.records.forEach((rec, ri) => {
                Object.entries(rec).forEach(([k, v]) => {
                    flat[`table${ti}.row${ri}.${k}`] = v;
                });
            });
        });

        Logger.info(COMPONENT, 'UI extracted', {
            fields: Object.keys(result.fields).length,
            tables: result.tables.length,
            flatKeys: Object.keys(flat).length,
        });
        return { fields: result.fields, tables: result.tables, flat };
    }

    /**
     * Scrolls through the full page so lazy/virtualised content renders.
     * @param {import('@playwright/test').Page} page
     * @private
     */
    static async _scrollFullPage(page) {
        try {
            await page.evaluate(async () => {
                await new Promise((resolve) => {
                    let total = 0;
                    const step = 600;
                    const timer = setInterval(() => {
                        window.scrollBy(0, step);
                        total += step;
                        if (total >= document.body.scrollHeight) {
                            clearInterval(timer);
                            window.scrollTo(0, 0);
                            resolve();
                        }
                    }, 60);
                });
            });
        } catch (err) {
            Logger.warn(COMPONENT, 'Full-page scroll failed (non-fatal)', { err: String(err) });
        }
    }

    /**
     * Flattens nested objects to dot-notation keys.
     * @param {Object} obj
     * @param {string} [prefix]
     * @param {Object} [out]
     * @returns {Object}
     * @private
     */
    static _flatten(obj, prefix = '', out = {}) {
        for (const [k, v] of Object.entries(obj || {})) {
            const key = prefix ? `${prefix}.${k}` : k;
            if (v != null && typeof v === 'object' && !Array.isArray(v)) {
                this._flatten(v, key, out);
            } else {
                out[key] = v;
            }
        }
        return out;
    }
}
