/**
 * @charset UTF-8
 * Mapping prompt templates for the GenAI semantic mapping engine.
 *
 * These prompts are sent to the LLM (via MCP / OpenAI-compatible endpoint) to map
 * UI field labels onto the unified NTM/XSDG field space. They are deliberately
 * strict: the model must return JSON only, with confidence scores, so the engine
 * can apply the scenario's confidence threshold deterministically.
 */

/**
 * Builds the system prompt that constrains model behaviour.
 * @returns {string}
 */
export function systemPrompt() {
    return [
        'You are a precise data-mapping engine for enterprise UI test automation.',
        'You map UI field labels to canonical backend field names (from NTM data and XSDG schema).',
        'Rules:',
        '1. Only map when semantically confident. Account for naming differences',
        '   (e.g. "Cust ID" == "Customer Identifier", "Net Qty" == "netQuantity").',
        '2. Never invent fields. If no good match exists, return mapped_field=null.',
        '3. Output STRICT JSON only — no prose, no markdown, no code fences.',
        '4. confidence is a number between 0 and 1.',
    ].join('\n');
}

/**
 * Builds the user prompt describing the concrete mapping task.
 * @param {string[]} uiFields      - UI field labels to map.
 * @param {string[]} candidateFields - Canonical NTM/XSDG field names.
 * @returns {string}
 */
export function mappingPrompt(uiFields, candidateFields) {
    return [
        'Map each UI field to the single best canonical field.',
        '',
        'UI_FIELDS:',
        JSON.stringify(uiFields, null, 2),
        '',
        'CANONICAL_FIELDS:',
        JSON.stringify(candidateFields, null, 2),
        '',
        'Return JSON of this exact shape:',
        '{ "mappings": [ { "ui_field": "<label>", "mapped_field": "<canonical|null>", "confidence": <0..1> } ] }',
    ].join('\n');
}
