/**
 * @charset UTF-8
 * McpClient - Thin client that calls a GenAI model to perform semantic field
 * mapping. It targets an OpenAI-compatible chat-completions endpoint (the same
 * shape exposed by most MCP LLM bridges and gateways).
 *
 * Configuration (via environment variables / .env):
 *   LLM_API_URL   - chat completions endpoint (e.g. https://gateway/v1/chat/completions)
 *   LLM_API_KEY   - bearer token / api key
 *   LLM_MODEL     - model name (default: gpt-4o-mini)
 *   HTTPS_PROXY   - optional corporate proxy (honoured via https-proxy-agent)
 *
 * If no endpoint is configured OR the call fails, isEnabled() returns false and
 * the AiMappingEngine transparently falls back to deterministic similarity
 * mapping — so the framework always runs, AI or not.
 */
import { HttpsProxyAgent } from 'https-proxy-agent';
import { Logger } from '../../utils/helpers/Logger.js';
import { systemPrompt, mappingPrompt } from './prompts/mappingPrompt.js';

const COMPONENT = 'McpClient';

export class McpClient {
    constructor(config = {}) {
        this.apiUrl = config.apiUrl || process.env.LLM_API_URL || '';
        this.apiKey = config.apiKey || process.env.LLM_API_KEY || '';
        this.model = config.model || process.env.LLM_MODEL || 'gpt-4o-mini';
        this.proxy = process.env.HTTPS_PROXY || process.env.https_proxy || '';
        this.timeoutMs = config.timeoutMs || 30000;
    }

    /** @returns {boolean} true when an LLM endpoint is configured. */
    isEnabled() {
        return Boolean(this.apiUrl && this.apiKey);
    }

    /**
     * Requests a semantic mapping from the model.
     * @param {string[]} uiFields
     * @param {string[]} candidateFields
     * @returns {Promise<Array<{ ui_field: string, mapped_field: string|null, confidence: number }>>}
     */
    async requestMapping(uiFields, candidateFields) {
        if (!this.isEnabled()) {
            Logger.info(COMPONENT, 'LLM endpoint not configured — deterministic fallback will be used');
            return [];
        }

        const body = {
            model: this.model,
            temperature: 0,
            response_format: { type: 'json_object' },
            messages: [
                { role: 'system', content: systemPrompt() },
                { role: 'user', content: mappingPrompt(uiFields, candidateFields) },
            ],
        };

        try {
            const content = await this._post(body);
            const parsed = JSON.parse(content);
            const mappings = Array.isArray(parsed?.mappings) ? parsed.mappings : [];
            Logger.info(COMPONENT, `LLM returned ${mappings.length} mappings`);
            return mappings;
        } catch (err) {
            Logger.warn(COMPONENT, 'LLM mapping request failed — falling back', { err: String(err) });
            return [];
        }
    }

    /**
     * Performs the HTTP POST to the chat-completions endpoint.
     * @param {Object} body
     * @returns {Promise<string>} message content
     * @private
     */
    async _post(body) {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), this.timeoutMs);
        const fetchOpts = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${this.apiKey}`,
            },
            body: JSON.stringify(body),
            signal: controller.signal,
        };
        if (this.proxy) fetchOpts.agent = new HttpsProxyAgent(this.proxy);

        try {
            const res = await fetch(this.apiUrl, fetchOpts);
            if (!res.ok) throw new Error(`LLM HTTP ${res.status}: ${await res.text()}`);
            const json = await res.json();
            return json?.choices?.[0]?.message?.content ?? '{}';
        } finally {
            clearTimeout(timer);
        }
    }
}
