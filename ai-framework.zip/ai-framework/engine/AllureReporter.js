/**
 * @charset UTF-8
 * AllureReporter - Renders business-friendly Allure report content for a
 * validation run. Designed for non-technical readers: plain language, clear
 * PASS/FAIL badges, simple summary, and field-level comparison tables.
 *
 * It produces Allure steps and HTML/text attachments only — no test assertions —
 * so it can be reused by any scenario spec.
 */
import * as allure from 'allure-js-commons';
import { VALIDATION_STATUS } from '../../utils/constants/Constants.js';

const COLOR = { PASS: '#2e7d32', FAIL: '#c62828', IGNORED: '#f9a825' };
const BADGE = { PASS: '✅ PASS', FAIL: '❌ FAIL', IGNORED: '⚠️ REVIEW' };

/** Escapes HTML special characters. */
function esc(str) {
    return String(str ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

export class AllureReporter {
    /**
     * Writes the high-level scenario description.
     * @param {import('./ScenarioLoader.js').ScenarioConfig} scenario
     */
    static async describeRun(scenario) {
        await allure.displayName(`Validation: ${scenario.scenario_name}`);
        await allure.severity('critical');
        await allure.description(
            `**What this test does (in plain words):**\n\n` +
            `It opens the application, goes to the **${esc(scenario.scenario_name)}** screen, reads every value shown on the page, ` +
            `and checks each one against the official source data (NTM) and the data rules (XSDG).\n\n` +
            `- **Green ✅** means the screen matches the source data.\n` +
            `- **Red ❌** means the screen does not match and needs attention.\n` +
            `- **Yellow ⚠️** means a value could not be checked automatically.`
        );
    }

    /**
     * Records a high-level workflow step with a status icon in its name.
     * @param {string} title
     * @param {'PASS'|'FAIL'|'IGNORED'} status
     * @param {() => Promise<any>} [body]
     */
    static async step(title, status, body) {
        const icon = status === VALIDATION_STATUS.PASS ? '✅' : status === VALIDATION_STATUS.FAIL ? '❌' : '⚠️';
        return allure.step(`${icon} ${title}`, async () => {
            if (body) await body();
        });
    }

    /**
     * Attaches the scenario summary card.
     * @param {Object} summary - { total, passed, failed, skipped, missing }
     * @param {Object} meta     - { mappingMode, threshold, sources }
     */
    static async summary(summary, meta = {}) {
        const passRate = summary.total ? Math.round((summary.passed / summary.total) * 100) : 0;
        const overall = summary.failed === 0 ? 'PASS' : 'FAIL';
        const html = `
<div style="font-family:Segoe UI,Arial,sans-serif;max-width:680px">
  <h2 style="margin:0 0 8px">Validation Summary</h2>
  <div style="display:inline-block;padding:6px 14px;border-radius:6px;color:#fff;font-weight:700;background:${COLOR[overall]}">
    Overall result: ${BADGE[overall]}
  </div>
  <table style="border-collapse:collapse;margin-top:14px;width:100%">
    <tbody>
      ${this._summaryRow('Total fields checked', summary.total)}
      ${this._summaryRow('Passed', summary.passed, COLOR.PASS)}
      ${this._summaryRow('Failed', summary.failed, summary.failed ? COLOR.FAIL : COLOR.PASS)}
      ${this._summaryRow('Missing on screen', summary.missing || 0, (summary.missing ? COLOR.FAIL : COLOR.PASS))}
      ${this._summaryRow('Could not check', summary.skipped || 0, COLOR.IGNORED)}
      ${this._summaryRow('Pass rate', `${passRate}%`)}
    </tbody>
  </table>
  <p style="color:#555;margin-top:12px;font-size:13px">
    Mapping method: <b>${esc(meta.mappingMode || 'AI semantic + rules')}</b> ·
    Confidence threshold: <b>${esc(meta.threshold ?? '')}</b><br/>
    Data sources: <b>${esc((meta.sources || []).join(', '))}</b>
  </p>
</div>`;
        await allure.attachment('📋 Scenario Summary', html, 'text/html');
    }

    /**
     * Attaches the field-level comparison table.
     * @param {Array<Object>} results - [{ field, uiField, expected, actual, status, confidence, note }]
     */
    static async comparisonTable(results) {
        const rows = results.map((r) => {
            const color = COLOR[r.status] || '#555';
            return `
      <tr>
        <td style="border:1px solid #ddd;padding:6px">${esc(r.field)}</td>
        <td style="border:1px solid #ddd;padding:6px">${esc(r.actual)}</td>
        <td style="border:1px solid #ddd;padding:6px">${esc(r.expected)}</td>
        <td style="border:1px solid #ddd;padding:6px;color:${color};font-weight:700">${BADGE[r.status] || r.status}</td>
        <td style="border:1px solid #ddd;padding:6px;color:#777">${esc(r.note || '')}</td>
      </tr>`;
        }).join('');

        const html = `
<div style="font-family:Segoe UI,Arial,sans-serif">
  <h3>Field-by-Field Comparison</h3>
  <table style="border-collapse:collapse;width:100%;font-size:13px">
    <thead>
      <tr style="background:#1565c0;color:#fff">
        <th style="border:1px solid #ddd;padding:8px;text-align:left">Field</th>
        <th style="border:1px solid #ddd;padding:8px;text-align:left">Value on Screen</th>
        <th style="border:1px solid #ddd;padding:8px;text-align:left">Expected Value</th>
        <th style="border:1px solid #ddd;padding:8px;text-align:left">Result</th>
        <th style="border:1px solid #ddd;padding:8px;text-align:left">Notes</th>
      </tr>
    </thead>
    <tbody>${rows}</tbody>
  </table>
</div>`;
        await allure.attachment('🔎 Field Comparison Table', html, 'text/html');
    }

    /**
     * Attaches the AI/rule mapping table for transparency.
     * @param {Array<Object>} mappings - [{ ui_field, mapped_field, confidence, origin }]
     */
    static async mappingTable(mappings) {
        const rows = mappings.map((m) => `
      <tr>
        <td style="border:1px solid #ddd;padding:6px">${esc(m.ui_field)}</td>
        <td style="border:1px solid #ddd;padding:6px">${esc(m.mapped_field ?? '(no match)')}</td>
        <td style="border:1px solid #ddd;padding:6px">${(Number(m.confidence) * 100).toFixed(0)}%</td>
        <td style="border:1px solid #ddd;padding:6px">${esc(m.origin)}</td>
      </tr>`).join('');
        const html = `
<div style="font-family:Segoe UI,Arial,sans-serif">
  <h3>How screen fields were matched to source data</h3>
  <table style="border-collapse:collapse;width:100%;font-size:13px">
    <thead><tr style="background:#37474f;color:#fff">
      <th style="border:1px solid #ddd;padding:8px;text-align:left">Screen Field</th>
      <th style="border:1px solid #ddd;padding:8px;text-align:left">Matched Source Field</th>
      <th style="border:1px solid #ddd;padding:8px;text-align:left">Confidence</th>
      <th style="border:1px solid #ddd;padding:8px;text-align:left">Method</th>
    </tr></thead>
    <tbody>${rows}</tbody>
  </table>
</div>`;
        await allure.attachment('🤖 Field Mapping (AI + Rules)', html, 'text/html');
    }

    /**
     * Attaches a screenshot buffer (used on failures).
     * @param {string} name
     * @param {Buffer} buffer
     */
    static async screenshot(name, buffer) {
        if (buffer) await allure.attachment(name, buffer, 'image/png');
    }

    /**
     * Renders a sectioned validation result (one card per UN/ID + header) as a
     * single business-friendly HTML report, and also emits an Allure step per
     * section so the test tree shows each UN/ID with its PASS/FAIL badge.
     * @param {Array<Object>} sections - [{ title, subtitle, status, summary, results }]
     */
    static async sections(sections) {
        if (!Array.isArray(sections) || !sections.length) return;

        const cards = sections.map((s) => this._sectionCard(s)).join('');
        const html = `
<div style="font-family:Segoe UI,Arial,sans-serif;max-width:920px">
  <h2 style="margin:0 0 4px">Emergency Response Report — Section-by-Section Validation</h2>
  <p style="color:#555;margin:0 0 16px;font-size:13px">
    Each card below is one part of the report. The <b>Flight &amp; Shipment</b> card checks the header;
    each <b>Dangerous Goods</b> card checks one UN/ID item, exactly as it appears on screen.
  </p>
  ${cards}
</div>`;
        await allure.attachment('🧾 Sectioned Validation (per UN/ID)', html, 'text/html');

        // One Allure step per section so each UN/ID is visible in the test tree.
        for (const s of sections) {
            await this.step(`${s.title} (${s.summary.passed}/${s.summary.total} passed)`, s.status, async () => {
                await allure.attachment(`${s.title} — details`, this._sectionCard(s), 'text/html');
            });
        }
    }

    /**
     * Builds one HTML card for a validation section.
     * @param {Object} s - { title, subtitle, status, summary, results }
     * @returns {string}
     * @private
     */
    static _sectionCard(s) {
        const color = COLOR[s.status] || '#555';
        const rows = (s.results || []).map((r) => {
            const c = COLOR[r.status] || '#555';
            return `
      <tr>
        <td style="border:1px solid #e0e0e0;padding:6px;white-space:nowrap">${esc(r.field)}</td>
        <td style="border:1px solid #e0e0e0;padding:6px">${esc(r.actual)}</td>
        <td style="border:1px solid #e0e0e0;padding:6px">${esc(r.expected)}</td>
        <td style="border:1px solid #e0e0e0;padding:6px;color:${c};font-weight:700;white-space:nowrap">${BADGE[r.status] || r.status}</td>
        <td style="border:1px solid #e0e0e0;padding:6px;color:#777">${esc(r.note || '')}</td>
      </tr>`;
        }).join('');

        return `
  <div style="border:1px solid #e0e0e0;border-radius:8px;margin:0 0 16px;overflow:hidden">
    <div style="background:${color};color:#fff;padding:10px 14px;display:flex;justify-content:space-between;align-items:center">
      <div>
        <div style="font-weight:700;font-size:15px">${BADGE[s.status] || ''} ${esc(s.title)}</div>
        <div style="font-size:12px;opacity:.9">${esc(s.subtitle || '')}</div>
      </div>
      <div style="font-size:13px;font-weight:700;white-space:nowrap">
        ${s.summary.passed}/${s.summary.total} OK${s.summary.failed ? ` · ${s.summary.failed} failed` : ''}
      </div>
    </div>
    <table style="border-collapse:collapse;width:100%;font-size:13px">
      <thead>
        <tr style="background:#f5f7fa;color:#333">
          <th style="border:1px solid #e0e0e0;padding:8px;text-align:left">Field</th>
          <th style="border:1px solid #e0e0e0;padding:8px;text-align:left">Value on Screen</th>
          <th style="border:1px solid #e0e0e0;padding:8px;text-align:left">Expected (NTM/XSDG)</th>
          <th style="border:1px solid #e0e0e0;padding:8px;text-align:left">Result</th>
          <th style="border:1px solid #e0e0e0;padding:8px;text-align:left">Notes</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>
  </div>`;
    }

    /** @private */
    static _summaryRow(label, value, color) {
        return `<tr>
      <td style="border:1px solid #eee;padding:6px;color:#444">${esc(label)}</td>
      <td style="border:1px solid #eee;padding:6px;font-weight:700;${color ? `color:${color}` : ''}">${esc(value)}</td>
    </tr>`;
    }
}
