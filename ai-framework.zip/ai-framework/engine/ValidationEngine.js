/**
 * @charset UTF-8
 * ValidationEngine - Compares the extracted UI values against the expected
 * NTM/XSDG values using the accepted field mappings.
 *
 * Checks performed (configurable via the scenario's `validation` block):
 *   - Exact value comparison (strict)
 *   - Data-type validation (number / boolean / string)
 *   - Date format + value validation (multi-format aware)
 *   - Missing field detection (expected but absent from UI)
 *   - Extra field detection (present in UI but not expected)
 *
 * Output is a list of per-field results in the {field, expected, actual, status}
 * shape already used elsewhere in this repo, so it plugs straight into Allure.
 */
import { VALIDATION_STATUS, DEFAULT_VALUES } from '../../utils/constants/Constants.js';
import { Logger } from '../../utils/helpers/Logger.js';

const COMPONENT = 'ValidationEngine';

export class ValidationEngine {
    /**
     * @param {import('./ScenarioLoader.js').ScenarioConfig} scenario
     */
    constructor(scenario) {
        this.cfg = scenario.validation;
        this.dateFormats = this.cfg.date_formats || ['MM/DD/YYYY', 'YYYY-MM-DD', 'DD-MMM-YYYY', 'DD/MM/YYYY'];
        this.ignore = new Set((this.cfg.ignore_fields || []).map((s) => this._norm(s)));
    }

    /**
     * Validates UI values against an expected row using the field mappings.
     * @param {Object} uiFlat       - Flat UI field map { label: value }.
     * @param {Object} expectedRow  - Flat expected map { canonicalField: value }.
     * @param {Array<Object>} mappings - Accepted mappings [{ ui_field, mapped_field, confidence }].
     * @returns {{ results: Array<Object>, summary: Object, allPassed: boolean }}
     */
    validate(uiFlat, expectedRow, mappings) {
        const results = [];
        const accepted = mappings.filter((m) => m.mapped_field);
        const usedExpected = new Set();

        for (const m of accepted) {
            if (this.ignore.has(this._norm(m.ui_field)) || this.ignore.has(this._norm(m.mapped_field))) continue;

            const actual = uiFlat[m.ui_field];
            const expected = this._lookupExpected(expectedRow, m.mapped_field);
            usedExpected.add(this._norm(m.mapped_field));

            results.push(this._compareField(m.ui_field, m.mapped_field, actual, expected, m.confidence));
        }

        // Missing-field detection: expected values that were never matched to UI.
        if (this.cfg.detect_missing) {
            for (const [k, v] of Object.entries(expectedRow)) {
                if (this._isEmpty(v) || this.ignore.has(this._norm(k))) continue;
                if (!usedExpected.has(this._norm(k))) {
                    results.push({
                        field: k,
                        uiField: DEFAULT_VALUES.MISSING,
                        expected: v,
                        actual: DEFAULT_VALUES.MISSING,
                        confidence: 0,
                        status: VALIDATION_STATUS.FAIL,
                        note: 'Expected field not found on UI',
                    });
                }
            }
        }

        // Extra-field detection: UI labels with no canonical mapping at all.
        if (this.cfg.detect_extra) {
            const mappedUi = new Set(accepted.map((m) => this._norm(m.ui_field)));
            for (const k of Object.keys(uiFlat)) {
                if (this.ignore.has(this._norm(k))) continue;
                if (!mappedUi.has(this._norm(k))) {
                    results.push({
                        field: k,
                        uiField: k,
                        expected: DEFAULT_VALUES.NA,
                        actual: uiFlat[k],
                        confidence: 0,
                        status: VALIDATION_STATUS.SKIP,
                        note: 'Extra UI field (no expected counterpart)',
                    });
                }
            }
        }

        const summary = this._summarise(results);
        const allPassed = summary.failed === 0;
        Logger.info(COMPONENT, `Validation: ${allPassed ? 'ALL PASSED' : 'FAILURES'}`, summary);
        return { results, summary, allPassed };
    }

    /**
     * Compares a single field, applying type/date awareness.
     * @private
     */
    _compareField(uiField, canonical, actual, expected, confidence) {
        const base = { field: canonical, uiField, expected, actual, confidence };

        if (this._isEmpty(expected)) {
            return { ...base, status: VALIDATION_STATUS.SKIP, note: 'No expected value to compare' };
        }
        if (this._isEmpty(actual)) {
            return { ...base, status: VALIDATION_STATUS.FAIL, note: 'UI value missing' };
        }

        // Date-aware comparison.
        if (this.cfg.validate_dates && this._looksLikeDate(expected) && this._looksLikeDate(actual)) {
            const ed = this._normaliseDate(expected);
            const ad = this._normaliseDate(actual);
            return { ...base, status: ed && ad && ed === ad ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL, note: 'date comparison' };
        }

        // Numeric-aware comparison.
        if (this.cfg.validate_types && this._isNumeric(expected) && this._isNumeric(actual)) {
            const en = this._toNumber(expected);
            const an = this._toNumber(actual);
            return { ...base, status: en === an ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL, note: 'numeric comparison' };
        }

        // Strict vs lenient string comparison.
        const e = String(expected).trim();
        const a = String(actual).trim();
        const equal = this.cfg.strict ? e === a : e.toLowerCase() === a.toLowerCase();
        return { ...base, status: equal ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL };
    }

    /** Looks up an expected value by canonical key or its leaf segment. @private */
    _lookupExpected(expectedRow, canonical) {
        if (canonical in expectedRow) return expectedRow[canonical];
        const leaf = canonical.split('.').pop();
        const hit = Object.keys(expectedRow).find((k) => this._norm(k) === this._norm(leaf) || this._norm(k).endsWith(this._norm(leaf)));
        return hit ? expectedRow[hit] : undefined;
    }

    /** @private */
    _summarise(results) {
        const total = results.length;
        const passed = results.filter((r) => r.status === VALIDATION_STATUS.PASS).length;
        const failed = results.filter((r) => r.status === VALIDATION_STATUS.FAIL).length;
        const skipped = results.filter((r) => r.status === VALIDATION_STATUS.SKIP).length;
        const missing = results.filter((r) => r.note === 'Expected field not found on UI').length;
        return { total, passed, failed, skipped, missing };
    }

    /** @private */
    _isEmpty(v) {
        return v == null || String(v).trim() === '';
    }

    /** @private */
    _isNumeric(v) {
        return /^-?\d+(\.\d+)?$/.test(String(v).replace(/[, ]/g, '').replace(/kg$/i, ''));
    }

    /** @private */
    _toNumber(v) {
        return parseFloat(String(v).replace(/[, ]/g, '').replace(/kg$/i, ''));
    }

    /** @private */
    _looksLikeDate(v) {
        return /\d{1,4}[\/-][A-Za-z0-9]{1,3}[\/-]\d{1,4}/.test(String(v));
    }

    /** Normalises a date string to YYYY-MM-DD for comparison. @private */
    _normaliseDate(v) {
        const s = String(v).trim();
        const months = { jan: '01', feb: '02', mar: '03', apr: '04', may: '05', jun: '06', jul: '07', aug: '08', sep: '09', oct: '10', nov: '11', dec: '12' };

        let m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
        if (m) return `${m[1]}-${m[2]}-${m[3]}`;

        m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/);
        if (m) return `${m[3]}-${m[1].padStart(2, '0')}-${m[2].padStart(2, '0')}`;

        m = s.match(/^(\d{1,2})[-/]([A-Za-z]{3})[-/](\d{4})/);
        if (m) return `${m[3]}-${months[m[2].toLowerCase()] || '01'}-${m[1].padStart(2, '0')}`;

        return s;
    }

    /** @private */
    _norm(s) {
        return String(s).toLowerCase().replace(/[^a-z0-9.]+/g, ' ').replace(/\s+/g, ' ').trim();
    }
}
