/**
 * @charset UTF-8
 * MappingMemory - Persists previously-confirmed field mappings so the framework
 * "learns" across runs and reduces dependence on the LLM over time.
 *
 * Memory is keyed by a normalised UI label and stores the resolved canonical
 * field plus the confidence and origin (exact|alias|ai). On the next run, a high
 * confidence remembered mapping is reused before any LLM call is made.
 *
 * Storage: a single JSON file (default ai-framework/engine/.mapping-memory.json),
 * safe to commit or gitignore depending on team preference.
 */
import fs from 'fs';
import path from 'path';
import { Logger } from '../../utils/helpers/Logger.js';

const COMPONENT = 'MappingMemory';
const DEFAULT_FILE = path.resolve(process.cwd(), 'ai-framework', 'engine', '.mapping-memory.json');

export class MappingMemory {
    /**
     * @param {string} [file] - Override storage location.
     */
    constructor(file = DEFAULT_FILE) {
        this.file = file;
        this.store = this._read();
    }

    /** Normalises a label to a stable lookup key. @param {string} s @returns {string} */
    static key(s) {
        return String(s).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
    }

    /**
     * Returns a remembered mapping for a UI label, if any.
     * @param {string} uiField
     * @returns {{ mapped_field: string, confidence: number, origin: string }|null}
     */
    get(uiField) {
        return this.store[MappingMemory.key(uiField)] || null;
    }

    /**
     * Stores/updates a mapping (keeps the highest-confidence version).
     * @param {string} uiField
     * @param {string} mappedField
     * @param {number} confidence
     * @param {string} origin
     */
    remember(uiField, mappedField, confidence, origin) {
        if (!mappedField) return;
        const k = MappingMemory.key(uiField);
        const existing = this.store[k];
        if (!existing || confidence >= existing.confidence) {
            this.store[k] = { mapped_field: mappedField, confidence, origin };
        }
    }

    /** Persists memory to disk. */
    save() {
        try {
            fs.mkdirSync(path.dirname(this.file), { recursive: true });
            fs.writeFileSync(this.file, JSON.stringify(this.store, null, 2), 'utf8');
            Logger.info(COMPONENT, `Mapping memory saved (${Object.keys(this.store).length} entries)`);
        } catch (err) {
            Logger.warn(COMPONENT, 'Failed to persist mapping memory', { err: String(err) });
        }
    }

    /** @returns {Object} @private */
    _read() {
        try {
            if (fs.existsSync(this.file)) return JSON.parse(fs.readFileSync(this.file, 'utf8'));
        } catch (err) {
            Logger.warn(COMPONENT, 'Could not read mapping memory, starting fresh', { err: String(err) });
        }
        return {};
    }
}
