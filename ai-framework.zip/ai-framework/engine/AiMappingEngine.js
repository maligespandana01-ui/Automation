/**
 * @charset UTF-8
 * AiMappingEngine - Maps UI field labels onto the unified NTM/XSDG canonical
 * field space using a 3-level strategy:
 *
 *   Level 1 — Exact match      : normalised label === normalised canonical name.
 *   Level 2 — Alias match      : global_aliases.json + scenario field_overrides.
 *   Level 3 — AI semantic match: LLM via McpClient, with a deterministic
 *             string-similarity fallback when the LLM is unavailable/uncertain.
 *
 * Mapping memory short-circuits all three levels for labels seen before.
 * Every mapping carries a confidence score; the scenario's confidence_threshold
 * decides whether a mapping is accepted or flagged as unmapped.
 */
import fs from 'fs';
import path from 'path';
import { Logger } from '../../utils/helpers/Logger.js';
import { McpClient } from './McpClient.js';
import { MappingMemory } from './MappingMemory.js';

const COMPONENT = 'AiMappingEngine';

export class AiMappingEngine {
    /**
     * @param {import('./ScenarioLoader.js').ScenarioConfig} scenario
     * @param {{ aliasesPath?: string, mcpClient?: McpClient, memory?: MappingMemory }} [deps]
     */
    constructor(scenario, deps = {}) {
        this.scenario = scenario;
        this.threshold = scenario.mapping_strategy.confidence_threshold;
        this.useAi = scenario.mapping_strategy.type === 'ai_semantic';
        this.useMemory = scenario.mapping_strategy.use_memory !== false;

        this.aliases = this._loadAliases(deps.aliasesPath);
        // Scenario-level overrides win over global aliases.
        Object.assign(this.aliases, this._normaliseAliasMap(scenario.field_overrides || {}));

        this.mcp = deps.mcpClient || new McpClient();
        this.memory = deps.memory || new MappingMemory();
    }

    /**
     * Maps every UI field label to a canonical field.
     * @param {string[]} uiFields
     * @param {string[]} canonicalFields
     * @returns {Promise<{ mappings: Array<Object>, unmapped: string[] }>}
     */
    async map(uiFields, canonicalFields) {
        const canonIndex = this._buildIndex(canonicalFields);
        const mappings = [];
        const needAi = [];

        // Levels 1 & 2 (+ memory) first; collect leftovers for the AI level.
        for (const ui of uiFields) {
            const remembered = this.useMemory ? this.memory.get(ui) : null;
            if (remembered && remembered.confidence >= this.threshold && this._resolve(canonIndex, remembered.mapped_field)) {
                mappings.push({ ui_field: ui, mapped_field: this._resolve(canonIndex, remembered.mapped_field), confidence: remembered.confidence, origin: 'memory' });
                continue;
            }

            const exact = this._resolve(canonIndex, ui);
            if (exact) {
                mappings.push(this._accept(ui, exact, 1.0, 'exact'));
                continue;
            }

            const aliasTarget = this.aliases[this._norm(ui)];
            if (aliasTarget && this._resolve(canonIndex, aliasTarget)) {
                mappings.push(this._accept(ui, this._resolve(canonIndex, aliasTarget), 0.97, 'alias'));
                continue;
            }

            needAi.push(ui);
        }

        // Level 3 — AI semantic mapping (with deterministic fallback).
        if (needAi.length) {
            const aiResults = await this._aiMap(needAi, canonicalFields, canonIndex);
            mappings.push(...aiResults);
        }

        const accepted = mappings.filter((m) => m.mapped_field && m.confidence >= this.threshold);
        const unmapped = mappings.filter((m) => !m.mapped_field || m.confidence < this.threshold).map((m) => m.ui_field);

        if (this.useMemory) {
            accepted.forEach((m) => this.memory.remember(m.ui_field, m.mapped_field, m.confidence, m.origin));
            this.memory.save();
        }

        Logger.info(COMPONENT, 'Mapping complete', {
            total: uiFields.length,
            accepted: accepted.length,
            unmapped: unmapped.length,
            aiUsed: this.useAi && this.mcp.isEnabled(),
        });
        return { mappings, unmapped };
    }

    /**
     * AI / fallback mapping for the leftover fields.
     * @param {string[]} uiFields
     * @param {string[]} canonicalFields
     * @param {Map<string,string>} canonIndex
     * @returns {Promise<Array<Object>>}
     * @private
     */
    async _aiMap(uiFields, canonicalFields, canonIndex) {
        let llm = [];
        if (this.useAi && this.mcp.isEnabled()) {
            llm = await this.mcp.requestMapping(uiFields, canonicalFields);
        }
        const llmByField = new Map(llm.map((m) => [this._norm(m.ui_field), m]));

        return uiFields.map((ui) => {
            const fromLlm = llmByField.get(this._norm(ui));
            if (fromLlm && fromLlm.mapped_field && this._resolve(canonIndex, fromLlm.mapped_field)) {
                return this._accept(ui, this._resolve(canonIndex, fromLlm.mapped_field), Number(fromLlm.confidence) || 0.85, 'ai');
            }
            // Deterministic fallback: best similarity match among canonical fields.
            const best = this._bestSimilarity(ui, canonicalFields);
            if (best.score >= this.threshold) {
                return this._accept(ui, best.field, best.score, 'similarity');
            }
            return { ui_field: ui, mapped_field: null, confidence: best.score, origin: 'unmapped' };
        });
    }

    /**
     * Computes the highest similarity canonical match for a UI label.
     * Combines token Jaccard overlap with normalised Levenshtein distance.
     * @param {string} ui
     * @param {string[]} canonicalFields
     * @returns {{ field: string|null, score: number }}
     * @private
     */
    _bestSimilarity(ui, canonicalFields) {
        let best = { field: null, score: 0 };
        for (const c of canonicalFields) {
            const score = this._similarity(ui, c);
            if (score > best.score) best = { field: c, score: Number(score.toFixed(3)) };
        }
        return best;
    }

    /**
     * Hybrid similarity in [0,1]: 0.6 * tokenJaccard + 0.4 * (1 - normalisedLevenshtein).
     * @param {string} a
     * @param {string} b
     * @returns {number}
     * @private
     */
    _similarity(a, b) {
        const na = this._norm(a);
        const nb = this._norm(b).split('.').pop(); // compare against leaf of dotted canonical key
        const ta = new Set(na.split(' ').filter(Boolean));
        const tb = new Set(nb.split(' ').filter(Boolean));
        const inter = [...ta].filter((t) => tb.has(t)).length;
        const union = new Set([...ta, ...tb]).size || 1;
        const jaccard = inter / union;

        const lev = this._levenshtein(na.replace(/\s/g, ''), nb.replace(/\s/g, ''));
        const maxLen = Math.max(na.length, nb.length) || 1;
        const levSim = 1 - lev / maxLen;

        return 0.6 * jaccard + 0.4 * levSim;
    }

    /** Standard Levenshtein edit distance. @private */
    _levenshtein(a, b) {
        const m = a.length, n = b.length;
        if (!m) return n;
        if (!n) return m;
        const dp = Array.from({ length: m + 1 }, (_, i) => [i, ...Array(n).fill(0)]);
        for (let j = 0; j <= n; j++) dp[0][j] = j;
        for (let i = 1; i <= m; i++) {
            for (let j = 1; j <= n; j++) {
                const cost = a[i - 1] === b[j - 1] ? 0 : 1;
                dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost);
            }
        }
        return dp[m][n];
    }

    /** Builds a normalised-key => original-name index of canonical fields. @private */
    _buildIndex(canonicalFields) {
        const idx = new Map();
        const add = (key, value) => {
            if (key && !idx.has(key)) idx.set(key, value);
        };
        for (const f of canonicalFields) {
            add(this._norm(f), f);
            add(this._compact(f), f);
            const leaf = f.split('.').pop();
            if (leaf) {
                add(this._norm(leaf), f);
                add(this._compact(leaf), f);
            }
        }
        return idx;
    }

    /**
     * Resolves a label against the canonical index using both space-normalised
     * and compact (alnum-only) forms, so "Customer ID" matches "CustomerID".
     * @param {Map<string,string>} idx
     * @param {string} label
     * @returns {string|undefined}
     * @private
     */
    _resolve(idx, label) {
        return idx.get(this._norm(label)) || idx.get(this._compact(label));
    }

    /** @private */
    _accept(uiField, mappedField, confidence, origin) {
        return { ui_field: uiField, mapped_field: mappedField, confidence: Number(confidence.toFixed(3)), origin };
    }

    /** Normalises a label/field name for comparison. @private */
    _norm(s) {
        return String(s).toLowerCase().replace(/[^a-z0-9.]+/g, ' ').replace(/\s+/g, ' ').trim();
    }

    /** Compact (alphanumeric-only, lowercase) form so "Customer ID" == "CustomerID". @private */
    _compact(s) {
        return String(s).split('.').pop().toLowerCase().replace(/[^a-z0-9]+/g, '');
    }

    /** Loads the global alias dictionary. @private */
    _loadAliases(aliasesPath) {
        const file = aliasesPath || path.resolve(process.cwd(), 'ai-framework', 'configs', 'mappings', 'global_aliases.json');
        try {
            if (fs.existsSync(file)) {
                return this._normaliseAliasMap(JSON.parse(fs.readFileSync(file, 'utf8')));
            }
        } catch (err) {
            Logger.warn(COMPONENT, 'Could not load global aliases', { err: String(err) });
        }
        return {};
    }

    /** Normalises alias keys so lookups are case/spacing-insensitive. @private */
    _normaliseAliasMap(map) {
        const out = {};
        for (const [k, v] of Object.entries(map || {})) out[this._norm(k)] = v;
        return out;
    }
}
