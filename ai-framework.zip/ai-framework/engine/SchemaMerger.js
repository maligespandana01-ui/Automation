/**
 * @charset UTF-8
 * SchemaMerger - Merges multiple XSDG schemas into a single unified schema and
 * binds NTM data records onto it.
 *
 * Handles the three relationship cases:
 *   - 1 XSDG  : pass-through
 *   - N XSDG  : union of fields; conflicting field definitions resolved by
 *               precedence (first non-empty wins) while recording the conflict
 *   - N NTM   : every NTM record is matched to the unified schema; multiple
 *               records produce multiple "expected rows"
 *
 * The result is an array of "expected rows": flat key/value maps that the UI
 * extraction will be validated against.
 */
import { Logger } from '../../utils/helpers/Logger.js';

const COMPONENT = 'SchemaMerger';

export class SchemaMerger {
    /**
     * Builds a unified schema + expected rows from loaded NTM/XSDG data.
     * @param {import('./DataSourceLoader.js').LoadedData} data
     * @returns {{ unifiedSchema: Object, expectedRows: Array<Object>, conflicts: Array<Object> }}
     */
    static merge(data) {
        const { unifiedSchema, conflicts } = this._mergeSchemas(data.xsdgSchemas);
        const expectedRows = this._bindNtm(unifiedSchema, data);

        Logger.info(COMPONENT, 'Schema merged', {
            schemas: data.xsdgSchemas.length,
            unifiedFields: Object.keys(unifiedSchema.fields).length,
            expectedRows: expectedRows.length,
            conflicts: conflicts.length,
        });
        return { unifiedSchema, expectedRows, conflicts };
    }

    /**
     * Unions the header + DG item field spaces from every XSDG schema.
     * @param {Array<Object>} schemas
     * @returns {{ unifiedSchema: Object, conflicts: Array<Object> }}
     * @private
     */
    static _mergeSchemas(schemas) {
        const fields = {};
        const itemFields = new Set();
        const conflicts = [];

        for (const schema of schemas) {
            for (const [k, v] of Object.entries(schema.fields || {})) {
                if (!(k in fields) || this._isEmpty(fields[k])) {
                    fields[k] = v;
                } else if (!this._isEmpty(v) && String(fields[k]) !== String(v)) {
                    conflicts.push({ field: k, kept: fields[k], discarded: v, source: schema.source });
                }
            }
            for (const item of schema.dgItems || []) {
                Object.keys(item).forEach((k) => itemFields.add(k));
            }
        }

        return {
            unifiedSchema: { fields, itemFields: [...itemFields], sources: schemas.map((s) => s.source) },
            conflicts,
        };
    }

    /**
     * Produces the expected rows by combining schema header context, schema DG
     * items, and NTM records. NTM values take precedence (they are the data),
     * XSDG provides schema/structure and any header values missing from NTM.
     * @param {Object} unifiedSchema
     * @param {import('./DataSourceLoader.js').LoadedData} data
     * @returns {Array<Object>}
     * @private
     */
    static _bindNtm(unifiedSchema, data) {
        const headerCtx = unifiedSchema.fields;
        const schemaItems = data.xsdgSchemas.flatMap((s) => s.dgItems || []);
        const ntmRecords = data.ntmRecords;

        // No NTM rows: expected = schema items decorated with header context.
        if (!ntmRecords.length) {
            const base = schemaItems.length ? schemaItems : [{}];
            return base.map((item) => ({ ...headerCtx, ...item }));
        }

        // Pair each NTM record with the best schema item (by index, falling back
        // to the first). Multiple NTM rows => multiple expected rows.
        return ntmRecords.map((rec, idx) => {
            const item = schemaItems[idx] || schemaItems[0] || {};
            // Schema (structure) provides the canonical key space; NTM (data)
            // provides the values. Bind NTM values onto schema fields by leaf
            // name so we don't end up with duplicate "schema key" + "label key"
            // entries (which would otherwise be falsely reported as missing).
            const base = { ...headerCtx, ...item };
            return this._bindValuesByLeaf(base, this._nonEmptyOnly(rec));
        });
    }

    /**
     * Overlays `values` onto `base`: when a value's key matches a base key by
     * leaf-name (last dot segment, case/spacing-insensitive) the base field's
     * value is replaced; otherwise the value is added as a new canonical field.
     * @param {Object} base   - Schema-derived field map (canonical keys).
     * @param {Object} values - NTM data values (may use human labels).
     * @returns {Object}
     * @private
     */
    static _bindValuesByLeaf(base, values) {
        const out = { ...base };
        const leafIndex = new Map();
        for (const k of Object.keys(out)) leafIndex.set(this._leaf(k), k);

        for (const [vk, vv] of Object.entries(values)) {
            const target = leafIndex.get(this._leaf(vk));
            if (target) {
                out[target] = vv; // NTM value wins over schema placeholder value
            } else {
                out[vk] = vv;     // NTM-only field with no schema counterpart
                leafIndex.set(this._leaf(vk), vk);
            }
        }
        return out;
    }

    /** Returns the normalised leaf (last dot segment) of a field key. @private */
    static _leaf(key) {
        return String(key).split('.').pop().toLowerCase().replace(/[^a-z0-9]+/g, '');
    }

    /** @returns {boolean} true when value is null/undefined/empty string. @private */
    static _isEmpty(v) {
        return v == null || String(v).trim() === '';
    }

    /** Returns a copy with empty values removed so they don't overwrite real data. @private */
    static _nonEmptyOnly(obj) {
        const out = {};
        for (const [k, v] of Object.entries(obj)) {
            if (!this._isEmpty(v)) out[k] = v;
        }
        return out;
    }
}
