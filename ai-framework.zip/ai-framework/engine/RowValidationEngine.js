/**
 * @charset UTF-8
 * RowValidationEngine - Section-aware validation for reports that repeat the
 * same block of fields for many items (e.g. the Emergency Response Report shows
 * one section per UN/ID / DG item).
 *
 * Instead of flattening the whole report into a single map and comparing only
 * the first row (which produces a lot of false "missing"/"mismatch" noise when
 * there are 3 UN/IDs), this engine:
 *   1. Compares the flight / shipment header once.
 *   2. Matches each UI DG row to its expected NTM/XSDG DG item BY UN/ID number
 *      (falling back to position) and compares them field-by-field.
 *   3. Emits one self-contained "section" per UN/ID so the report reads like the
 *      screen: one clear PASS/FAIL block per dangerous-goods item.
 *
 * Field meaning is mapped explicitly (UI label <-> NTM/XSDG field) so values are
 * compared like-for-like (UN/ID digits, packing group, pieces, net qty, etc.).
 */
import { VALIDATION_STATUS } from '../../utils/constants/Constants.js';
import { Logger } from '../../utils/helpers/Logger.js';

const COMPONENT = 'RowValidationEngine';

/**
 * Flight / shipment header fields. `expected` reads from the NTM-derived search
 * criteria; `actual` reads from the UI report's flight-info header.
 */
const HEADER_FIELDS = [
    { label: 'Flight Number', expected: ['flightNumber'], actual: ['flightNumber'], kind: 'flight' },
    { label: 'Flight Date', expected: ['flightDate'], actual: ['date', 'flightDate'], kind: 'date' },
    { label: 'Origin', expected: ['origin'], actual: ['from', 'origin'], kind: 'code' },
    { label: 'Destination', expected: ['destination'], actual: ['to', 'destination'], kind: 'code' },
    { label: 'Unit Number (ULD)', expected: ['unitNumber', 'uld'], actual: ['unitNum', 'unitNumber'], kind: 'code' },
];

/**
 * Per-UN/ID dangerous-goods fields. `expected` lists the candidate NTM/XSDG
 * field names (first non-empty wins); `actual` lists the candidate UI row keys.
 */
const HAZMAT_FIELDS = [
    { label: 'UN/ID Number', expected: ['unid'], actual: ['unIdNumber', 'unid'], kind: 'unid', key: true },
    { label: 'Proper Shipping Name', expected: ['properShippingName'], actual: ['properShippingName'], kind: 'text' },
    { label: 'Class / Division', expected: ['classDivision'], actual: ['classDivision'], kind: 'code' },
    { label: 'Packing Group', expected: ['packingGroup'], actual: ['packingGroup'], kind: 'pg' },
    { label: 'Pieces', expected: ['numPcs', 'pieces'], actual: ['numPcs', 'pieces'], kind: 'number' },
    { label: 'Net Quantity', expected: ['netQty'], actual: ['netQty'], kind: 'qty' },
    { label: 'Reportable Qty (RQ)', expected: ['rq', 'reportableQty'], actual: ['rq', 'reportableQty'], kind: 'yn' },
];

export class RowValidationEngine {
    /** @param {import('./ScenarioLoader.js').ScenarioConfig} scenario */
    constructor(scenario) {
        this.cfg = (scenario && scenario.validation) || {};
        this.strict = this.cfg.strict !== false;
    }

    /**
     * Validates a sectioned report.
     * @param {{ header: Object, rows: Array<Object> }} actual - UI header + DG rows.
     * @param {{ header: Object, rows: Array<Object> }} expected - NTM/XSDG header + DG rows.
     * @returns {{ sections: Array<Object>, summary: Object, allPassed: boolean }}
     */
    validate(actual, expected) {
        const sections = [];

        // 1. Flight / shipment header (compared once).
        sections.push(this._compareSection(
            'Flight & Shipment',
            'Header values shown on the report vs the NTM',
            HEADER_FIELDS,
            actual.header || {},
            expected.header || {}
        ));

        // 2. One section per expected UN/ID, matched to its UI row by UN/ID number.
        const actualRows = Array.isArray(actual.rows) ? actual.rows : [];
        const expectedRows = Array.isArray(expected.rows) ? expected.rows : [];
        const usedActual = new Set();

        expectedRows.forEach((expRow, idx) => {
            const expKey = this._unidKey(this._read(expRow, ['unid']));
            let actRow = null;
            let actIndex = -1;

            // Prefer matching by UN/ID number (stable across ordering differences).
            if (expKey) {
                actIndex = actualRows.findIndex((r, i) =>
                    !usedActual.has(i) && this._unidKey(this._read(r, ['unIdNumber', 'unid'])) === expKey);
            }
            // Fall back to positional match when UN/ID is absent or not found.
            if (actIndex < 0 && !usedActual.has(idx) && actualRows[idx]) {
                actIndex = idx;
            }
            if (actIndex >= 0) {
                actRow = actualRows[actIndex];
                usedActual.add(actIndex);
            }

            const unidLabel = expKey ? `UN${expKey}` : `Item ${idx + 1}`;
            const ctx = this._rowContext(expRow, actRow);
            sections.push(this._compareSection(
                `Dangerous Goods - ${unidLabel}`,
                ctx,
                HAZMAT_FIELDS,
                actRow || {},
                expRow,
                !actRow
            ));
        });

        // 3. Extra UI rows that did not match any expected UN/ID (informational).
        actualRows.forEach((actRow, i) => {
            if (usedActual.has(i)) return;
            const unid = this._unidKey(this._read(actRow, ['unIdNumber', 'unid']));
            sections.push({
                title: `Dangerous Goods - ${unid ? `UN${unid}` : `Extra item ${i + 1}`} (on screen only)`,
                subtitle: 'Shown on the report but not present in the NTM/XSDG source',
                status: VALIDATION_STATUS.SKIP,
                summary: { total: 0, passed: 0, failed: 0, missing: 0, skipped: 1 },
                results: HAZMAT_FIELDS.map((f) => ({
                    field: f.label,
                    expected: '—',
                    actual: this._read(actRow, f.actual),
                    status: VALIDATION_STATUS.SKIP,
                    note: 'No matching source item',
                })),
            });
        });

        const summary = this._aggregate(sections);
        const allPassed = summary.failed === 0;
        Logger.info(COMPONENT, `Sectioned validation: ${allPassed ? 'ALL PASSED' : 'FAILURES'}`, summary);
        return { sections, summary, allPassed };
    }

    /**
     * Compares one block of fields and returns a section result.
     * @private
     */
    _compareSection(title, subtitle, fields, actualObj, expectedObj, forceMissing = false) {
        const results = fields.map((f) => {
            const expected = this._read(expectedObj, f.expected);
            const actual = forceMissing ? undefined : this._read(actualObj, f.actual);

            if (this._isEmpty(expected)) {
                return { field: f.label, expected: '—', actual: this._show(actual), status: VALIDATION_STATUS.SKIP, note: 'No source value to check' };
            }
            if (this._isEmpty(actual)) {
                return { field: f.label, expected: this._show(expected), actual: '— missing —', status: VALIDATION_STATUS.FAIL, note: 'Not found on screen' };
            }
            const ok = this._equal(f.kind, actual, expected);
            return {
                field: f.label,
                expected: this._show(expected),
                actual: this._show(actual),
                status: ok ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL,
                note: ok ? '' : 'Value differs',
            };
        });

        const summary = this._summarise(results);
        const status = summary.failed > 0
            ? VALIDATION_STATUS.FAIL
            : (summary.passed > 0 ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.SKIP);
        return { title, subtitle, status, summary, results };
    }

    /** Builds a short context line for a DG section. @private */
    _rowContext(expRow, actRow) {
        const psn = this._read(expRow, ['properShippingName']) || this._read(actRow || {}, ['properShippingName']) || '';
        const awb = this._read(actRow || {}, ['awbNumber', 'awb']) || this._read(expRow, ['awb', 'awbNumber']) || '';
        const uld = this._read(actRow || {}, ['unitNum', 'unitNumber']) || this._read(expRow, ['unitNumber', 'uld']) || '';
        const bits = [];
        if (psn) bits.push(String(psn));
        if (awb) bits.push(`AWB ${awb}`);
        if (uld) bits.push(`ULD ${uld}`);
        return bits.join(' · ') || 'Dangerous goods item';
    }

    // ---- value reading + comparison helpers ----

    /**
     * Reads the first non-empty value among candidate keys, matching by exact key
     * first and then by normalised leaf name (so dotted/cased keys still resolve).
     * @private
     */
    _read(obj, candidates) {
        if (!obj) return undefined;
        for (const c of candidates) {
            if (c in obj && !this._isEmpty(obj[c])) return obj[c];
        }
        const normCandidates = candidates.map((c) => this._norm(c));
        for (const [k, v] of Object.entries(obj)) {
            const leaf = this._norm(String(k).split('.').pop());
            if (normCandidates.includes(leaf) && !this._isEmpty(v)) return v;
        }
        return undefined;
    }

    /** @private */
    _equal(kind, actual, expected) {
        const a = String(actual).trim();
        const e = String(expected).trim();
        switch (kind) {
            case 'unid':
                return this._unidKey(a) === this._unidKey(e);
            case 'number':
                return this._toNum(a) === this._toNum(e);
            case 'qty': {
                const an = this._toNum(a);
                const en = this._toNum(e);
                if (an != null && en != null) return an === en;
                return this._loose(a) === this._loose(e);
            }
            case 'pg':
                return this._loose(a) === this._loose(e);
            case 'code':
                return a.toUpperCase() === e.toUpperCase();
            case 'date':
                return this._dateKey(a) === this._dateKey(e);
            case 'yn':
                return this._yn(a) === this._yn(e);
            case 'flight':
                return a.replace(/^0+/, '') === e.replace(/^0+/, '');
            case 'text':
            default: {
                const an = this._loose(a);
                const en = this._loose(e);
                if (an === en) return true;
                // Tolerate UI truncation / minor wording: accept containment.
                return an.length > 3 && en.length > 3 && (an.includes(en) || en.includes(an));
            }
        }
    }

    /** UN/ID reduced to its digits (UN2915 -> 2915, 01324 -> 1324). @private */
    _unidKey(v) {
        return String(v ?? '').replace(/[^0-9]/g, '').replace(/^0+/, '');
    }

    /** Numeric value or null. @private */
    _toNum(v) {
        const m = String(v).replace(/,/g, '').match(/-?\d+(\.\d+)?/);
        return m ? parseFloat(m[0]) : null;
    }

    /** Lowercased alphanumeric form for tolerant text compare. @private */
    _loose(v) {
        return String(v ?? '').toLowerCase().replace(/[^a-z0-9]+/g, '');
    }

    /** Normalises Y/N style values. @private */
    _yn(v) {
        const s = String(v ?? '').trim().toLowerCase();
        if (s === 'y' || s === 'yes' || s === 'true' || s === 'rq') return 'Y';
        return 'N';
    }

    /** Normalises a date to YYYY-MM-DD for comparison. @private */
    _dateKey(v) {
        const s = String(v ?? '').trim();
        let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
        if (m) return `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`;
        m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/);
        if (m) return `${m[3]}-${m[1].padStart(2, '0')}-${m[2].padStart(2, '0')}`;
        return s;
    }

    /** @private */
    _norm(s) {
        return String(s ?? '').toLowerCase().replace(/[^a-z0-9]+/g, '');
    }

    /** @private */
    _isEmpty(v) {
        return v == null || String(v).trim() === '';
    }

    /** @private */
    _show(v) {
        return this._isEmpty(v) ? '—' : String(v);
    }

    /** @private */
    _summarise(results) {
        return {
            total: results.length,
            passed: results.filter((r) => r.status === VALIDATION_STATUS.PASS).length,
            failed: results.filter((r) => r.status === VALIDATION_STATUS.FAIL).length,
            skipped: results.filter((r) => r.status === VALIDATION_STATUS.SKIP).length,
            missing: results.filter((r) => r.note === 'Not found on screen').length,
        };
    }

    /** @private */
    _aggregate(sections) {
        return sections.reduce((acc, s) => {
            acc.total += s.summary.total;
            acc.passed += s.summary.passed;
            acc.failed += s.summary.failed;
            acc.skipped += s.summary.skipped || 0;
            acc.missing += s.summary.missing || 0;
            return acc;
        }, { total: 0, passed: 0, failed: 0, skipped: 0, missing: 0 });
    }
}
