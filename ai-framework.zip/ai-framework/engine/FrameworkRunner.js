/**
 * @charset UTF-8
 * FrameworkRunner - The single orchestrator that runs an entire AI-driven
 * UI-vs-data validation from a scenario config. This is the only class a test
 * spec needs to call.
 *
 * Pipeline:
 *   1. Load scenario (YAML/JSON)
 *   2. Load + merge NTM (data) and XSDG (schema) sources
 *   3. Navigate the application (generic, locator-free)
 *   4. Extract all visible UI fields
 *   5. AI-map UI fields -> canonical NTM/XSDG fields (3-level strategy)
 *   6. Validate (strict, type/date/missing/extra aware)
 *   7. Emit a business-friendly Allure report
 *
 * The runner is framework-agnostic about HOW the browser/login is provided: the
 * caller passes a `page` and an optional `login` hook, keeping this reusable.
 */
import * as allure from 'allure-js-commons';
import { VALIDATION_STATUS } from '../../utils/constants/Constants.js';
import { Logger } from '../../utils/helpers/Logger.js';

import { ScenarioLoader } from './ScenarioLoader.js';
import { DataSourceLoader } from './DataSourceLoader.js';
import { SchemaMerger } from './SchemaMerger.js';
import { Navigator } from './Navigator.js';
import { UiExtractor } from './UiExtractor.js';
import { AiMappingEngine } from './AiMappingEngine.js';
import { ValidationEngine } from './ValidationEngine.js';
import { RowValidationEngine } from './RowValidationEngine.js';
import { AllureReporter } from './AllureReporter.js';

const COMPONENT = 'FrameworkRunner';

export class FrameworkRunner {
    /**
     * @param {string} scenarioPath - Path to the scenario YAML/JSON.
     * @param {{
     *   page: import('@playwright/test').Page,
     *   login?: (page:any)=>Promise<void>,
     *   navigate?: (page:any, ctx:Object)=>Promise<void>,
     *   extract?: (page:any, ctx:Object)=>Promise<{fields?:Object, flat:Object, tables?:Array}>
     * }} ctx
     *   - login:    optional login hook (used by the `login` navigation step)
     *   - navigate: optional screen adapter; when provided it OWNS navigation +
     *               search (receives NTM-derived criteria in ctx.criteria) and
     *               the generic Navigator/navigation_steps are skipped.
     *   - extract:  optional screen adapter that returns the UI field map for
     *               complex/legacy screens; when omitted the generic UiExtractor
     *               reads the DOM.
     */
    constructor(scenarioPath, ctx) {
        this.scenarioPath = scenarioPath;
        this.page = ctx.page;
        this.login = ctx.login;
        this.navigateHook = ctx.navigate;
        this.extractHook = ctx.extract;
        // Optional single dataset (test case) to run when the scenario declares a
        // `datasets:` list. Shape: { name, ntm_files, xsdg_files }. When set, it
        // overrides the scenario's data_sources for this run.
        this.dataset = ctx.dataset;
    }

    /**
     * Runs the full validation pipeline.
     * @returns {Promise<{ allPassed: boolean, summary: Object, results: Array<Object>, mappings: Array<Object> }>}
     */
    async run() {
        const scenario = ScenarioLoader.load(this.scenarioPath);
        await AllureReporter.describeRun(scenario);

        // Resolve which data sources this run uses: an explicit dataset (one case
        // from a multi-case scenario) takes precedence over the scenario default.
        const effectiveScenario = this.dataset
            ? { ...scenario, data_sources: { ntm_files: this.dataset.ntm_files, xsdg_files: this.dataset.xsdg_files } }
            : scenario;

        // ---- Load + merge data sources ----
        let merged;
        let criteria;
        let loadedData;
        await AllureReporter.step('Load & merge source data (NTM + XSDG)', VALIDATION_STATUS.PASS, async () => {
            loadedData = DataSourceLoader.load(effectiveScenario);
            merged = SchemaMerger.merge(loadedData);
            // Reusable across ALL screens: flight search criteria from the NTM.
            criteria = DataSourceLoader.extractSearchCriteria(loadedData);
            await allure.attachment('Search criteria (from NTM)', JSON.stringify(criteria, null, 2), 'application/json');
            await allure.attachment('NTM records (expected data)', JSON.stringify(loadedData.ntmRecords, null, 2), 'application/json');
            await allure.attachment('Unified XSDG schema', JSON.stringify(merged.unifiedSchema, null, 2), 'application/json');
            await allure.attachment('Expected rows (merged)', JSON.stringify(merged.expectedRows, null, 2), 'application/json');
            if (merged.conflicts.length) {
                await allure.attachment('Schema conflicts resolved', JSON.stringify(merged.conflicts, null, 2), 'application/json');
            }
        });

        // Context shared with hooks and used to resolve ${ntm.*} placeholders.
        const hookCtx = { criteria, ntm: criteria, data: loadedData, scenario };

        // ---- Navigate ----
        await AllureReporter.step('Launch & navigate to screen', VALIDATION_STATUS.PASS, async () => {
            if (this.navigateHook) {
                // Screen adapter owns navigation + NTM-driven search.
                await this.navigateHook(this.page, hookCtx);
            } else {
                await this.page.goto(scenario.application.url, { waitUntil: 'domcontentloaded' }).catch(() => {});
                const navigator = new Navigator(this.page, { login: this.login, context: { ntm: criteria } });
                await navigator.run(scenario.application.navigation_steps);
            }
        });

        // ---- Extract UI ----
        let ui;
        await AllureReporter.step('Extract all visible UI fields', VALIDATION_STATUS.PASS, async () => {
            ui = this.extractHook
                ? await this.extractHook(this.page, hookCtx)
                : await UiExtractor.extract(this.page);
            if (!ui.flat) ui.flat = {};
            await allure.attachment('Extracted UI fields', JSON.stringify(ui.fields || ui.flat, null, 2), 'application/json');
            if (ui.tables) await allure.attachment('Extracted UI tables', JSON.stringify(ui.tables, null, 2), 'application/json');
        });

        // ---- Section-aware (per-UN/ID) validation --------------------------------
        // When the screen adapter returns DG `rows` (e.g. the ERR report), validate
        // section-by-section: the flight header once, then ONE section per UN/ID
        // matched to its NTM/XSDG item. This mirrors the screen and avoids the
        // false-diff noise of flattening many rows into a single comparison.
        if (Array.isArray(ui.rows) && ui.rows.length) {
            const rowEngine = new RowValidationEngine(scenario);
            const { sections, summary, allPassed } = rowEngine.validate(
                { header: ui.header || {}, rows: ui.rows },
                { header: criteria, rows: merged.expectedRows }
            );

            await AllureReporter.summary(summary, {
                mappingMode: 'Per-UN/ID field mapping (NTM/XSDG)',
                threshold: scenario.mapping_strategy && scenario.mapping_strategy.confidence_threshold,
                sources: merged.unifiedSchema.sources,
            });
            await AllureReporter.sections(sections);

            await AllureReporter.step(
                `Validate report sections (${summary.passed}/${summary.total} checks passed)`,
                allPassed ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL,
                async () => {
                    if (!allPassed && scenario.report && scenario.report.screenshots_on_failure) {
                        const shot = await this.page.screenshot({ fullPage: true }).catch(() => null);
                        await AllureReporter.screenshot('Screen at time of failure', shot);
                    }
                }
            );

            Logger.info(COMPONENT, `Run complete (sectioned) for "${scenario.scenario_name}"`, summary);
            return { allPassed, summary, results: sections, mappings: [] };
        }

        // ---- AI mapping ----
        const expectedRow = merged.expectedRows[0] || {};
        const canonicalFields = this._canonicalFields(merged);
        const uiFields = Object.keys(ui.flat);

        const engine = new AiMappingEngine(scenario);
        let mapResult;
        const mappingMode = engine.useAi && engine.mcp.isEnabled() ? 'AI semantic (LLM) + rules' : 'Rules + similarity (LLM offline)';
        await AllureReporter.step('Map screen fields to source data (AI + rules)', VALIDATION_STATUS.PASS, async () => {
            mapResult = await engine.map(uiFields, canonicalFields);
            await AllureReporter.mappingTable(mapResult.mappings);
            if (mapResult.unmapped.length) {
                await allure.attachment('Unmapped UI fields (below confidence threshold)', JSON.stringify(mapResult.unmapped, null, 2), 'application/json');
            }
        });

        // ---- Validate ----
        const validator = new ValidationEngine(scenario);
        const { results, summary, allPassed } = validator.validate(ui.flat, expectedRow, mapResult.mappings);

        // ---- Report ----
        await AllureReporter.summary(summary, {
            mappingMode,
            threshold: scenario.mapping_strategy.confidence_threshold,
            sources: merged.unifiedSchema.sources,
        });
        await AllureReporter.comparisonTable(results);

        await AllureReporter.step(
            `Validate screen values against source data (${summary.passed}/${summary.total} passed)`,
            allPassed ? VALIDATION_STATUS.PASS : VALIDATION_STATUS.FAIL,
            async () => {
                if (!allPassed && scenario.report.screenshots_on_failure) {
                    const shot = await this.page.screenshot({ fullPage: true }).catch(() => null);
                    await AllureReporter.screenshot('Screen at time of failure', shot);
                }
            }
        );

        Logger.info(COMPONENT, `Run complete for "${scenario.scenario_name}"`, summary);
        return { allPassed, summary, results, mappings: mapResult.mappings };
    }

    /**
     * Collects the canonical field name space from the merged schema + expected rows.
     * @param {{ unifiedSchema: Object, expectedRows: Array<Object> }} merged
     * @returns {string[]}
     * @private
     */
    _canonicalFields(merged) {
        const set = new Set([
            ...Object.keys(merged.unifiedSchema.fields || {}),
            ...(merged.unifiedSchema.itemFields || []),
        ]);
        merged.expectedRows.forEach((row) => Object.keys(row).forEach((k) => set.add(k)));
        return [...set];
    }
}
